# How to Subscribe to Price AI Skills

This document explains how your repository can receive AI coding rules (Agent
Skills) for both **Cursor IDE** and **GitHub Copilot**.

## Prerequisites

| Tool | Requirement |
|------|-------------|
| **Cursor IDE** | Beta/Nightly release (stable does not support Agent Skills yet) |
| **GitHub Copilot** | VS Code with Copilot extension |

## Overview

By subscribing, your repository automatically receives Agent Skills that teach
AI assistants your organization's coding standards. Skills work with both
Cursor and Copilot using the same format.

### What You'll Receive

```
your-repo/
├── .cursor/
│   └── skills/                    # Cursor reads skills from here
│       ├── coding-principles/SKILL.md
│       ├── python-backend/SKILL.md
│       └── ...
├── .github/
│   └── skills/                    # Copilot reads skills from here
│       ├── coding-principles/SKILL.md
│       ├── python-backend/SKILL.md
│       └── ...
└── .ai-rules-version              # Version tracking
```

Same skills, two locations—both tools get identical content.

## How to Subscribe

### Step 1: Add GitHub Topic

Add a topic to your repository that matches your tech stack:

1. Go to your repository on GitHub
2. Click the gear icon (⚙️) next to "About"
3. Add a topic from the list below
4. Click "Save changes"

### Available Topics

| Topic | What You Get |
|-------|--------------|
| `ai-rules-backend-python` | Generic skills + Python backend |
| `ai-rules-backend-typescript` | Generic skills + TypeScript backend |
| `ai-rules-backend-dotnet` | Generic skills + .NET backend |
| `ai-rules-backend-rest-api` | Generic skills + REST API standards |
| `ai-rules-frontend` | Generic skills + Frontend standards |
| `ai-rules-devops` | Generic skills + DevOps CI/CD |
| `ai-rules-devops-infrastructure` | Generic skills + DevOps + Terraform |

**Generic skills** (security, QA, architecture) are included with ALL topics.

### Step 2: Wait for PR

The distribution pipeline will:

1. Detect your repository based on the topic
2. Open a PR with the relevant skills
3. You review and merge

## How Skills Work

### Context-Aware Loading

Both Cursor and Copilot read skill descriptions to decide when to load them:

```yaml
# SKILL.md frontmatter
---
name: python-backend
description: |
  Python backend development standards. Use when writing Python services,
  FastAPI apps, async code, Pydantic models, or pytest tests.
---
```

When you ask about Python, the AI loads `python-backend`. When you ask about
security, it loads `security-owasp-cwe`. The AI decides based on context.

### Always-Active Skills

Security and architecture skills are always loaded:

- `security-owasp-cwe` - OWASP Top 10, CWE guidelines
- `secure-by-design` - Security principles
- `security-critical-rules` - Critical security rules (PHI, secrets)
- `coding-principles` - Core coding standards

## Version Tracking

The `.ai-rules-version` file tracks what you have:

```json
{
  "version": "1.0.0",
  "content_hash": "abc123def456...",
  "topics": ["ai-rules-backend-python"],
  "skills": ["coding-principles", "python-backend", "..."],
  "updated_at": "2026-01-11T00:00:00Z"
}
```

PRs are only created when skills actually change.

### Pinning a Version

To stay on a specific version, create `.ai-rules-config`:

```yaml
pinned_version: "1.0.0"
```

### Disabling Updates

```yaml
enabled: false
```

## Managing Subscriptions

| Action | How |
|--------|-----|
| Add subscription | Add new GitHub topic |
| Remove subscription | Remove GitHub topic |
| Change subscription | Modify topics |

Changes take effect on next distribution run.

## Support

- See [README.md](./README.md) for skill details
- See [CONTRIBUTING.md](./CONTRIBUTING.md) for how skills are managed
- Open an issue for questions
