# Proposal: AI-Augmented PI Planning & End-to-End Agentic SDLC

## 1. Executive Summary

This proposal outlines the enhancement of our AI agent ecosystem to support a **Human-in-the-loop, Jira-first, Multi-Stage Lifecycle**. Through this process, we enable Product Owners, Tech Leads, and Developers to collaborate seamlessly across ChatGPT Enterprise, IDEs (Cursor/GitHub Copilot), and GitHub Cloud Agents.

**Key Capabilities:**

- **Dual-Path Architecture**: Product teams use ChatGPT Enterprise; Engineering teams use IDE agents
- **Autonomy Scoring**: AI-calculated readiness labels determine which stories can be automated
- **Opt-In Cloud Agents**: Teams choose whether to enable autonomous code generation for agent-ready stories
- **Centralized Governance**: Skills and standards distributed automatically via GitHub Topics
- **Full Traceability**: PRD → Epic → Story → Code with labels for metrics and adoption tracking

**Why This Matters:**

- Accelerates time-to-value for well-defined stories
- Maintains human oversight where complexity or judgment is required
- Provides clear metrics on AI adoption and effectiveness
- Scales best practices across all repositories automatically

---

## 2. The End-to-End Agentic SDLC

### Visual Overview

```mermaid
flowchart TB
    subgraph Product["🎯 Product Path (ChatGPT Enterprise)"]
        A[Ideation GPT] --> B[Epic GPT] --> C[Story GPT]
    end
    
    subgraph Tech["👨‍💻 Tech Lead Path (IDE Agents)"]
        D[Epic Agent] --> E[Story Agent]
    end
    
    C --> F{AI Disposition}
    E --> F
    
    F -->|"ai-human-led\n(Score <50)"| G["👤 Human Developer\n(Full ownership)"]
    F -->|"ai-assisted\n(Score 50-79)"| H["🤝 Developer + IDE Agents\n(AI assists human)"]
    F -->|"ai-auto + agent-ready\n(Score ≥80)\n+ Team Enabled"| I["☁️ Cloud Agents\n(AI implements, human reviews)"]
    
    subgraph IDE["🛠️ IDE Agents (Cursor / GitHub Copilot)"]
        direction TB
        J[API Architect]
        K[Unit Tests Agent]
        L[Debug Agent]
        M[Address Comments]
        N[Git Commit Agent]
        O[Janitor Agent]
        P[Mentor Agent]
    end
    
    subgraph Cloud["☁️ Cloud Agents (GitHub - Opt-In)"]
        direction TB
        Q[PRD Agent]
        R[Solution Design Agent]
        S[Backlog Agent]
        T[Coding Agent]
    end
    
    H --> IDE
    I --> Cloud
```

---

## 3. The Multi-Stage Agent Lifecycle

### Stage 1: Ideation to PRD (ChatGPT Enterprise)

- **Process**: Product Owners initiate a conversation in ChatGPT Enterprise to refine a new feature or idea. The agent uses Atlassian Apps (Rovo Connector) to research existing Confluence documentation and Jira items, plus Web Search for market analysis.
- **Agent**: **Ideation GPT** — Transforms rough ideas into comprehensive PRDs through collaborative refinement and research integration.
- **Output**: A structured Product Requirements Document (PRD) following a business-friendly format with user personas, requirements, success metrics, and business vocabulary.
- **Storage**: Using Atlassian App, the finalized PRD is exported to **Confluence** or **SharePoint (Microsoft App)** for stakeholder review and sign-off.
- **Dependency**: Apps for Custom GPTs are in Beta and will be available for Zelis Enterprise account on Feb 2nd.

---

### Stage 2: PRD to Jira Epic (ChatGPT Enterprise / IDE)

- **Process**: Once the PRD is approved, the Epic agent pulls the document content and converts it into a Jira Epic. Product teams use ChatGPT Enterprise (Epic GPT); Tech Leads can use IDE agents (Epic Agent) for technical work without PRDs.
- **Agent**: **Epic GPT / Epic Agent** — Converts PRD into technical Epic using the CREATE framework (Context, Result, Explain, Approach, Tone, Edit), or creates standalone Epics for tech debt, bugs, and infrastructure work.
- **Output**: Jira Epic with structured sections: business problem, engineering objectives, architecture approach, implementation phases, risk assessment, and dependencies.
- **Governance**: The Epic is tagged with standardized labels (`ai_generated`, `prd_linked`) to ensure full traceability from ideation to execution.

---

### Stage 3: Epic to User Stories (ChatGPT Enterprise / IDE)

- **Process**: The Story agent breaks down the Epic into appropriately-sized User Stories (3-5 story points max) with Gherkin acceptance criteria and INVEST validation.
- **Agent**: **Story GPT / Story Agent** — Breaks Epics into INVEST-compliant User Stories with AI Autonomy scoring based on Gherkin clarity, complexity, and testability.
- **Output**: User Stories with:
  - Standard format (As a... I want... So that...)
  - Gherkin scenarios (happy path, edge cases, error handling)
  - Business rules and functional examples
  - AI Autonomy Score (0-100)
- **Governance**: Stories are labeled based on AI disposition:
  - `ai-auto` + `agent-ready` (Score ≥80): Eligible for Cloud Agent implementation
  - `ai-assisted` (Score 50-79): Developer-led with AI assistance
  - `ai-human-led` (Score <50): Human-driven implementation

---

### Stage 4: Story Implementation (IDE Agents)

- **Process**: Developers pick up stories and implement using IDE agents. Skills (coding standards, security rules) are automatically injected based on repository topics.
- **Agent**: **Default Cursor/Copilot Agent** + **Distributed Skills** — AI-assisted coding with organization standards automatically applied.
- **Output**: Code changes following org-wide coding standards, security practices, and testing requirements.
- **Dependency**: Skills distributed automatically via GitHub Topics subscription model. Repositories subscribe by adding topics (e.g., `ai-rules-backend-dotnet`).

---

### Stage 5: API Design & Review (IDE Agents)

- **Process**: When building or modifying APIs, the architect agent reviews designs against best practices and generates complete working code.
- **Agent**: **API Architect Agent** — Reviews API design for RESTful principles, security, resilience; generates 3-layer architecture (Service → Manager → Resilience) with Polly patterns.
- **Output**: Complete API scaffolding with circuit breakers, retry policies, bulkhead isolation, or detailed review feedback with prioritized issues.

---

### Stage 6: Testing (IDE Agents)

- **Process**: Agents generate meaningful unit tests focused on business logic validation, not just coverage metrics.
- **Agent**: **Unit Tests Agent / Unit Test Generator** — Creates xUnit/NUnit tests with realistic scenarios, business rule validation, and proper mocking strategies.
- **Output**: Test files with Arrange-Act-Assert pattern, descriptive naming (`MethodName_Condition_ExpectedResult`), and coverage of business-critical paths.

---

### Stage 7: Code Review & PR Management (IDE Agents)

- **Process**: After PR submission, the agent fetches review comments from GitHub and addresses them systematically.
- **Agent**: **Address Comments Agent** — Automatically fetches PR comments, filters out bot comments, prioritizes by severity, and implements fixes with proper commit messages.
- **Output**: Targeted fixes committed with messages referencing the PR and reviewer. Human reviewer comments prioritized; Copilot suggestions filtered by default.

---

### Stage 8: Debugging (IDE Agents)

- **Process**: When bugs are reported, the debug agent follows a systematic 4-phase process: Problem Assessment → Investigation → Resolution → Quality Assurance.
- **Agent**: **Debug Agent** — Systematic debugging with root cause analysis, hypothesis formation, targeted fixes, and verification planning.
- **Output**: Bug fix with documented root cause, verification plan execution, regression test coverage, and preventive recommendations.

---

### Stage 9: Maintenance & Continuous Improvement (IDE Agents)

- **Process**: Ongoing code health maintenance, developer support, and streamlined Git workflows.
- **Agents**:
  - **Janitor Agent** — Performs cleanup, simplification, and tech debt remediation across any codebase.
  - **Mentor Agent** — Provides engineering guidance, best practices support, and learning recommendations.
  - **Git Commit Agent** — Streamlined commit workflow with Conventional Commits format, protected branch warnings, and sensitive data detection.
- **Output**: Cleaner codebase, consistent commit history, and continuous developer education.

---

### Stage 10: Autonomous Implementation (Cloud Agents - Opt-In)

> **Important**: Cloud Agents are **opt-in per team** and only execute when stories meet AI disposition criteria.

- **Process**: For teams that enable Cloud Agents, stories with `agent-ready` label trigger autonomous implementation pipeline: PRD → Solution Design → Backlog → Code.
- **Agents**:
  - **PRD Agent** — Creates comprehensive PRDs with business-functional focus, repository analysis, and full traceability metadata.
  - **Solution Design Agent** — Creates architecture with PLAN→APPROVE→EXECUTE workflow, presenting 2-3 options with tradeoffs before implementation.
  - **Backlog Agent** — Generates separate frontend/backend stories with INVEST compliance, Gherkin criteria, and dependency mapping.
  - **Coding Agent** — Implements `agent-ready` stories with security enforcement, language-specific best practices, and mandatory Playwright screenshot documentation.
- **Output**: Production-ready code with full traceability (Code → Backlog → Design → PRD → Epic), comprehensive test coverage, and visual documentation.
- **Governance**: 
  - Stories must have Autonomy Score ≥80
  - Team must explicitly enable Cloud Agents via `.github/agents/config.yml`
  - Human approval required at design phase (APPROVE step)
  - All code reviewed before merge

**When Cloud Agents Are Used:**
| Criterion | Requirement |
|-----------|-------------|
| Autonomy Score | ≥80 (`ai-auto` + `agent-ready` labels) |
| Team Enablement | `.github/agents/config.yml` present with agents enabled |
| Acceptance Criteria | Clear Gherkin scenarios (Given/When/Then) |
| Complexity | No security-sensitive or novel architecture |
| Human Checkpoint | Design approval before code generation |

---

## 4. Why ChatGPT Enterprise for Product Teams

| Capability | Benefit |
|------------|---------|
| **No IDE Required** | Accessible to Product Owners, Business Analysts, and stakeholders without technical tooling |
| **Atlassian Apps (Rovo Connector)** | Direct integration with Confluence and Jira for research and artifact creation |
| **Microsoft Apps** | SharePoint integration for document storage and collaboration |
| **Web Search** | Market research, competitor analysis, and industry best practices |
| **Custom GPTs** | Team-specific configurations with shared knowledge and workflows |
| **Conversation History** | Maintain context across ideation sessions |
| **Enterprise Security** | Data stays within organizational boundaries |

**ChatGPT Enterprise Custom GPTs:**

| GPT | Purpose | Primary Users |
|-----|---------|---------------|
| Ideation GPT | PRD creation with research | Product Owners |
| Epic GPT | PRD to Jira Epic conversion | Product Owners, Tech Leads |
| Story GPT | Epic to Stories with Autonomy scoring | Product Owners, Tech Leads |

---

## 5. Centralized AI Governance: The Distribution Model

### Single Source of Truth

All AI artifacts are managed in the **Zelis.AI.Studio** repository and distributed automatically to subscriber repositories.

```
Zelis.AI.Studio/
├── agents/           → Custom Agents (IDE + Cloud)
│   ├── *.agent.md    → Agent definitions
│   └── config/       → Team configuration templates
├── chatgpt/          → Custom GPT instructions
│   ├── ideation-gpt/
│   ├── epic-gpt/
│   └── story-gpt/
├── skills/           → Coding standards (distributed via Topics)
├── prompts/          → Reusable prompt templates
├── config/
│   └── topics.yaml   → Topic-to-Skill mapping
└── .github/workflows/
    └── distribute-ai-rules.yml  → Automated distribution
```

### Topic-Based Skill Distribution

Repositories subscribe to skills by adding GitHub Topics. On release, skills are automatically distributed via PR.

```mermaid
flowchart LR
    A[Zelis.AI.Studio] -->|Release| B[Distribution Workflow]
    B --> C{Identify Topics}
    C -->|ai-rules-backend-dotnet| D[.NET Skills]
    C -->|ai-rules-backend-python| E[Python Skills]
    C -->|ai-rules-frontend| F[Frontend Skills]
    C -->|ai-rules-devops| G[DevOps Skills]
    
    D --> H[Subscriber Repo 1]
    D --> I[Subscriber Repo 2]
    E --> J[Subscriber Repo 3]
```

### Skill Categories

| Category | Skills | Distribution |
|----------|--------|--------------|
| **Generic (All Repos)** | sdlc/coding-principles, sdlc/sdlc-principles, security/security-standards, security/secure-coding-enforcement, testing/testing-standards, testing/integration-test-contracts | Automatic to all subscribers |
| **Backend - .NET** | dotnet-backend, csharp-development, dotnet-upgrade | `ai-rules-backend-dotnet` topic |
| **Backend - Python** | python-backend | `ai-rules-backend-python` topic |
| **Backend - TypeScript** | typescript-backend | `ai-rules-backend-typescript` topic |
| **Frontend** | frontend-standards | `ai-rules-frontend` topic |
| **DevOps** | devops-ci-cd, terraform-infrastructure | `ai-rules-devops` topic |
| **Database** | sql-development | `ai-rules-database-sql` topic |

---

## 6. Labels & Governance

### Standard Labels

| Label | Applied To | Purpose |
|-------|------------|---------|
| `ai-generated` | Epic, Story | Indicates artifact was created by AI agent |
| `prd-linked` | Epic | Epic traces back to approved PRD |
| `ai-auto` | Story | AI can implement independently (Score ≥80) |
| `ai-assisted` | Story | AI assists human developer (Score 50-79) |
| `ai-human-led` | Story | Human-led implementation (Score <50) |
| `agent-ready` | Story | Eligible for Cloud Agent implementation |

### Jira Custom Fields

| Field | Type | Purpose |
|-------|------|---------|
| `ai_autonomy_score` | Number | Calculated score (0-100) |
| `ai_disposition` | Select | ai-auto / ai-assisted / human-led |
| `prd_link` | URL | Link to source PRD in Confluence/SharePoint |
| `figma_link` | URL | Link to design specifications |

### Metrics Dashboard

Track AI adoption and effectiveness:

- Stories by Autonomy Label (distribution)
- Agent-Ready Story Completion Rate
- Time-to-Implementation by Autonomy Level
- Skill Coverage by Repository
- PRD-to-Production Traceability

---

## 7. Implementation Roadmap

### Phase 1: ChatGPT Enterprise Rollout
- Deploy Ideation GPT, Epic GPT, Story GPT as Custom GPTs
- Enable Atlassian Apps (Rovo Connector) for Confluence/Jira integration (Feb 2nd)
- Train Product Owners on PRD creation workflow
- Establish team-config.yml templates

### Phase 2: Skill Distribution
- Configure GitHub Topics on subscriber repositories
- Execute initial skill distribution release
- Monitor skill adoption and compliance
- Refine topic-to-skill mappings based on feedback

### Phase 3: IDE Agent Adoption
- Distribute agent files to development teams
- Enable Rovo MCP in Cursor/Copilot environments (Work with ZEDI team)
- Establish Agent workflows

### Phase 4: Cloud Agent Enablement (Opt-In)
- Pilot Cloud Agents with volunteer teams
- Establish `agent-ready` criteria and scoring thresholds
- Create `.github/agents/config.yml` templates
- Measure autonomous implementation success rates

### Phase 5: Multi-Agent Orchestration
- Establish orchestration patterns for long-horizon work using Cursor multi-agent features (Preview)
- Build subagent coordination best practices

---
