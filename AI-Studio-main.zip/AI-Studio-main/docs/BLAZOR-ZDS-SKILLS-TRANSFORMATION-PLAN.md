# Blazor & ZDS Skills Transformation Plan

> **Source Project:** Payor-Maintenance (`E:\PayorMaintenanceModern\01addspeckit\Payor-Maintenance`)
> **Target Project:** Zelis.AI.Studio
> **Created:** January 28, 2026
> **Updated:** January 28, 2026
> **Status:** Phase 1 & 2 Complete
> **Branch:** `feat/blazor-zds-skills`
> **Commit:** `7edb09f`

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [Source Analysis](#source-analysis)
3. [Transformation Strategy](#transformation-strategy)
4. [New Skills Specification](#new-skills-specification)
5. [New Agents Specification](#new-agents-specification)
6. [Topic Mapping Updates](#topic-mapping-updates)
7. [Implementation Phases](#implementation-phases)
8. [Migration Checklist](#migration-checklist)

---

## Executive Summary

### Objective

Transform project-specific Blazor and ZDS (Zelis Design System) skills from Payor-Maintenance into reusable, enterprise-wide skills for distribution via Zelis.AI.Studio.

### Scope

| Category | Source Count | Generalizable | New Skills |
|----------|--------------|---------------|------------|
| Blazor Core Skills | 6 | 6 | 2-3 |
| ZDS Component Skills | 25+ | 15+ | 1-2 |
| Domain Agents | 9 | 5 | 3-4 |
| Spec Kit Agents | 8 | 8 | Consider separate distribution |

### Key Decisions Made

| Decision | Resolution |
|----------|------------|
| ZDS skills distribution | Opt-in via separate `ai-rules-design-zds` topic |
| Blazor skills and ZDS | Kept separate - Blazor skills are framework-agnostic |
| Spec Kit workflow agents | Deferred to Phase 3 for evaluation |

---

## Source Analysis

### Payor-Maintenance Skills Structure

```
.claude/skills/
├── Blazor Core (6 skills)
│   ├── blazor-component-structure/
│   ├── blazor-adapter/
│   ├── razor-file-organization/
│   ├── viewmodel-integration/
│   ├── async-event-handling/
│   └── dependency-injection/
│
├── ZDS Foundation (6 skills)
│   ├── zds-colors/
│   ├── zds-typography/
│   ├── zds-grid/
│   ├── zds-spacing/
│   ├── zds-icons/
│   └── zds-image/
│
├── ZDS Components (19+ skills)
│   ├── zds-button/
│   ├── zds-card/
│   ├── zds-modal/
│   ├── zds-table/
│   ├── zds-form-controls/
│   ├── zds-toast/
│   ├── zds-accordion/
│   ├── zds-alert/
│   ├── zds-avatar/
│   ├── zds-badge/
│   ├── zds-button-group/
│   ├── zds-navbar/
│   ├── zds-offcanvas/
│   ├── zds-placeholder/
│   ├── zds-popover/
│   ├── zds-progress/
│   ├── zds-spinner/
│   ├── zds-tabs/
│   └── ... more
│
└── Project-Specific (not generalizable)
    ├── pm-claim-overview-card/
    ├── pm-copy-to-clipboard/
    ├── pm-sidebar-nav/
    ├── pm-status-note-accordion/
    └── pm-tag-management/
```

### What's Project-Specific vs Generalizable

#### Project-Specific (DO NOT generalize)

| Element | Example | Reason |
|---------|---------|--------|
| Namespaces | `PayorMaintenance.UI.Components` | Project-specific |
| Models | `DRGModel`, `SubGroupViewModel` | Domain-specific |
| Services | `SubGroupUIService`, `PayorUIService` | Business logic |
| Components | `pm-*` prefixed skills | Project patterns |
| Specific models | `ContactInfoModel`, `PayorGeneralDto` | Domain entities |

#### Generalizable (SHOULD transform)

| Element | Example | Reason |
|---------|---------|--------|
| Patterns | Dual-file structure, MVVM | Universal Blazor |
| Naming conventions | `{Feature}VM`, `On{Action}Clicked` | Reusable standards |
| DI patterns | `[Inject]`, service layers | .NET standard |
| Async patterns | `async Task`, cancellation | .NET standard |
| ZDS classes | `btn-primary`, `card`, `modal` | Company design system |
| Accessibility | ARIA, keyboard nav | Universal |

---

## Transformation Strategy

### Approach: Layered Generalization

```
┌─────────────────────────────────────────────────────────┐
│                    Generic Patterns                      │
│  (blazor-frontend, blazor-mvvm - no company specifics)  │
├─────────────────────────────────────────────────────────┤
│                  Company Standards                       │
│      (zds-design-system - Zelis-specific styling)       │
├─────────────────────────────────────────────────────────┤
│                 Project Overrides                        │
│     (Stays in individual repos - not distributed)       │
└─────────────────────────────────────────────────────────┘
```

### Generalization Rules

1. **Replace specific namespaces** with `{ProjectRoot}` placeholders
2. **Replace specific models** with generic examples (`{ModelType}`, `{Entity}`)
3. **Replace specific services** with interface patterns (`I{Feature}Service`)
4. **Keep design system references** in separate ZDS skill (opt-in)
5. **Extract universal patterns** that apply to any Blazor project

---

## New Skills Specification

### Skill 1: `blazor-frontend`

**Purpose:** Core Blazor component development patterns (framework-agnostic)

**File:** `skills/blazor/blazor-frontend/SKILL.md`

**Frontmatter (follows project schema exactly):**

```yaml
---
name: blazor-frontend
description: |
  Blazor frontend development standards. Use when writing Blazor components,
  Razor files, component lifecycle code, or Blazor Server/WebAssembly applications.
  Covers component structure, code-behind patterns, event handling, and DI.
disposition: contextual
filePatterns:
  - "**/*.razor"
  - "**/*.razor.cs"
version: 1.0.0
---
```

> **Note:** No `compliance` field with WCAG - schema only supports `soc2`, `iso27001`, `hipaa`.
> Version is unquoted per existing skill patterns (e.g., `csharp-development`).

**Content Sections (using MUST/SHOULD/MUST NOT pattern):**

```markdown
# Blazor Frontend Development Standards

## Core Requirements

- **MUST** use dual-file component structure (`.razor` + `.razor.cs` code-behind)
- **MUST NOT** use `@code` blocks in `.razor` files
- **MUST** follow PascalCase for component and method names
- **MUST** use `[Inject]` attribute for dependency injection

## Component Structure

| Element | Convention | Example |
|---------|------------|---------|
| Components | `PascalCase` | `UserProfile`, `DataGrid` |
| Event handlers | `On{Action}{Context}` | `OnSaveClicked`, `OnFilterChanged` |
| Parameters | Descriptive names | `UserId`, `IsEnabled` |
| Private fields | `camelCase` | `_userService`, `_isLoading` |

## Code-Behind Organization

- **MUST** organize members in this order:
  1. Injected services (`[Inject]`)
  2. Parameters (`[Parameter]`)
  3. Private fields
  4. Lifecycle methods
  5. Event handlers
  6. Private methods

## Lifecycle Methods

- **SHOULD** use async versions when performing I/O operations
- **MUST** call `StateHasChanged()` only when necessary
- **MUST NOT** perform heavy operations in `OnInitialized` (use `OnInitializedAsync`)

## Event Handling

- **MUST** use `async Task` for async event handlers (not `async void`)
- **MUST** use `EventCallback<T>` for component communication
- **SHOULD** support cancellation tokens for long-running operations

## Dependency Injection

- **MUST** use `[Inject]` attribute for service injection
- **MUST** use `default!` for non-nullable injected services
- **MUST** place injected services at the top of the class

## Anti-Patterns

- **MUST NOT** use `.Result` or `.Wait()` on async operations
- **MUST NOT** use empty catch blocks
- **MUST NOT** mix business logic with UI code in code-behind
```

---

### Skill 2: `blazor-mvvm`

**Purpose:** ViewModel integration patterns for Blazor components

**File:** `skills/blazor/blazor-mvvm/SKILL.md`

**Frontmatter (follows project schema exactly):**

```yaml
---
name: blazor-mvvm
description: |
  Blazor MVVM and ViewModel patterns. Use when implementing ViewModels,
  UI services, or separating UI state from components. Covers ViewModel
  structure, UI service layer, and testability patterns.
disposition: contextual
filePatterns:
  - "**/*ViewModel.cs"
  - "**/*VM.cs"
  - "**/ViewModels/**/*.cs"
  - "**/*UIService.cs"
version: 1.0.0
---
```

**Content Sections (using MUST/SHOULD/MUST NOT pattern):**

```markdown
# Blazor MVVM Patterns

## Core Principles

- **MUST** keep UI state in ViewModel, not in code-behind
- **MUST** use flat ViewModel structure (no nested state classes)
- **SHOULD** move business logic to ViewModel for testability
- **MUST NOT** expose DTOs directly as ViewModel properties

## ViewModel Structure

| Element | Convention | Example |
|---------|------------|---------|
| Class naming | `{Feature}ViewModel` or `{Feature}VM` | `UserProfileViewModel` |
| Properties | UI state only | `IsLoading`, `ErrorMessage` |
| Methods | UI logic | `ValidateForm()`, `ResetState()` |
| Interface | `I{Feature}UIService` | `IUserUIService` |

## ViewModel Implementation

- **MUST** use properties for all UI state
- **MUST** initialize collections to empty (not null)
- **SHOULD** use `INotifyPropertyChanged` when needed
- **MUST NOT** include HTTP calls directly (use UI Service)

## UI Service Layer

- **MUST** create `I{Feature}UIService` interface for each feature
- **MUST** handle DTO to UI Model mapping in service
- **MUST** handle API calls and error transformation
- **SHOULD** return UI-friendly error messages

## Code-Behind Guidelines

- **SHOULD** keep code-behind under 300 lines
- **MUST** delegate complex logic to ViewModel
- **SHOULD** use `[ExcludeFromCodeCoverage]` for simple delegation methods
- **MUST NOT** contain business logic

## When to Use ViewModel

| Scenario | Approach |
|----------|----------|
| Simple display (< 5 properties) | Direct binding |
| Forms with validation | ViewModel |
| Complex state management | ViewModel |
| Shared state across components | ViewModel + DI |

## Testing

- **MUST** unit test ViewModel logic independently
- **MUST** mock UI services in ViewModel tests
- **SHOULD** verify state changes after method calls
```

---

### Skill 3: `zds-design-system`

**Purpose:** Zelis Design System (ZDS) component usage and styling standards

**File:** `skills/design-system/zds-design-system/SKILL.md`

**Frontmatter (follows project schema exactly):**

```yaml
---
name: zds-design-system
description: |
  Zelis Design System (ZDS) standards. Use when implementing UI components
  with ZDS styling, Bootstrap-based layouts, or company design guidelines.
  Covers component classes, color palette, typography, and accessibility.
disposition: contextual
filePatterns:
  - "**/*.razor"
  - "**/*.cshtml"
  - "**/*.css"
  - "**/*.scss"
version: 1.0.0
---
```

**Content Sections (using MUST/SHOULD/MUST NOT pattern):**

```markdown
# Zelis Design System (ZDS) Standards

## Core Principles

- **MUST** use Bootstrap 5 as the foundation
- **MUST** follow simplicity-first approach
- **MUST** ensure WCAG 2.1 AA accessibility compliance
- **MUST** use ZDS-approved component patterns

## Button Standards

- **MUST** use `btn-sm` size for all buttons
- **MUST** use `btn-primary` for primary actions
- **MUST** use `btn-outline-secondary` for secondary actions

| Action Type | Classes |
|-------------|---------|
| Primary | `btn btn-primary btn-sm` |
| Secondary | `btn btn-outline-secondary btn-sm` |
| Danger | `btn btn-danger btn-sm` |

## Card Standards

- **MUST** use standard card structure with `card-body`
- **MUST NOT** use `shadow-sm` on cards
- **MUST NOT** use `border-0` on cards
- **MUST NOT** use `fw-semibold` on card titles

## Form Controls

- **MUST** use `form-control-sm` for all inputs
- **MUST** use `form-select-sm` for all selects
- **SHOULD** use `form-label` for labels

## Color Palette

- **MUST** use semantic color classes: `primary`, `secondary`, `success`, `danger`, `warning`, `info`
- **MUST** use `bg-*` for backgrounds, `text-*` for text colors
- **SHOULD** use `text-bg-*` for combined background and text

## Typography

- **MUST** use semantic heading tags (`h1`-`h6`)
- **SHOULD** use `<small>` for secondary labels
- **MUST NOT** use `fw-bold` for labels (use `<small>` instead)

## Grid and Layout

- **SHOULD** prefer `col-auto` with `flex-wrap` for flexible layouts
- **MUST** use `gap-*` utilities for spacing between flex items
- **SHOULD** use `g-3` as standard gutter size

## Spacing

- **MUST** use Bootstrap spacing scale (0-5 plus auto)
- **SHOULD** use `px-3 py-2` for compact toolbar padding
- **SHOULD** use `mb-3` for form group margins

## Common Patterns

### Action Button Groups

- **MUST** use `d-flex gap-2` for button groups
- **MUST** place primary action first

### Card Grids

- **SHOULD** use `row-cols-*` for responsive card grids
- **SHOULD** use `g-3` gutter for card spacing

## Accessibility

- **MUST** include `aria-label` on icon-only buttons
- **MUST** support keyboard navigation
- **MUST** maintain color contrast compliance
- **SHOULD** use `role` attributes where semantic HTML is insufficient
```

---

## New Agents Specification

### Agent 1: `blazor-component.agent.md`

**Purpose:** Blazor component generation and Figma-to-code translation

**Based on:** `ui-razor.agent.md` from Payor-Maintenance

**Generalization:**
- Remove PM-specific model references
- Make design system configurable
- Keep Figma translation patterns
- Keep accessibility requirements

---

### Agent 2: `architecture-dotnet.agent.md`

**Purpose:** .NET architecture standards, SOLID, Clean Architecture

**Based on:** `architecture.agent.md` from Payor-Maintenance

**Generalization:**
- Remove project-specific namespaces
- Keep SOLID principles
- Keep Clean Architecture boundaries
- Keep modern C# guidelines

---

### Agent 3: `database-sql.agent.md`

**Purpose:** SQL/T-SQL standards, naming conventions, schema design

**Based on:** `database.agent.md` from Payor-Maintenance

**Generalization:**
- Already highly generalizable
- Keep naming conventions (PK_, FK_, IX_)
- Keep formatting standards
- Add support for different SQL dialects

---

### Agent 4: `xunit-testing.agent.md`

**Purpose:** Unit test generation with AAA pattern

**Based on:** `xunit-testing.agent.md` from Payor-Maintenance

**Note:** Already exists in Zelis.AI.Studio as `unit-test-generator.agent.md` - consider merging patterns

---

## Topic Mapping Updates

### Proposed Updates to `config/topics.yaml`

Following the existing structure in `topics.yaml`, add under the `topics:` section:

```yaml
# Existing topics (for reference)
topics:
  ai-rules-backend-python:
    - python-backend

  ai-rules-backend-dotnet:
    - dotnet-backend
    - csharp-development
    - dotnet-upgrade

  ai-rules-frontend:
    - frontend-standards

  # NEW: Blazor frontend topic
  ai-rules-frontend-blazor:
    - blazor-frontend
    - blazor-mvvm

  # NEW: ZDS design system topic (separate for flexibility)
  ai-rules-design-zds:
    - zds-design-system
```

> **Note:** The existing `ai-rules-frontend` topic provides `frontend-standards`.
> Blazor projects would subscribe to BOTH `ai-rules-frontend` and `ai-rules-frontend-blazor`.

### Distribution Options

| Option | Blazor Skills | ZDS Skills | Pros | Cons |
|--------|---------------|------------|------|------|
| A | `ai-rules-frontend-blazor` | Included | Simple, one topic | Forces ZDS on all Blazor projects |
| B | `ai-rules-frontend-blazor` | `ai-rules-design-zds` | Flexible | Two topics needed |
| C | Add to `ai-rules-backend-dotnet` | Separate topic | Leverages existing | Mixes backend/frontend |

**Recommendation:** Option B - Separate topics for flexibility

### Subscription Examples

A Blazor project using ZDS would add these GitHub topics:
- `ai-rules-frontend` (general frontend standards)
- `ai-rules-frontend-blazor` (Blazor-specific)
- `ai-rules-design-zds` (ZDS styling)
- `ai-rules-backend-dotnet` (if also has .NET backend)

---

## Implementation Phases

### Phase 1: Core Blazor Skills - COMPLETED

- [x] Create `skills/blazor/blazor-frontend/SKILL.md` (~200 lines)
- [x] Create `skills/blazor/blazor-mvvm/SKILL.md` (~200 lines)
- [x] Update `config/topics.yaml` with `ai-rules-frontend-blazor`
- [x] Run `npm run lint` to validate (32 skills, 0 errors)
- [x] Commit and push to `feat/blazor-zds-skills` branch

**Skills Created:**
| Skill | Lines | Content Coverage |
|-------|-------|------------------|
| `blazor-frontend` | ~200 | Component structure, code-behind, lifecycle, events, DI, data binding |
| `blazor-mvvm` | ~200 | ViewModel patterns, 9 MVVM rules, UI services, data flow, testability |

### Phase 2: ZDS Design System - COMPLETED

- [x] Create `skills/design-system/zds-design-system/SKILL.md` (~250 lines)
- [x] Extract key patterns from 25+ ZDS component skills
- [x] Consolidate into single comprehensive skill
- [x] Add `ai-rules-design-zds` topic
- [x] Validate with lint

**Skills Created:**
| Skill | Lines | Content Coverage |
|-------|-------|------------------|
| `zds-design-system` | ~250 | Buttons, cards, forms, tables, modals, colors, typography, spacing, accessibility |

### Phase 3: Agents - PENDING

- [ ] Generalize `blazor-component.agent.md`
- [ ] Generalize `architecture-dotnet.agent.md`
- [ ] Review existing agents for overlap
- [ ] Add to `agents/` directory

### Phase 4: Testing & Documentation - PENDING

- [ ] Test distribution to sample repo
- [ ] Update SUBSCRIPTION.md with new topics
- [ ] Update README.md with new skills
- [ ] Create HowTo guides if needed

### Phase 5: Release - PENDING

- [ ] Create PR with all changes
- [ ] Review with stakeholders
- [ ] Merge and create release
- [ ] Trigger distribution to subscribers

---

## Migration Checklist

### Pre-Migration - COMPLETED

- [x] Review all source skills in Payor-Maintenance
- [x] Identify all project-specific references
- [x] Document transformation rules
- [x] Get stakeholder approval on scope

### During Migration - COMPLETED

- [x] Create skills one at a time
- [x] Validate each with `npm run lint`
- [x] Test in local IDE before committing
- [x] Keep source skills as reference

### Post-Migration - PENDING

- [ ] Verify distribution works
- [ ] Update Payor-Maintenance to use distributed skills
- [ ] Remove duplicate local skills from Payor-Maintenance
- [ ] Document any project-specific overrides needed

---

## Appendix A: Source Skill Analysis Details

### Blazor Core Skills Summary

| Skill | Lines | Project-Specific | Generalizable |
|-------|-------|------------------|---------------|
| blazor-component-structure | ~150 | 30% | 70% |
| blazor-adapter | ~200 | 20% | 80% |
| razor-file-organization | ~80 | 0% | 100% |
| viewmodel-integration | ~250 | 40% | 60% |
| async-event-handling | ~120 | 25% | 75% |
| dependency-injection | ~100 | 30% | 70% |

### ZDS Component Skills Summary

| Category | Count | Consolidation Strategy |
|----------|-------|------------------------|
| Foundation (colors, typography, grid, spacing) | 6 | Merge into single section |
| Atoms (button, badge, avatar, spinner) | 8 | Merge into components section |
| Molecules (card, modal, table, form) | 11 | Merge into components section |
| Project-specific (pm-*) | 5 | Do not migrate |

---

## Appendix B: Transformation Examples

### Before (Project-Specific)

```csharp
// Payor-Maintenance specific
namespace PayorMaintenance.UI.Components.SubGroup
{
    public partial class SubGroupBasicInfo : ComponentBase
    {
        [Inject] private ISubGroupUIService SubGroupService { get; set; } = default!;
        [Parameter] public SubGroupViewModel SubGroupVM { get; set; } = default!;
    }
}
```

### After (Generalized)

```csharp
// Generalized pattern
namespace {ProjectRoot}.UI.Components.{Feature}
{
    public partial class {Feature}Section : ComponentBase
    {
        [Inject] private I{Feature}UIService {Feature}Service { get; set; } = default!;
        [Parameter] public {Feature}ViewModel {Feature}VM { get; set; } = default!;
    }
}
```

---

## Appendix C: Related Documents

- [AUTO-DETECT-SKILLS-DISTRIBUTION-PLAN.md](./AUTO-DETECT-SKILLS-DISTRIBUTION-PLAN.md) - Auto-detection system
- [PROJECT_ANALYSIS.md](../PROJECT_ANALYSIS.md) - Full project analysis
- [SUBSCRIPTION.md](../SUBSCRIPTION.md) - Subscription model
- [CONTRIBUTING.md](../CONTRIBUTING.md) - How to add skills

---

## Appendix D: Implementation Log

### January 28, 2026

**Phase 1 & 2 Completed:**

1. Created `skills/blazor/blazor-frontend/SKILL.md`
   - Extracted patterns from 6 Blazor core skills
   - Generalized all project-specific references
   - ~200 lines covering components, lifecycle, events, DI

2. Created `skills/blazor/blazor-mvvm/SKILL.md`
   - Consolidated ViewModel integration patterns
   - Documented the 9 MVVM rules
   - ~200 lines covering ViewModels, UI services, testability

3. Created `skills/design-system/zds-design-system/SKILL.md`
   - Consolidated 25+ ZDS component skills into one
   - ~250 lines covering all major Bootstrap 5 components
   - Documented ZDS-specific restrictions (no shadow-sm, btn-sm required, etc.)

4. Updated `config/topics.yaml`
   - Added `ai-rules-frontend-blazor` topic
   - Added `ai-rules-design-zds` topic

5. Validation
   - Ran `npm run lint` - 32 skills validated, 0 errors
   - Pre-commit hooks passed

6. Git Operations
   - Created branch `feat/blazor-zds-skills`
   - Committed: `7edb09f`
   - Pushed to origin

**Next Steps:**
- Create PR for review
- Proceed to Phase 3 (Agents) if approved
- Test distribution to a sample repository

---

*This document will be updated as implementation progresses.*
