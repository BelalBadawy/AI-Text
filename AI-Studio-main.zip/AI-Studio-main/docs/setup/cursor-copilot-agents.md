# Cursor/Copilot Custom Agents Setup Guide

This guide walks you through setting up the two Custom Agents for the Tech Lead workflow:
1. **Epic Agent** - Create technical Epics (PRD-based or standalone)
2. **Story Agent** - Break Epics into User Stories with Autonomy scoring

## Prerequisites

Before you begin, ensure you have:

- [ ] Cursor IDE installed with Copilot access
- [ ] Rovo MCP enabled in Cursor settings
- [ ] Access to this repository (Zelis.AI.Studio)
- [ ] Access to your team's Jira project
- [ ] Access to your team's Confluence space (for PRD-based Epics)

## Step 1: Clone the Repository

If you haven't already, clone the Zelis.AI.Studio repository:

```bash
git clone https://github.com/your-org/Zelis.AI.Studio.git
cd Zelis.AI.Studio
```

## Step 2: Configure Team Settings

### 2.1 Copy the Template

```bash
cp agents/config/team-config.yml agents/config/team-config.local.yml
```

### 2.2 Edit Your Configuration

Open `agents/config/team-config.local.yml` and fill in your team's values:

```yaml
team:
  name: "Your Team Name"
  workday_id: "WD-12345"           # Your team's Workday identifier
  business_vertical: "Healthcare"   # Your business vertical
  
  confluence:
    space_key: "YOUR_SPACE"
    space_id: "12345"
    default_parent_page_id: "98765"
  
  jira:
    project_key: "YOUR_PROJECT"
    project_id: "10001"
    board_id: "42"
    epic_issue_type_id: "10000"
    story_issue_type_id: "10001"

labels:
  standard:
    - "ai_generated"
    - "prd_linked"
  custom:
    - "your_team"
    - "q1_2026"

story_quality:
  max_story_points: 5
  min_story_points: 1
  autonomy_threshold_autonomous: 80
  autonomy_threshold_assisted: 50
  require_gherkin: true
  require_invest_validation: true

custom_fields:
  prd_link: "customfield_10100"
  ai_autonomy_score: "customfield_10101"
  ai_autonomy_label: "customfield_10102"
  figma_link: "customfield_10103"
```

### 2.3 Find Your Jira IDs

For detailed instructions on finding all Atlassian IDs, see the comprehensive guide in [docs/setup/chatgpt-custom-gpts.md](chatgpt-custom-gpts.md#finding-atlassian-ids).

**Quick Reference**:

| ID | Where to Find |
|----|---------------|
| `project_key` | Issue key prefix (e.g., `PROJ` from `PROJ-123`) |
| `project_id` | Project Settings → Details |
| `board_id` | URL: `/boards/42` |
| `epic_issue_type_id` | REST API: `GET /rest/api/3/issuetype` |
| `story_issue_type_id` | REST API: `GET /rest/api/3/issuetype` |
| `space_key` | URL: `/wiki/spaces/MYSPACE/...` |
| `space_id` | Space Settings → Space Details |

**Project ID**:
1. Go to your Jira project settings
2. Look at the URL: `https://your-domain.atlassian.net/jira/software/projects/PROJ/settings`
3. Or use Jira API: `GET /rest/api/3/project/PROJ`

**Issue Type IDs**:
1. Go to Project Settings → Issue Types
2. Or use Jira API: `GET /rest/api/3/issuetype`

**Custom Field IDs**:
1. Go to Settings → Issues → Custom Fields
2. Click on each field to see its ID in the URL
3. Or use Jira API: `GET /rest/api/3/field`

## Step 3: Enable Rovo MCP in Cursor

### 3.1 Open Cursor Settings

1. Open Cursor
2. Go to **Settings** (Cmd/Ctrl + ,)
3. Search for "MCP" or navigate to Extensions → MCP

### 3.2 Enable Rovo MCP

1. Find **Atlassian Rovo** in the MCP providers list
2. Enable it
3. Authenticate with your Atlassian account
4. Grant necessary permissions for Jira and Confluence

### 3.3 Verify MCP Connection

In Cursor chat, try:
```
@mcp What Jira projects can I access?
```

If successful, you should see a list of your accessible projects.

## Step 4: Using the Agents

### 4.1 Using Epic Agent

The Epic Agent creates technical Epics from PRDs or as standalone work items.

**Invoke the agent**:
```
@agents/epic-agent.agent.md
```

**Mode 1: Create Epic from PRD**
```
Create an Epic from this PRD: https://your-confluence.atlassian.net/wiki/spaces/SPACE/pages/12345
```

**Mode 2: Create Standalone Epic**
```
Create a technical Epic for: Migrate authentication service from OAuth1 to OAuth2
```

**The agent will**:
1. Ask clarifying questions
2. Generate an Epic using CREATE framework
3. Present for your review
4. Create in Jira after approval

### 4.2 Using Story Agent

The Story Agent breaks down Epics into User Stories with Autonomy scoring.

**Invoke the agent**:
```
@agents/story-agent.agent.md
```

**Break down an Epic**:
```
Break down Epic PROJ-123 into stories
```

Or:
```
Create stories from this Epic: https://your-jira.atlassian.net/browse/PROJ-123
```

**The agent will**:
1. Fetch the Epic from Jira
2. Generate stories with Gherkin acceptance criteria
3. Calculate Autonomy scores
4. Present for your review
5. Create stories in Jira after approval

## Step 5: Workflow Examples

### Example 1: PRD-Based Feature

```
You: @agents/epic-agent.agent.md Create an Epic from this PRD: 
     https://confluence.example.com/wiki/spaces/PROD/pages/12345

Agent: I've read the PRD for "Digital Member ID Card". Here's my summary:
       [Summary]
       Ready to create the Epic?

You: Yes, proceed

Agent: Here's the Epic using CREATE framework:
       [Full Epic content]
       Please review. Any adjustments?

You: Looks good, create it

Agent: ✓ Created Epic PROJ-456 in Jira
       URL: https://jira.example.com/browse/PROJ-456
       
       Next: Use Story Agent to break this down into stories.

You: @agents/story-agent.agent.md Break down PROJ-456

Agent: I've analyzed Epic PROJ-456. Here are 6 stories:
       [Story breakdown with autonomy scores]
       
       Agent-Ready (3): US-001, US-003, US-005
       Assisted (2): US-002, US-004
       Human-Driven (1): US-006
       
       Approve creation?

You: Yes

Agent: ✓ Created 6 stories linked to PROJ-456
```

### Example 2: Standalone Technical Epic

```
You: @agents/epic-agent.agent.md

Agent: Would you like to:
       1. Create an Epic from a PRD (provide URL)
       2. Create a standalone technical Epic (describe the work)

You: 2 - I need to upgrade our .NET Core 3.1 services to .NET 8

Agent: Creating a Tech Debt Epic. Let me gather details:
       - What services are affected?
       - What's the timeline pressure?
       - Are there known blockers?

You: All 5 microservices in the Payment domain. Need done before .NET 3.1 EOL.
     Main blocker is EntityFramework Core compatibility.

Agent: Here's the Epic:
       [Tech Debt Epic with CREATE framework]
       
       Ready to create?
```

## Troubleshooting

### Agent Not Found

**Symptom**: "Cannot find agent" error

**Solution**:
1. Ensure you're in the Zelis.AI.Studio repository
2. Check the file path: `agents/epic-agent.agent.md`
3. Verify the file exists and has correct frontmatter

### Rovo MCP Not Working

**Symptom**: Jira/Confluence commands fail

**Solution**:
1. Check MCP is enabled: Settings → MCP
2. Re-authenticate with Atlassian
3. Verify permissions in Atlassian admin
4. Check Cursor logs for MCP errors

### Configuration Not Loading

**Symptom**: Agent doesn't use team settings

**Solution**:
1. Verify `agents/config/team-config.yml` exists
2. Check YAML syntax with a validator
3. Ensure file is in the repository (not just local)

### Epic/Story Creation Fails

**Symptom**: Items not created in Jira

**Solution**:
1. Verify project key is correct
2. Check issue type IDs match your Jira configuration
3. Ensure custom fields exist in your project
4. Review required fields in Jira project settings

### Autonomy Scores Seem Wrong

**Symptom**: Scores don't reflect complexity

**Solution**:
1. Review the scoring criteria in Story Agent
2. Adjust thresholds in team-config.yml
3. Ensure Gherkin scenarios are complete
4. Check for missing complexity deductions

## Best Practices

### For Tech Leads

1. **Use standalone Epics** for technical work without PRDs
2. **Review autonomy scores** before sprint planning
3. **Break down high-complexity stories** further
4. **Keep team config updated** when Jira changes

### For Efficient Workflows

1. **Create Epic first**, then immediately use Story Agent
2. **Review stories in batches** rather than one-by-one
3. **Use agent handoffs** for seamless Epic → Story flow
4. **Standardize business vocabulary** across team

### For Quality

1. **Always review before approving** Jira creation
2. **Verify Gherkin scenarios** cover edge cases
3. **Check autonomy deductions** are appropriate
4. **Ensure stories are 3-5 points** maximum

## Quick Reference

### Agent Commands

| Task | Command |
|------|---------|
| Create PRD-based Epic | `@agents/epic-agent.agent.md Create Epic from: [URL]` |
| Create Standalone Epic | `@agents/epic-agent.agent.md Create Epic for: [description]` |
| Break Down Epic | `@agents/story-agent.agent.md Break down PROJ-123` |

### Autonomy Labels

| Score | Label | Meaning |
|-------|-------|---------|
| 80-100 | `autonomy_autonomous` | AI can implement independently |
| 50-79 | `autonomy_assisted` | AI needs human guidance |
| <50 | `autonomy_human` | Human should lead |

### File Locations

```
Zelis.AI.Studio/
  agents/
    config/
      team-config.yml          # Template
      team-config.local.yml    # Your settings (gitignored)
    epic-agent.agent.md        # Epic Agent
    story-agent.agent.md       # Story Agent
```

## Support

For issues with:
- **Agent behavior**: Review agent markdown files
- **Rovo MCP**: Check Cursor MCP settings
- **Jira/Confluence**: Contact Atlassian admin
- **Configuration**: Validate YAML syntax
