# ChatGPT Enterprise Custom GPTs Setup Guide

This guide walks you through setting up the three Custom GPTs for the Product Owner workflow:
1. **Ideation GPT** - Create PRDs from ideas
2. **Epic GPT** - Convert PRDs to Jira Epics
3. **Story GPT** - Break Epics into User Stories

## Prerequisites

Before you begin, ensure you have:

- [ ] ChatGPT Enterprise account with Custom GPT creation permissions
- [ ] Rovo Connector enabled (for Atlassian - Jira/Confluence)
- [ ] Microsoft Connector enabled (for SharePoint)
- [ ] Access to your team's Confluence space
- [ ] Access to your team's Jira project
- [ ] Access to your team's SharePoint site (optional)

## Step 1: Prepare Team Configuration

1. Copy the template from `agents/config/team-config.yml`
2. Reference `agents/config/team-config.example.yml` for a complete example (Price Labs)
3. Fill in your team's specific values (see "Finding Atlassian IDs" section below)
4. Save the file - you'll upload it to each GPT's Knowledge section

```yaml
# Team Identity
team:
  name: "Your Team Name"
  workday_id: "WD-12345"
  business_vertical: "Price Optimization"

# Jira Configuration
jira:
  site_base_url: "https://your-domain.atlassian.net"
  project_key: "PROJ"
  board_id: "42"
  issue_types:
    epic: "10000"
    story: "10009"
    subtask: "10007"

# Confluence Configuration
confluence:
  base_url: "https://your-domain.atlassian.net/wiki"
  space_key: "CM"
  space_name: "Documentation"
  prd_parent_page:
    page_id: "1735164156"
    page_name: "PRDs"
  page_title_pattern: "PRD: {{PRD Title}}"
  page_labels:
    - "prd"
    - "ai-generated"
  publish_behavior: "draft"
```

**Note**: Due to ChatGPT's ~8000 character instruction limit, team configuration is uploaded as a file attachment rather than pasted into instructions.

---

## Finding Atlassian IDs

This section explains how to find the required Jira and Confluence IDs for your team configuration.

### Confluence IDs

#### Space Key

The Space Key is visible in the URL of any page in your space:

```
https://your-domain.atlassian.net/wiki/spaces/MYSPACE/pages/12345/Page+Title
                                            ^^^^^^^
                                            Space Key
```

#### Space ID

1. Go to your Confluence space
2. Click **Space Settings** (gear icon) → **Space Details**
3. The Space ID is shown on the details page

**Alternative**: Use the Confluence REST API:
```
GET https://your-domain.atlassian.net/wiki/rest/api/space/MYSPACE
```

**Documentation**: [Find your Space ID](https://support.atlassian.com/confluence-cloud/docs/find-your-space-id/)

#### Page ID (for default_parent_page_id)

The Page ID is visible in the URL when viewing a page:

```
https://your-domain.atlassian.net/wiki/spaces/MYSPACE/pages/123456789/Page+Title
                                                       ^^^^^^^^^
                                                       Page ID
```

---

### Jira IDs

#### Project Key

The Project Key is the prefix used in issue keys:

```
Issue key: PROJ-123
           ^^^^
           Project Key
```

Also visible in project URLs:
```
https://your-domain.atlassian.net/jira/software/projects/PROJ/boards/42
                                                          ^^^^
                                                          Project Key
```

#### Project ID

1. Go to your Jira project
2. Click **Project Settings** (gear icon in sidebar)
3. Go to **Details**
4. The Project ID is shown on this page

**Alternative**: Use the Jira REST API:
```
GET https://your-domain.atlassian.net/rest/api/3/project/PROJ
```

Response includes: `"id": "10001"`

**Documentation**: [Find your Project ID](https://support.atlassian.com/jira-cloud-administration/docs/find-your-site-id/)

#### Board ID

The Board ID is visible in the board URL:

```
https://your-domain.atlassian.net/jira/software/projects/PROJ/boards/42
                                                                     ^^
                                                                     Board ID
```

#### Epic Issue Type ID

To find the Issue Type ID for Epics:

**Method 1: Jira Admin (Recommended)**
1. Go to **Jira Settings** (gear icon) → **Issues** → **Issue Types**
2. Click on **Epic**
3. The ID is in the URL: `/secure/admin/EditIssueType!default.jspa?id=10000`

**Method 2: REST API**
```
GET https://your-domain.atlassian.net/rest/api/3/issuetype
```

Response includes all issue types with their IDs:
```json
[
  { "id": "10000", "name": "Epic", ... },
  { "id": "10001", "name": "Story", ... },
  { "id": "10002", "name": "Task", ... }
]
```

**Method 3: Project-specific Issue Types**
```
GET https://your-domain.atlassian.net/rest/api/3/project/PROJ
```

Look in the `issueTypes` array in the response.

#### Story Issue Type ID

Same methods as Epic Issue Type ID - just find the entry where `"name": "Story"`.

#### Custom Field IDs

To find custom field IDs:

1. Go to **Jira Settings** → **Issues** → **Custom Fields**
2. Click on the field you need
3. The ID is in the URL: `/secure/admin/EditCustomField!default.jspa?id=10100`

**Alternative**: Use the REST API:
```
GET https://your-domain.atlassian.net/rest/api/3/field
```

Response includes all fields:
```json
[
  { "id": "customfield_10100", "name": "PRD Link", ... },
  { "id": "customfield_10101", "name": "AI Autonomy Score", ... }
]
```

---

### Quick Reference: Where to Find Each ID

| ID | Where to Find | Example |
|----|---------------|---------|
| **confluence.space_key** | URL: `/wiki/spaces/MYSPACE/...` | `MYSPACE` |
| **confluence.space_id** | Space Settings → Space Details | `12345` |
| **confluence.default_parent_page_id** | URL: `/pages/123456789/...` | `123456789` |
| **jira.project_key** | Issue key prefix: `PROJ-123` | `PROJ` |
| **jira.project_id** | Project Settings → Details | `10001` |
| **jira.board_id** | URL: `/boards/42` | `42` |
| **jira.epic_issue_type_id** | REST API or Admin → Issue Types | `10000` |
| **jira.story_issue_type_id** | REST API or Admin → Issue Types | `10001` |
| **custom_fields.*** | Admin → Custom Fields (URL) | `customfield_10100` |

---

### Atlassian Documentation Links

- [Confluence: Find your Space ID](https://support.atlassian.com/confluence-cloud/docs/find-your-space-id/)
- [Jira: Find your Site/Project ID](https://support.atlassian.com/jira-cloud-administration/docs/find-your-site-id/)
- [Jira REST API: Get Issue Types](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-issue-types/)
- [Jira REST API: Get Fields](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-issue-fields/)
- [Jira REST API: Get Project](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-projects/)

---

## Step 2: Create Ideation GPT

### 2.1 Create the GPT

1. Navigate to ChatGPT Enterprise
2. Click **"Explore GPTs"** in the sidebar
3. Click **"Create a GPT"** (or **"Create"** button)
4. Select the **"Configure"** tab

### 2.2 Basic Settings

| Field | Value |
|-------|-------|
| **Name** | `[Team Name] Ideation Agent` |
| **Description** | Transform ideas into comprehensive PRDs through collaborative refinement and research. Creates business-friendly Product Requirements Documents with Confluence and SharePoint integration. |
| **Instructions** | Copy entire contents from `chatgpt/ideation-gpt/instructions.md` |

### 2.3 Upload Team Configuration

**Important**: Due to the ~8000 character limit for GPT instructions, upload your team configuration as a file attachment instead of pasting it.

1. In the GPT builder, go to the **Knowledge** section
2. Click **Upload files**
3. Upload your `team-config.yml` file (from `agents/config/`)
4. The GPT will automatically read configuration from this uploaded file

### 2.4 Enable Capabilities

In the **Capabilities** section, enable:
- [x] Web Browsing (for industry research)
- [x] Code Interpreter (for data processing)

### 2.5 Connect Apps (Atlassian, SharePoint)

**Note**: Apps (formerly called "Connectors") are connected at the user/workspace level, not in the GPT builder. Users must connect apps before using the GPT.

**For Workspace Admins** (Enterprise/Edu - one-time setup):
1. Go to **Workspace Settings → Apps**
2. Find and enable **Atlassian** app
3. Find and enable **Microsoft 365** app (for SharePoint)
4. Configure action controls as needed

**For Users** (each user must do this once):
1. Go to **Settings → Apps**
2. Find **Atlassian** and click **Connect**
3. Complete OAuth authorization with your Atlassian account
4. Find **Microsoft 365** and click **Connect** (if using SharePoint)
5. Complete OAuth authorization

**Using Apps in Conversations**:
Once connected, users can invoke apps by:
- Using `@Atlassian` mention in prompts
- Clicking **+** then **More** to select the app

**Available Atlassian Actions**:
- Search and read Confluence pages
- Create Confluence pages
- Search and read Jira issues
- Create and update Jira issues

**Documentation**: 
- [Apps in ChatGPT](https://help.openai.com/en/articles/11487775-connectors-in-chatgpt)
- [Atlassian Rovo MCP Setup](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/setting-up-chatgpt/)

### 2.6 Add Conversation Starters

Add these suggested prompts:
- "I have a new feature idea: [describe your idea]"
- "Help me create a PRD for improving [area]"
- "Research existing documentation about [topic] before we create a PRD"
- "What should I include in a PRD for [feature type]?"

### 2.7 Set Profile Picture

Upload your team logo or use a relevant icon.

### 2.8 Save and Test

1. Click **"Create"** or **"Save"**
2. Test with a sample idea
3. Verify Confluence/SharePoint integration works

---

## Step 3: Create Epic GPT

### 3.1 Create the GPT

1. Click **"Create a GPT"**
2. Select **"Configure"** tab

### 3.2 Basic Settings

| Field | Value |
|-------|-------|
| **Name** | `[Team Name] Epic Agent` |
| **Description** | Convert PRDs into well-structured Jira Epics using the CREATE framework. Transforms business requirements into technical specifications for engineering teams. |
| **Instructions** | Copy entire contents from `chatgpt/epic-gpt/instructions.md` |

### 3.3 Upload Team Configuration

1. Go to the **Knowledge** section
2. Upload your `team-config.yml` file

### 3.4 Enable Capabilities

- [x] Code Interpreter

### 3.5 Apps (Atlassian)

Users must have Atlassian app connected (see Step 2.5). This GPT uses:
- Confluence: Read PRD pages
- Jira: Create Epics, search related issues

### 3.6 Add Conversation Starters

- "Convert this Confluence PRD to an Epic: [paste URL]"
- "Create an Epic from this SharePoint document: [paste URL]"
- "Help me structure an Epic using the CREATE framework"

### 3.7 Save and Test

1. Save the GPT
2. Test with a real PRD URL
3. Verify Epic creation in Jira

---

## Step 4: Create Story GPT

### 4.1 Create the GPT

1. Click **"Create a GPT"**
2. Select **"Configure"** tab

### 4.2 Basic Settings

| Field | Value |
|-------|-------|
| **Name** | `[Team Name] Story Agent` |
| **Description** | Break down Epics into well-defined User Stories with Gherkin acceptance criteria and AI Autonomy scoring. Creates sprint-ready stories in Jira. |
| **Instructions** | Copy entire contents from `chatgpt/story-gpt/instructions.md` |

### 4.3 Upload Team Configuration

1. Go to the **Knowledge** section
2. Upload your `team-config.yml` file

### 4.4 Enable Capabilities

- [x] Code Interpreter

### 4.5 Apps (Atlassian)

Users must have Atlassian app connected (see Step 2.5). This GPT uses:
- Jira: Read Epics, create Stories

### 4.6 Add Conversation Starters

- "Break down Epic PROJ-123 into stories"
- "Create stories from this Epic: [paste Jira URL]"
- "What's a good story breakdown for an authentication Epic?"
- "Help me write Gherkin acceptance criteria for [feature]"

### 4.7 Save and Test

1. Save the GPT
2. Test with a real Epic key
3. Verify stories are created and linked correctly

---

## Step 5: Share with Your Team

### Publishing Options

1. **My Workspace** (Recommended for initial rollout)
   - Only your organization can access
   - Good for testing and refinement

2. **Anyone with the link**
   - Share specific link with team members
   - Good for controlled access

3. **Public** (Not recommended)
   - Anyone can discover and use
   - May expose internal processes

### Sharing the GPTs

1. Open each GPT
2. Click **"Share"** or the share icon
3. Set visibility to **"My workspace"**
4. Copy the share link
5. Distribute to Product Owners

---

## Troubleshooting

### Connectors Not Available

**Symptom**: Can't find Rovo or Microsoft connectors in Actions

**Solution**:
1. Contact your ChatGPT Enterprise admin
2. Request enabling the Atlassian Rovo connector
3. Request enabling the Microsoft 365 connector
4. Ensure your account has connector permissions

### Confluence/Jira Access Denied

**Symptom**: "Access denied" when trying to read/create

**Solution**:
1. Verify your Atlassian account has appropriate permissions
2. Check that the service account used by the connector has access
3. Verify space/project permissions in Atlassian admin

### SharePoint Access Issues

**Symptom**: Can't read or write to SharePoint

**Solution**:
1. Verify Microsoft 365 connector is properly configured
2. Check SharePoint site permissions
3. Ensure your account has access to the document library

### Configuration Not Loading

**Symptom**: GPT doesn't use team settings

**Solution**:
1. Verify YAML syntax is correct (use a YAML validator)
2. Ensure configuration is pasted in the correct location
3. Check for special characters that may break parsing

### Epic/Story Creation Fails

**Symptom**: Items not created in Jira

**Solution**:
1. Verify project key and issue type IDs are correct
2. Check that required fields are provided
3. Ensure the connector has "create" permissions
4. Review Jira project's required fields configuration

---

## Best Practices

### For Product Owners

1. **Start with Ideation GPT** for new features
2. **Review research findings** before proceeding to PRD
3. **Always approve checkpoints** - don't let the GPT auto-proceed
4. **Link PRDs to Epics** for traceability
5. **Review autonomy scores** to understand implementation complexity

### For Team Leads

1. **Standardize on team configuration** across all GPTs
2. **Review generated Epics/Stories** before sprint planning
3. **Use autonomy labels** to assign work appropriately
4. **Keep business vocabulary updated** for consistency

### Maintenance

1. **Update team configuration** when Jira/Confluence settings change
2. **Review and refine** GPT instructions based on team feedback
3. **Monitor quality** of generated PRDs, Epics, and Stories
4. **Adjust autonomy thresholds** based on actual implementation experience

---

## Quick Reference

### GPT URLs (after creation)

| GPT | URL |
|-----|-----|
| Ideation GPT | [Paste your URL here after creation] |
| Epic GPT | [Paste your URL here after creation] |
| Story GPT | [Paste your URL here after creation] |

### Workflow Summary

```
Ideation GPT          Epic GPT              Story GPT
     │                    │                     │
     ▼                    ▼                     ▼
 Idea → PRD         PRD → Epic           Epic → Stories
     │                    │                     │
     ▼                    ▼                     ▼
 Confluence/         Jira Epic            Jira Stories
 SharePoint          (CREATE)             (Gherkin + Autonomy)
```

### Support

For issues with:
- **GPT behavior**: Review and adjust instructions
- **Connectors**: Contact ChatGPT Enterprise admin
- **Jira/Confluence**: Contact Atlassian admin
- **SharePoint**: Contact Microsoft 365 admin
