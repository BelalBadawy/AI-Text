# Auto-Detect Skills Distribution System - Design Proposal

**Author:** AI Studio Team  
**Date:** January 28, 2026  
**Status:** Draft - Pending Review

---

## Executive Summary

This proposal outlines an automated skill distribution system that will:
- Automatically scan all 200+ repositories in the organization
- Detect each repository's tech stack by analyzing file patterns
- Distribute appropriate AI coding skills without requiring any team action
- Support opt-out and customization at the repository level

**Key Benefit:** Zero synchronous coordination required from teams. The system is fully automated with async PR-based adoption.

---

## Problem Statement

The current topic-based distribution approach has limitations:

| Issue | Impact |
|-------|--------|
| Requires teams to add GitHub topics | Needs write/admin access to repo settings |
| Manual topic selection | Teams must understand which skills they need |
| Synchronous coordination | Can't efficiently onboard 200+ repos |
| No automatic discovery | New repos must manually opt-in |

---

## Proposed Solution: Auto-Detect + Org-Wide Scan

### High-Level Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  TRIGGER: Scheduled (weekly) or Manual dispatch                             │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  DISCOVERY: Scan ALL repos in Price-Optimization org                        │
│  - Filter out: archived, forks, denylist                                    │
│  - Result: List of 200+ active repositories                                 │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  ANALYSIS (per repo): Use GitHub Tree API to list all files                 │
│  - Match files against detection rules (*.csproj → .NET, *.py → Python)    │
│  - Result: List of detected skills per repo                                 │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  CONFIG CHECK: Read .ai-rules-config if exists                              │
│  - enabled: false → Skip repo                                               │
│  - pinned_version → Use specific version                                    │
│  - skills: [...] → Override auto-detected skills                            │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  DELIVERY: Create PR with detected skills + generic skills                  │
│  - Skills copied to .cursor/skills/ and .github/skills/                     │
│  - Team reviews and merges at their convenience (async)                     │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Architecture Diagram

```mermaid
flowchart TD
    subgraph trigger [Trigger]
        A[Scheduled Weekly OR Manual Dispatch]
    end
    
    subgraph discovery [Discovery Phase]
        B[list-org-repositories action]
        B --> C[Get all repos in org]
        C --> D[Filter: archived, forks, allowlist/denylist]
    end
    
    subgraph analysis [Analysis Phase - Per Repo]
        E[detect-tech-stack action]
        E --> F[GitHub Tree API: list files]
        F --> G[Match against detection-rules.yaml]
        G --> H[Return detected skills]
    end
    
    subgraph config [Config Check]
        I[Read .ai-rules-config if exists]
        I --> J{enabled: false?}
        J -->|Yes| K[Skip repo]
        J -->|No| L[Apply skills]
    end
    
    subgraph apply [Apply Phase]
        L --> M[apply-ai-rules action]
        M --> N[Create PR with skills]
    end
    
    trigger --> discovery
    discovery --> analysis
    analysis --> config
```

---

## Detection Rules Configuration

A new YAML configuration file defines how tech stacks are detected:

### `config/detection-rules.yaml`

```yaml
# Detection rules - each skill maps to file patterns
# Extensible: add new rules without code changes

detection_rules:
  # .NET / C#
  dotnet-backend:
    patterns: 
      - "**/*.csproj"
      - "**/*.sln"
      - "**/*.fsproj"
    description: ".NET project files"
    
  csharp-development:
    patterns: 
      - "**/*.cs"
    min_files: 3  # Require at least 3 C# files
    description: "C# source code"
    
  dotnet-upgrade:
    patterns:
      - "**/*.csproj"
    description: ".NET upgrade guidance"

  # Python
  python-backend:
    patterns: 
      - "**/*.py"
      - "**/requirements.txt"
      - "**/pyproject.toml"
      - "**/setup.py"
    description: "Python project"
    
  # TypeScript
  typescript-backend:
    patterns: 
      - "**/*.ts"
      - "**/tsconfig.json"
    exclude: 
      - "**/node_modules/**"
    min_files: 3
    description: "TypeScript project"
    
  # Database / SQL
  sql-development:
    patterns: 
      - "**/*.sql"
      - "**/migrations/**"
      - "**/Migrations/**"
      - "**/stored-procedures/**"
    description: "SQL files or database migrations"
    
  # REST API
  rest-api-standards:
    patterns: 
      - "**/*Controller.cs"
      - "**/*Controller.ts"
      - "**/controllers/**"
      - "**/api/**"
      - "**/swagger*.json"
      - "**/openapi*.yaml"
    description: "API controllers or OpenAPI specs"
    
  # Frontend
  frontend-standards:
    patterns: 
      - "**/*.cshtml"
      - "**/*.razor"
      - "**/*.jsx"
      - "**/*.tsx"
      - "**/*.vue"
      - "**/angular.json"
    description: "Frontend framework files"
    
  # DevOps / CI-CD
  devops-ci-cd:
    patterns: 
      - "**/Dockerfile"
      - "**/.github/workflows/**"
      - "**/azure-pipelines.yml"
      - "**/Jenkinsfile"
    description: "CI/CD configuration"
    
  # Infrastructure
  terraform-infrastructure:
    patterns: 
      - "**/*.tf"
      - "**/*.tfvars"
      - "**/terraform/**"
    description: "Terraform infrastructure code"

# Central repository filters
repository_filters:
  # Explicit denylist - never process these repos
  denylist:
    - "Price-Optimization/legacy-archived-repo"
    - "Price-Optimization/template-repo"
    - "Price-Optimization/Zelis.AI.Studio"  # This repo itself
  
  # Optional allowlist - if populated, ONLY process these repos
  # Useful for phased rollout
  allowlist: []
  
  # Automatic filters
  skip_archived: true
  skip_forks: true
  skip_empty: true
```

---

## Files to Create/Modify

### New Files

| File | Purpose |
|------|---------|
| `config/detection-rules.yaml` | Detection patterns and repository filters |
| `.github/actions/list-org-repositories/action.yml` | Enumerate repos in org with filtering |
| `.github/actions/detect-tech-stack/action.yml` | Analyze repo contents via GitHub Tree API |
| `.github/workflows/distribute-ai-rules-auto.yml` | New workflow for automated distribution |

### Modified Files

| File | Changes |
|------|---------|
| `.github/actions/apply-ai-rules/src/utils.js` | Add `detectSkillsFromRepo()` function |
| `.github/actions/apply-ai-rules/src/index.js` | Support auto-detect mode alongside topics |
| `SUBSCRIPTION.md` | Document new automated approach |

---

## New Workflow: `distribute-ai-rules-auto.yml`

```yaml
name: Auto-Distribute AI Rules

on:
  schedule:
    - cron: '0 6 * * 1'  # Weekly on Monday 6 AM UTC
  workflow_dispatch:
    inputs:
      dry_run:
        description: 'Dry run mode (no PRs created)'
        type: boolean
        default: false
      repository_filter:
        description: 'Optional: specific repo to process (owner/repo)'
        type: string
        required: false

jobs:
  list-repositories:
    runs-on: ubuntu-latest
    outputs:
      repositories: ${{ steps.list.outputs.repositories }}
    steps:
      - uses: actions/checkout@v4
      - uses: ./.github/actions/list-org-repositories
        id: list
        with:
          organization: Price-Optimization
          github_token: ${{ secrets.GITHUB_TOKEN }}
    
  distribute:
    needs: list-repositories
    runs-on: ubuntu-latest
    strategy:
      matrix:
        repository: ${{ fromJson(needs.list-repositories.outputs.repositories) }}
      max-parallel: 10
      fail-fast: false
    steps:
      - uses: actions/checkout@v4
      
      - name: Detect tech stack
        id: detect
        uses: ./.github/actions/detect-tech-stack
        with:
          repository: ${{ matrix.repository }}
          github_token: ${{ secrets.GITHUB_TOKEN }}
      
      - name: Apply AI rules
        uses: ./.github/actions/apply-ai-rules
        with:
          repository: ${{ matrix.repository }}
          detected_skills: ${{ steps.detect.outputs.skills }}
          github_token: ${{ secrets.GITHUB_TOKEN }}
          dry_run: ${{ inputs.dry_run }}
```

---

## Customization Matrix

| Customization | How | Who Controls |
|---------------|-----|--------------|
| Add new detection rules | Edit `config/detection-rules.yaml` | Central team |
| Add new skills | Add folder in `skills/` + update detection rules | Central team |
| Skip specific repos | Add to `denylist` in detection-rules.yaml | Central team |
| Phased rollout | Use `allowlist` in detection-rules.yaml | Central team |
| Opt-out a repo | Add `.ai-rules-config` with `enabled: false` | Repo team |
| Pin to version | Add `.ai-rules-config` with `pinned_version: "1.0.0"` | Repo team |
| Override detected skills | Add `.ai-rules-config` with explicit `skills: [...]` | Repo team |

---

## Repository-Level Configuration

Teams can customize behavior by adding `.ai-rules-config` to their repo:

```yaml
# .ai-rules-config - Repository-level configuration

# Opt-out completely
enabled: false

# OR customize:
enabled: true

# Pin to a specific version (skip newer versions)
pinned_version: "1.2.0"

# Override auto-detected skills with explicit list
skills:
  - dotnet-backend
  - csharp-development
  - sql-development

# Disable auto-detection, use only explicit skills above
auto_detect: false
```

---

## Example: How Detection Works

```
Repository: Price-Optimization/PaymentService

File Structure:
├── src/
│   ├── PaymentService.csproj         ✓ Matches: dotnet-backend
│   ├── Program.cs                    ✓ Matches: csharp-development
│   ├── Controllers/
│   │   └── PaymentController.cs      ✓ Matches: rest-api-standards
│   └── Data/
│       └── Migrations/               ✓ Matches: sql-development
├── terraform/
│   └── main.tf                       ✓ Matches: terraform-infrastructure
├── Dockerfile                        ✓ Matches: devops-ci-cd
└── .github/workflows/ci.yml          ✓ Matches: devops-ci-cd

Detected Skills (6):
  - dotnet-backend
  - csharp-development
  - rest-api-standards
  - sql-development
  - terraform-infrastructure
  - devops-ci-cd

Plus Generic Skills (18):
  - sdlc/coding-principles
  - security/security-standards
  - security/secure-coding-enforcement
  - ... (all security, QA, architecture skills)

Total: 24 skills delivered via PR
```

---

## Migration Path

| Phase | Action | Risk |
|-------|--------|------|
| 1. Deploy | Add new workflow alongside existing topic-based workflow | None - existing flow unchanged |
| 2. Validate | Run in dry-run mode, review detection accuracy | None - no PRs created |
| 3. Pilot | Use allowlist to test with 5-10 repos | Low - limited scope |
| 4. Rollout | Remove allowlist, enable org-wide distribution | Medium - monitor PR volume |
| 5. Deprecate | (Optional) Phase out topic-based approach | Low - after validation |

---

## Comparison: Current vs Proposed

| Aspect | Current (Topics) | Proposed (Auto-Detect) |
|--------|------------------|------------------------|
| Team action required | Add GitHub topic (needs permissions) | None (or opt-out) |
| Skill selection | Manual - teams choose topics | Automatic - based on code |
| New repo onboarding | Manual opt-in | Automatic discovery |
| Accuracy | Teams may choose wrong topics | Based on actual code |
| Scalability | Requires coordination | Fully automated |
| Customization | Limited | Full (allow/deny lists, overrides) |

---

## Honest Assessment: Pros and Cons

### Pros (Benefits)

| Pro | Details |
|-----|---------|
| **Zero friction adoption** | Teams don't need to do anything to receive skills. PRs arrive automatically. This is critical for 200+ repos. |
| **Permission-free** | No admin access needed. The current topic approach requires repo settings access, which many developers don't have. |
| **Accurate skill matching** | Detection based on actual code is more accurate than teams guessing which topics they need. A repo with `*.csproj` files objectively needs .NET skills. |
| **Self-maintaining** | New repos automatically get discovered. Teams that add SQL files later automatically get SQL skills on the next run. |
| **Extensible** | Adding new detection rules is just YAML - no code changes. Central team can iterate quickly. |
| **Graceful opt-out** | Teams who don't want skills can easily opt-out with a simple config file. |
| **Backward compatible** | Existing topic-based approach continues to work during transition. |

### Cons (Risks and Challenges)

| Con | Details | Mitigation |
|-----|---------|------------|
| **Unwanted PRs** | Teams may receive PRs they didn't ask for. Some teams may find this intrusive, especially if they have their own AI rules or don't use AI assistants. | Clear communication before rollout. Easy opt-out via `.ai-rules-config`. |
| **Detection false positives** | A repo with a single `test.sql` file might get SQL skills it doesn't really need. File presence doesn't always indicate active use of that technology. | Use `min_files` threshold in detection rules. Allow teams to override via config. |
| **Detection false negatives** | Unusual project structures or naming conventions might not be detected. A Python project without `requirements.txt` might be missed. | Document detection rules clearly. Allow explicit skill requests in `.ai-rules-config`. |
| **PR fatigue** | With weekly runs across 200 repos, teams may get annoyed by frequent PRs, especially if skills change often. | Only create PRs when content actually changes (hash comparison). Consider monthly instead of weekly. |
| **GitHub API rate limits** | Scanning 200 repos and their file trees may hit API rate limits, especially with the Tree API. | Use GitHub App authentication (higher limits). Implement pagination and backoff. Consider caching. |
| **Maintenance burden** | Detection rules need ongoing maintenance as new technologies emerge or naming conventions change. | Document rule authoring process. Assign ownership to central team. |
| **Complexity increase** | The system becomes more complex than simple topic-based matching. More moving parts = more potential failure points. | Comprehensive logging. Dry-run mode for testing. Gradual rollout with monitoring. |
| **Loss of team agency** | Some teams may prefer to explicitly choose their skills rather than having them auto-assigned. Developers may feel "things are being done to them." | Emphasize that auto-detect is a convenience, not a mandate. Teams can always override with explicit `skills: []` in config. |

### Neutral Observations

| Observation | Implication |
|-------------|-------------|
| **Org culture matters** | This approach works best in organizations where central tooling is welcomed. If teams value autonomy highly, the opt-out default (vs opt-in) may cause friction. |
| **Detection is heuristic** | No detection system is perfect. There will always be edge cases. The question is whether the accuracy is "good enough" for the majority of repos. |
| **Delayed adoption** | PRs still require teams to merge. If teams ignore PRs, the system achieves discovery but not actual adoption. Consider metrics to track merge rates. |
| **Security considerations** | The GitHub App needs read access to all repos in the org. This is a privilege that should be audited and documented. |

### My Honest Opinion

**This approach is well-suited for your situation** (200 repos, need for automation, Hackathon timeline) because:

1. The alternative (coordinating 200 teams to add topics) is not practical
2. Auto-detection is accurate for standard tech stacks (.NET, Python, SQL, etc.)
3. The opt-out mechanism provides an escape hatch for teams who don't want it

**However, be prepared for:**

1. Some teams will be surprised/annoyed by unsolicited PRs - communicate beforehand
2. Detection will be ~90% accurate, not 100% - have a process for handling edge cases
3. The first rollout will surface issues - plan for iteration and feedback collection

**Recommendation:** Start with a pilot (10-20 repos via allowlist), collect feedback, refine detection rules, then proceed to full rollout. This reduces risk and builds confidence.

---

## Open Questions for Review

1. **Schedule frequency:** Weekly (Monday 6 AM UTC) - is this appropriate?
2. **PR merge policy:** Should we enable auto-merge for low-risk updates?
3. **Notification:** Should we notify teams before first PR via email/Slack?
4. **Rollout approach:** Phased (allowlist) or immediate org-wide?
5. **Existing topic subscribers:** Keep both approaches or migrate?

---

## Implementation Tasks

- [ ] Create `config/detection-rules.yaml` with file patterns for all skills
- [ ] Create `.github/actions/list-org-repositories/action.yml`
- [ ] Create `.github/actions/detect-tech-stack/action.yml`
- [ ] Update `.github/actions/apply-ai-rules/src/utils.js` with detection function
- [ ] Update `.github/actions/apply-ai-rules/src/index.js` to support auto-detect mode
- [ ] Create `.github/workflows/distribute-ai-rules-auto.yml`
- [ ] Update `SUBSCRIPTION.md` documentation
- [ ] Test in dry-run mode
- [ ] Pilot with selected repositories
- [ ] Full rollout

---

## Appendix: Industry Reference

This approach is inspired by practices from large tech companies:

| Company | Pattern | Our Adaptation |
|---------|---------|----------------|
| Netflix | "Paved Roads" - curated, opt-in golden paths | Auto-detect provides the right path automatically |
| Amazon | Org-wide security scans, guardrails | Org-wide scan with opt-out capability |
| Meta | Central catalog, team subscription | Central skills, automatic delivery |
| Google | Standards enforced via shared tooling | Skills distributed via automated PRs |

---

*Document generated for review. Please provide feedback on the approach and open questions.*
