#!/usr/bin/env node
/**
 * Setup script for pre-commit hooks
 *
 * Attempts to install pre-commit hooks if pre-commit is available.
 * Falls back to a simple git hook if pre-commit is not installed.
 */

import { execSync, spawnSync } from "node:child_process";
import * as fs from "node:fs";
import * as path from "node:path";

const HOOK_CONTENT = `#!/bin/sh
# Pre-commit hook installed by zelis-ai-studio
# Runs the skill linter before each commit

npm run lint
if [ $? -ne 0 ]; then
  echo ""
  echo "❌ Skill lint failed. Please fix the errors above before committing."
  exit 1
fi
`;

function isGitRepo() {
  return fs.existsSync(".git");
}

function hasPreCommit() {
  // Try pre-commit command first
  let result = spawnSync("pre-commit", ["--version"], {
    stdio: "pipe",
    shell: true,
  });
  if (result.status === 0) return true;

  // Try via python module (handles PATH issues)
  result = spawnSync("python3", ["-m", "pre_commit", "--version"], {
    stdio: "pipe",
    shell: true,
  });
  return result.status === 0;
}

function installPreCommitHooks() {
  console.log("📦 Installing pre-commit hooks...");
  try {
    // Try pre-commit command first
    try {
      execSync("pre-commit install", { stdio: "inherit" });
    } catch {
      // Fallback to python module
      execSync("python3 -m pre_commit install", { stdio: "inherit" });
    }
    console.log("✅ Pre-commit hooks installed successfully!");
    return true;
  } catch (error) {
    console.error("❌ Failed to install pre-commit hooks:", error.message);
    return false;
  }
}

function installSimpleHook() {
  const hooksDir = path.join(".git", "hooks");
  const hookPath = path.join(hooksDir, "pre-commit");

  // Create hooks directory if it doesn't exist
  if (!fs.existsSync(hooksDir)) {
    fs.mkdirSync(hooksDir, { recursive: true });
  }

  // Don't overwrite existing hooks
  if (fs.existsSync(hookPath)) {
    const existingContent = fs.readFileSync(hookPath, "utf-8");
    if (existingContent.includes("zelis-ai-studio")) {
      console.log("✅ Git hook already installed");
      return true;
    }
    console.log("⚠️  Existing pre-commit hook found, not overwriting");
    console.log("   Add 'npm run lint' to your existing hook manually");
    return false;
  }

  fs.writeFileSync(hookPath, HOOK_CONTENT, { mode: 0o755 });
  console.log("✅ Simple git pre-commit hook installed");
  return true;
}

function main() {
  console.log("");
  console.log("🔧 Setting up pre-commit hooks for zelis-ai-studio");
  console.log("");

  if (!isGitRepo()) {
    console.log("⚠️  Not a git repository, skipping hook setup");
    return;
  }

  if (hasPreCommit()) {
    console.log("✓ pre-commit found");
    installPreCommitHooks();
  } else {
    console.log("⚠️  pre-commit not found (pip install pre-commit)");
    console.log("   Installing simple git hook instead...");
    console.log("");
    installSimpleHook();
    console.log("");
    console.log("💡 For full pre-commit support (markdown linting, etc.):");
    console.log("   pip install pre-commit && pre-commit install");
  }

  console.log("");
}

main();

