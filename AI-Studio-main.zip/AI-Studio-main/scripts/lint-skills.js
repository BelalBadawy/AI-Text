#!/usr/bin/env node
/**
 * SKILL.md linter with schema validation and cross-reference checking
 *
 * Validates:
 * - Required frontmatter fields (name, description)
 * - Schema validation (disposition, version, filePatterns)
 * - Cross-references between topics.yaml and skills
 * - Body content requirements
 */

import * as fs from "node:fs";
import * as path from "node:path";
import yaml from "js-yaml";

const SKILLS_DIR = "skills";
const TOPICS_CONFIG = "config/topics.yaml";
const REQUIRED_FIELDS = ["name", "description"];
const MIN_BODY_LENGTH = 50;
const MAX_LINES = 500;
const VALID_DISPOSITIONS = ["always", "contextual"];
// Full semantic versioning regex supporting pre-release versions (e.g., 1.0.0-beta.1)
// and build metadata (e.g., 1.0.0+20130313144700, 1.0.0+exp.sha.5114f85)
const SEMVER_REGEX = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;

/**
 * Parse frontmatter from SKILL.md
 */
function parseFrontmatter(content) {
    if (!content.startsWith("---")) {
        return {
            frontmatter: null,
            body: content,
            error: "Missing frontmatter (must start with ---)",
        };
    }

    const lines = content.split("\n");
    let endIndex = null;

    for (let i = 1; i < lines.length; i++) {
        if (lines[i].trim() === "---") {
            endIndex = i;
            break;
        }
    }

    if (endIndex === null) {
        return {
            frontmatter: null,
            body: content,
            error: "Missing closing --- for frontmatter",
        };
    }

    const frontmatterText = lines.slice(1, endIndex).join("\n");
    const body = lines
        .slice(endIndex + 1)
        .join("\n")
        .trim();

    try {
        return { frontmatter: yaml.load(frontmatterText), body, error: null };
    } catch (e) {
        return { frontmatter: null, body, error: `Invalid YAML: ${e.message}` };
    }
}

/**
 * Validate frontmatter against schema
 */
function validateSchema(frontmatter, skillDir) {
    const errors = [];
    const warnings = [];

    // Check required fields
    for (const field of REQUIRED_FIELDS) {
        if (!frontmatter[field]) {
            errors.push(`Missing required field: ${field}`);
        }
    }

    // Check name matches directory
    if (frontmatter.name && frontmatter.name !== skillDir) {
        warnings.push(
            `Skill name '${frontmatter.name}' doesn't match directory '${skillDir}'`
        );
    }

    // Validate description
    if (frontmatter.description) {
        // Check if description was incorrectly parsed as an array
        if (Array.isArray(frontmatter.description)) {
            errors.push(
                "Description is an array - use 'description: |' for multi-line strings"
            );
        } else if (typeof frontmatter.description === "string") {
            if (frontmatter.description.length < 20) {
                warnings.push(
                    "Description is very short - should explain when to use this skill"
                );
            }
        } else {
            errors.push(
                `Description must be a string, got ${typeof frontmatter.description}`
            );
        }
    }

    // Validate disposition
    if (
        frontmatter.disposition &&
        !VALID_DISPOSITIONS.includes(frontmatter.disposition)
    ) {
        errors.push(
            `Invalid disposition '${frontmatter.disposition}' - must be one of: ${VALID_DISPOSITIONS.join(", ")}`
        );
    }

    // Validate version format (semver)
    if (frontmatter.version) {
        const versionStr = String(frontmatter.version);
        if (!SEMVER_REGEX.test(versionStr)) {
            warnings.push(
                `Version '${versionStr}' is not valid semver (expected X.Y.Z)`
            );
        }
    }

    // Validate filePatterns is an array of strings
    if (frontmatter.filePatterns) {
        if (!Array.isArray(frontmatter.filePatterns)) {
            errors.push("filePatterns must be an array");
        } else {
            for (const pattern of frontmatter.filePatterns) {
                if (typeof pattern !== "string") {
                    errors.push(`filePattern '${pattern}' must be a string`);
                }
            }
        }
    }

    // Validate compliance is an array of objects
    if (frontmatter.compliance) {
        if (!Array.isArray(frontmatter.compliance)) {
            errors.push("compliance must be an array");
        } else {
            for (const item of frontmatter.compliance) {
                if (typeof item !== "object" || item === null) {
                    errors.push("compliance items must be objects like { soc2: 'CC5.2' }");
                }
            }
        }
    }

    return { errors, warnings };
}

/**
 * Validate a single SKILL.md file
 */
function validateSkill(skillPath) {
    const errors = [];
    const warnings = [];

    const content = fs.readFileSync(skillPath, "utf-8");
    const { frontmatter, body, error } = parseFrontmatter(content);

    if (error) {
        errors.push(error);
        return { errors, warnings, frontmatter: null };
    }

    // Schema validation
    const skillDir = path.basename(path.dirname(skillPath));
    const schemaResult = validateSchema(frontmatter, skillDir);
    errors.push(...schemaResult.errors);
    warnings.push(...schemaResult.warnings);

    // Check body content
    if (body.length < MIN_BODY_LENGTH) {
        errors.push(
            `Body content too short (${body.length} chars, minimum ${MIN_BODY_LENGTH})`
        );
    }

    // Check line count
    const lineCount = content.split("\n").length;
    if (lineCount > MAX_LINES) {
        warnings.push(`File has ${lineCount} lines (recommended max: ${MAX_LINES})`);
    }

    return { errors, warnings, frontmatter };
}

/**
 * Load topics configuration
 */
function loadTopicsConfig() {
    if (!fs.existsSync(TOPICS_CONFIG)) {
        return null;
    }
    const content = fs.readFileSync(TOPICS_CONFIG, "utf-8");
    return yaml.load(content);
}

/**
 * Get all skill names referenced in topics.yaml
 */
function getReferencedSkills(topicsConfig) {
    const skills = new Set();

    // Generic skills - now organized by category
    if (topicsConfig.generic_skills) {
        // Check if it's the new nested structure (object with categories)
        if (typeof topicsConfig.generic_skills === 'object' && !Array.isArray(topicsConfig.generic_skills)) {
            // New structure: categories containing arrays of skills
            for (const category of Object.keys(topicsConfig.generic_skills)) {
                const categorySkills = topicsConfig.generic_skills[category];
                if (Array.isArray(categorySkills) && categorySkills !== null && categorySkills !== undefined) {
                    for (const skill of categorySkills) {
                        skills.add(skill);
                    }
                }
            }
        } else if (Array.isArray(topicsConfig.generic_skills)) {
            // Old structure: flat array of skills (backward compatibility)
            for (const skill of topicsConfig.generic_skills) {
                skills.add(skill);
            }
        }
    }

    // Topic-specific skills
    if (topicsConfig.topics) {
        for (const topic of Object.keys(topicsConfig.topics)) {
            for (const skill of topicsConfig.topics[topic]) {
                skills.add(skill);
            }
        }
    }

    return skills;
}

/**
 * Cross-validate topics.yaml against actual skills
 */
function crossValidateTopics(topicsConfig, existingSkills) {
    const errors = [];
    const warnings = [];
    const referencedSkills = getReferencedSkills(topicsConfig);

    // Check all referenced skills exist
    for (const skill of referencedSkills) {
        if (!existingSkills.has(skill)) {
            errors.push(`topics.yaml references non-existent skill: '${skill}'`);
        }
    }

    // Check for orphan skills (exist but not referenced)
    for (const skill of existingSkills) {
        if (!referencedSkills.has(skill)) {
            warnings.push(
                `Skill '${skill}' exists but is not referenced in topics.yaml`
            );
        }
    }

    return { errors, warnings };
}

/**
 * Find all SKILL.md files recursively and return skill names with paths
 */
function findSkillFiles() {
    const skills = [];

    if (!fs.existsSync(SKILLS_DIR)) {
        return skills;
    }

    /**
     * Recursively scan directory for SKILL.md files
     */
    function scanDirectory(dir, relativePath = '') {
        const items = fs.readdirSync(dir, { withFileTypes: true });
        
        for (const item of items) {
            const fullPath = path.join(dir, item.name);
            const relPath = relativePath ? path.join(relativePath, item.name) : item.name;
            
            if (item.isDirectory()) {
                // Check if this directory contains SKILL.md
                const skillPath = path.join(fullPath, "SKILL.md");
                if (fs.existsSync(skillPath)) {
                    skills.push({ path: skillPath, name: relPath });
                } else {
                    // Recursively scan subdirectories
                    scanDirectory(fullPath, relPath);
                }
            }
        }
    }

    scanDirectory(SKILLS_DIR);
    return skills;
}

// Main
console.log();
console.log("=".repeat(60));
console.log("SKILL LINT REPORT");
console.log("=".repeat(60));
console.log();

const skillFiles = findSkillFiles();

if (skillFiles.length === 0) {
    console.log("No skills found in skills/ directory");
    process.exit(1);
}

let totalErrors = 0;
let totalWarnings = 0;
const results = [];
const existingSkillNames = new Set(skillFiles.map((s) => s.name));

// Validate each skill
console.log("Validating skills...\n");
for (const { path: skillPath, name: skillName } of skillFiles) {
    const { errors, warnings } = validateSkill(skillPath);

    totalErrors += errors.length;
    totalWarnings += warnings.length;

    if (errors.length > 0 || warnings.length > 0) {
        results.push({ skillName, errors, warnings });
    }
}

// Cross-validate with topics.yaml
const topicsConfig = loadTopicsConfig();
if (topicsConfig) {
    console.log("Cross-validating with topics.yaml...\n");
    const crossValidation = crossValidateTopics(topicsConfig, existingSkillNames);

    if (
        crossValidation.errors.length > 0 ||
        crossValidation.warnings.length > 0
    ) {
        results.push({
            skillName: "topics.yaml",
            errors: crossValidation.errors,
            warnings: crossValidation.warnings,
        });
        totalErrors += crossValidation.errors.length;
        totalWarnings += crossValidation.warnings.length;
    }
} else {
    console.log("⚠ topics.yaml not found - skipping cross-validation\n");
}

// Print results
if (results.length > 0) {
    for (const { skillName, errors, warnings } of results) {
        console.log(`${skillName}:`);
        for (const error of errors) {
            console.log(`  ✗ ERROR: ${error}`);
        }
        for (const warning of warnings) {
            console.log(`  ⚠ WARNING: ${warning}`);
        }
        console.log();
    }
}

// Summary
console.log("-".repeat(60));
console.log(`Skills checked: ${skillFiles.length}`);
console.log(`Errors: ${totalErrors}`);
console.log(`Warnings: ${totalWarnings}`);
console.log(`Status: ${totalErrors === 0 ? "PASSED" : "FAILED"}`);
console.log("-".repeat(60));
console.log();

process.exit(totalErrors > 0 ? 1 : 0);
