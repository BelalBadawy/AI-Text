# How-To Guides

Comprehensive guides for using agents, skills, and custom GPTs in the Zelis AI Studio.

---

## 📂 Quick Navigation

| Category | What's Inside | Who Should Use |
|----------|---------------|----------------|
| **[🤖 Agents](agents/)** | Chatmode agents for development tasks | All developers |
| **[⚡ Skills](skills/)** | GitHub Copilot Skills for code generation | VS Code users only |
| **[⚙️ Setup](setup/)** | Initial configuration and setup | First-time users |

---

## 🤖 Agent Guides

Agents are interactive assistants that help with specific development tasks. Use them via `@agent-name` in VS Code or GitHub Copilot.

### 📝 Code Review & Quality

| Guide | Agent | What It Does | When to Use |
|-------|-------|--------------|-------------|
| [Address Comments](agents/HOW-TO-USE-ADDRESS-COMMENTS.md) | `@address-comments` | Automatically fixes PR review comments | After code review |
| [API Architect](agents/HOW-TO-USE-API-ARCHITECT.md) | `@api-architect` | Reviews & generates .NET API code | API development |
| [Code Quality Guardian](agents/HOW-TO-USE-CODE-QUALITY-GUARDIAN.md) | `@code-quality-guardian` | ⚠️ **Not yet implemented** | Security & quality analysis |
| [Debug](agents/HOW-TO-USE-DEBUG.md) | `@debug` | Systematic bug investigation | When things break |
| [Janitor](agents/HOW-TO-USE-JANITOR.md) | `@janitor` | Code cleanup & tech debt removal | Refactoring sprints |

### 📚 Documentation & Planning

| Guide | Agent | What It Does | When to Use |
|-------|-------|--------------|-------------|
| [Knowledgebase Generator](agents/HOW-TO-USE-KNOWLEDGEBASE-GENERATOR.md) | `@knowledgebase-orchestrator` | Generates comprehensive repo documentation | Onboarding, legacy code |
| [Migration Analyzer](agents/HOW-TO-USE-MIGRATION-ANALYZER.md) | `@migration-orchestrator` | .NET modernization & containerization analysis | Migration planning |

### 🎯 Agile & Project Management

| Guide | Agent | What It Does | When to Use |
|-------|-------|--------------|-------------|
| [Epic & Story Agents](agents/HOW-TO-USE-EPIC-STORY-AGENTS.md) | `@epic-agent` + `@story-agent` | Creates Epics from PRDs, breaks into User Stories | Sprint planning |

### 🧪 Testing & Development

| Guide | Agent | What It Does | When to Use |
|-------|-------|--------------|-------------|
| [Unit Test Generator](agents/HOW-TO-USE-UNIT-TEST-GENERATOR.md) | `@unit-test-generator` | Generates xUnit tests with mocking | TDD, coverage improvement |

### 👨‍🏫 Learning & Guidance

| Guide | Agent | What It Does | When to Use |
|-------|-------|--------------|-------------|
| [Mentor](agents/HOW-TO-USE-MENTOR.md) | `@mentor` | Socratic guidance (no code edits) | Learning, architectural decisions |

### 🔧 Development Workflow

| Guide | Agent | What It Does | When to Use |
|-------|-------|--------------|-------------|
| [Git Commit](agents/HOW-TO-USE-GIT-COMMIT.md) | `@git-commit` | Automated Git workflow + Conventional Commits | Every commit |

---

## ⚡ Skills Guides

**⚠️ IMPORTANT**: Skills are **ONLY available in VS Code**. They do NOT work in Visual Studio 2022.

Skills provide inline code suggestions and follow best practices automatically as you type.

### By Technical Area

| Guide | Focus Area | What's Covered | Target Users |
|-------|------------|----------------|--------------|
| [.NET Backend Skills](skills/HOW-TO-USE-SKILLS-DOTNET-BACKEND.md) | C#/.NET Development | 11 skills: dotnet-backend, csharp-development, clean-architecture, EF Core, Dapper, etc. | Backend developers |
| [AWS Migration Skills](skills/HOW-TO-USE-SKILLS-AWS-MIGRATION.md) | Azure → AWS SDK Migration | 7 skills: KeyVault→Secrets, AppConfig→AppConfig, AppInsights→CloudWatch, etc. | Cloud migration teams |

### How to Get Skills in Your Repo

**Option A: Automatic Distribution (Recommended)**
1. Org admin adds GitHub topic to your repo (e.g., `ai-rules-backend-dotnet`)
2. Skills distributed automatically via PR on release

**Option B: Manual Copy**
1. Browse to [Zelis.AI.Studio/skills](https://github.com/Price-Optimization/Zelis.AI.Studio/tree/main/skills)
2. Copy desired `SKILL.md` file
3. Create `.github/.ai/skills/` in your repo
4. Paste as `{skill-name}.md`
5. Reload VS Code window

**Option C: Request from Admin**
Contact org admin for manual distribution.

---

## ⚙️ Setup Guides

First-time configuration and advanced setup.

| Guide | What It Covers | When to Use |
|-------|----------------|-------------|
| [Skills vs Instructions vs Prompts](setup/SKILLS-VS-INSTRUCTIONS-VS-PROMPTS.md) | Difference between SKILL.md, .instructions.md, and .prompt.md files, and how each type loads into AI context | Understanding repo architecture and context loading |
| [Custom Prompts in VS Code](setup/HOW-TO-USE-CUSTOM-PROMPTS.md) | Use prompt files as slash commands in Copilot Chat | Setting up reusable prompts |
| [Create Custom GPT](setup/HOW-TO-CREATE-CUSTOM-GPT.md) | Build custom ChatGPT agents | Creating specialized ChatGPT assistants |

---

## 🚀 Getting Started

### New to Agents?

**Start here:**
1. **Documentation**: Try [@knowledgebase-orchestrator](agents/HOW-TO-USE-KNOWLEDGEBASE-GENERATOR.md) to document a repo
2. **Daily workflow**: Use [@git-commit](agents/HOW-TO-USE-GIT-COMMIT.md) for intelligent commits
3. **Code quality**: Run [@debug](agents/HOW-TO-USE-DEBUG.md) when stuck

### New to Skills?

**Start here:**
1. Read [VS Code-only warning](skills/HOW-TO-USE-SKILLS-DOTNET-BACKEND.md#important-vs-code-only)
2. Get skills in your repo (see options above)
3. Open VS Code and start coding - skills work automatically

### Planning a Sprint?

**Start here:**
1. Create Epic from PRD: [@epic-agent](agents/HOW-TO-USE-EPIC-STORY-AGENTS.md)
2. Break into Stories: [@story-agent](agents/HOW-TO-USE-EPIC-STORY-AGENTS.md)
3. Generate tests: [@unit-test-generator](agents/HOW-TO-USE-UNIT-TEST-GENERATOR.md)

### Migrating to Cloud?

**Start here:**
1. Analyze .NET readiness: [@migration-orchestrator](agents/HOW-TO-USE-MIGRATION-ANALYZER.md)
2. Use [AWS Migration Skills](skills/HOW-TO-USE-SKILLS-AWS-MIGRATION.md) for SDK changes

---

## 📊 Agent vs Skills: When to Use What?

| Use Case | Use Agent | Use Skill |
|----------|-----------|-----------|
| Generate entire test class | ✅ `@unit-test-generator` | ❌ |
| Get inline test suggestions as you type | ❌ | ✅ `unit-test-isolation` skill |
| Create complete documentation | ✅ `@knowledgebase-orchestrator` | ❌ |
| Follow coding standards automatically | ❌ | ✅ `csharp-development` skill |
| Debug specific issue | ✅ `@debug` | ❌ |
| Migrate Azure SDK to AWS | Use both! Agent for orchestration, Skills for inline help | ✅ Both |
| Review API architecture | ✅ `@api-architect` | ❌ |
| Clean up technical debt | ✅ `@janitor` | ❌ |
| Learn concepts (no code edits) | ✅ `@mentor` | ❌ |
| Commit with generated message | ✅ `@git-commit` | ❌ |

**Rule of Thumb:**
- **Agents**: Interactive tasks, analysis, generation of complete artifacts
- **Skills**: Background guidance, inline suggestions, enforce patterns as you code

---

## 🔍 Find What You Need

### By Role

**Backend Developer**
- [.NET Backend Skills](skills/HOW-TO-USE-SKILLS-DOTNET-BACKEND.md)
- [@api-architect](agents/HOW-TO-USE-API-ARCHITECT.md)
- [@unit-test-generator](agents/HOW-TO-USE-UNIT-TEST-GENERATOR.md)

**Tech Lead**
- [@migration-orchestrator](agents/HOW-TO-USE-MIGRATION-ANALYZER.md)
- [@epic-agent + @story-agent](agents/HOW-TO-USE-EPIC-STORY-AGENTS.md)
- [@knowledgebase-orchestrator](agents/HOW-TO-USE-KNOWLEDGEBASE-GENERATOR.md)

**Junior Developer**
- [@mentor](agents/HOW-TO-USE-MENTOR.md)
- [@debug](agents/HOW-TO-USE-DEBUG.md)
- [.NET Backend Skills](skills/HOW-TO-USE-SKILLS-DOTNET-BACKEND.md)

**DevOps/Cloud Engineer**
- [AWS Migration Skills](skills/HOW-TO-USE-SKILLS-AWS-MIGRATION.md)
- [@migration-orchestrator](agents/HOW-TO-USE-MIGRATION-ANALYZER.md)

**Product Manager**
- [@epic-agent](agents/HOW-TO-USE-EPIC-STORY-AGENTS.md) (create Epics from PRDs)

### By Task

**Writing Code**
- [.NET Backend Skills](skills/HOW-TO-USE-SKILLS-DOTNET-BACKEND.md) (inline guidance)
- [@api-architect](agents/HOW-TO-USE-API-ARCHITECT.md) (API generation)

**Testing**
- [@unit-test-generator](agents/HOW-TO-USE-UNIT-TEST-GENERATOR.md) (generate xUnit tests)

**Debugging**
- [@debug](agents/HOW-TO-USE-DEBUG.md) (systematic investigation)

**Code Review**
- [@address-comments](agents/HOW-TO-USE-ADDRESS-COMMENTS.md) (fix PR comments)
- [@code-quality-guardian](agents/HOW-TO-USE-CODE-QUALITY-GUARDIAN.md) (⚠️ not yet implemented)

**Documentation**
- [@knowledgebase-orchestrator](agents/HOW-TO-USE-KNOWLEDGEBASE-GENERATOR.md) (complete docs)

**Refactoring**
- [@janitor](agents/HOW-TO-USE-JANITOR.md) (cleanup tech debt)

**Migration**
- [@migration-orchestrator](agents/HOW-TO-USE-MIGRATION-ANALYZER.md) (.NET modernization)
- [AWS Migration Skills](skills/HOW-TO-USE-SKILLS-AWS-MIGRATION.md) (SDK migration)

**Planning**
- [@epic-agent + @story-agent](agents/HOW-TO-USE-EPIC-STORY-AGENTS.md) (Agile breakdown)

**Git Workflow**
- [@git-commit](agents/HOW-TO-USE-GIT-COMMIT.md) (automated commits)

---

## 💡 Tips for Success

### General Tips

1. **Start with Quick Start sections** - All guides have 🚀 Quick Start examples
2. **Check tool availability** - Some agents are planned but not implemented (marked with ⚠️)
3. **VS Code vs Visual Studio** - Skills ONLY work in VS Code, not Visual Studio 2022
4. **Try examples first** - Run the provided examples to understand behavior

### Agent Tips

- Use `@agent-name` to invoke agents in VS Code
- Agents maintain conversation context - ask follow-up questions
- Most agents can work in VS Code or GitHub Copilot Mission Control
- Check the "When to Use" column to pick the right agent

### Skills Tips

- Skills work automatically in VS Code as you type - no special command needed
- Reload VS Code window after adding new skills: `Ctrl+Shift+P` → "Reload Window"
- Skills are most effective when following existing patterns in your codebase
- Check `.github/.ai/skills/` folder to see which skills are active

---

## 🆘 Getting Help

### Troubleshooting

Each guide has a 🐛 **Troubleshooting** section with common issues and solutions.

### Still Stuck?

1. Check the **Success Checklist** at the end of each guide
2. Review the **Best Practices** section
3. Try the **Example Sessions** to compare with your workflow
4. Contact your organization admin for setup issues

---

## 📚 Additional Resources

- [Main Repository README](../README.md)
- [AGENTS.md](../AGENTS.md) - Technical documentation for agent architecture
- [CONTRIBUTING.md](../CONTRIBUTING.md) - How to contribute skills or agents

---

## 🎯 Quick Links

### Most Popular Guides

1. [Git Commit Agent](agents/HOW-TO-USE-GIT-COMMIT.md) - Use daily
2. [.NET Backend Skills](skills/HOW-TO-USE-SKILLS-DOTNET-BACKEND.md) - Active while coding
3. [Knowledgebase Generator](agents/HOW-TO-USE-KNOWLEDGEBASE-GENERATOR.md) - Onboarding new devs
4. [Debug Agent](agents/HOW-TO-USE-DEBUG.md) - When things break
5. [Epic & Story Agents](agents/HOW-TO-USE-EPIC-STORY-AGENTS.md) - Sprint planning

### By Maturity

**Production-Ready**
- [@git-commit](agents/HOW-TO-USE-GIT-COMMIT.md)
- [@debug](agents/HOW-TO-USE-DEBUG.md)
- [@janitor](agents/HOW-TO-USE-JANITOR.md)
- [@mentor](agents/HOW-TO-USE-MENTOR.md)
- [@api-architect](agents/HOW-TO-USE-API-ARCHITECT.md)
- [@address-comments](agents/HOW-TO-USE-ADDRESS-COMMENTS.md)
- [@knowledgebase-orchestrator](agents/HOW-TO-USE-KNOWLEDGEBASE-GENERATOR.md)
- [@migration-orchestrator](agents/HOW-TO-USE-MIGRATION-ANALYZER.md)
- [@epic-agent + @story-agent](agents/HOW-TO-USE-EPIC-STORY-AGENTS.md)
- [@unit-test-generator](agents/HOW-TO-USE-UNIT-TEST-GENERATOR.md)
- [.NET Backend Skills](skills/HOW-TO-USE-SKILLS-DOTNET-BACKEND.md)
- [AWS Migration Skills](skills/HOW-TO-USE-SKILLS-AWS-MIGRATION.md)

**Planned/Not Yet Implemented**
- [@code-quality-guardian](agents/HOW-TO-USE-CODE-QUALITY-GUARDIAN.md) ⚠️

---

**Last Updated:** January 29, 2026

**Feedback?** Submit an issue or PR to improve these guides!
