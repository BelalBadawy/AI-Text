# How to Use .NET Backend Skills

## 🎯 Overview

.NET Backend Skills provide **real-time coding guidance** directly in VS Code while you write C#, ASP.NET Core, and .NET applications. These skills automatically activate when you work on relevant files and guide GitHub Copilot to follow your organization's standards.

**⚠️ IMPORTANT: Skills only work in VS Code (Visual Studio Code)**
- ❌ NOT available in Visual Studio 2022
- ❌ NOT available in Visual Studio for Mac
- ✅ Only works in VS Code with GitHub Copilot extension

---

## 📦 Available .NET Backend Skills

| Skill | What It Does | When It Activates |
|-------|--------------|-------------------|
| **dotnet-backend** | Core .NET development standards (.NET 8+, C# 13, DI, validation) | Any `.cs`, `.csproj`, `appsettings.json` file |
| **csharp-development** | C# coding conventions (naming, error handling, LINQ) | Any `.cs` file |
| **dotnet-upgrade** | Guidance for upgrading legacy .NET Framework to modern .NET | `.csproj`, migration projects |
| **dotnet-clean-architecture** | Clean Architecture patterns (layers, dependencies) | Architecture planning, new projects |
| **repository-pattern** | Repository and Unit of Work implementation | Data access layer files |
| **api-controller-generator** | RESTful API controller patterns | `*Controller.cs` files |
| **fluent-validation** | FluentValidation setup and usage | Validator classes, DTOs |
| **pipeline-behaviors** | MediatR pipeline behaviors (logging, validation) | MediatR handlers |
| **ef-core-configuration** | Entity Framework Core setup and best practices | DbContext files, migrations |
| **dapper-query-builder** | Dapper SQL query patterns | Data access with Dapper |
| **specification-pattern** | Specification pattern for complex queries | Query logic files |

---

## 🚀 Quick Start

### Step 1: Verify Skills Are Installed

Your repository needs skills in the `.github/.ai/skills/` folder:

```
your-repo/
└── .github/
    └── .ai/
        └── skills/
            ├── dotnet-backend.md
            ├── csharp-development.md
            ├── ef-core-configuration.md
            └── ... (other skills)
```

**How to get skills in your repo:**

**Option A: Automatic Distribution (Recommended)**
1. Your organization admin adds the GitHub topic `ai-rules-backend-dotnet` to your repository
2. Skills are automatically distributed via PR when Zelis.AI.Studio releases

**Option B: Manual Copy (For Individual Skills)**
1. Browse to [Zelis.AI.Studio/skills](https://github.com/Price-Optimization/Zelis.AI.Studio/tree/main/skills)
2. Navigate to the skill category you need (e.g., `dotnet-backend/dotnet-backend/`)
3. Copy the `SKILL.md` file
4. Create `.github/.ai/skills/` in your repo (if it doesn't exist)
5. Paste and rename to `{skill-name}.md` (e.g., `dotnet-backend.md`)
6. Commit and push

**Option C: Manual Request**

Contact your organization admin to manually distribute all skills to your repository.

### Step 2: Open VS Code

**Requirements:**
- VS Code (latest version)
- GitHub Copilot extension installed
- Signed in to GitHub Copilot

### Step 3: Start Coding!

Skills activate **automatically** when you work on matching files. Just start writing code and Copilot will follow the skill guidance.

---

## 💡 How Skills Work (Behind the Scenes)

```
1. You open a C# file (e.g., UserService.cs)
   ↓
2. GitHub Copilot scans .github/.ai/skills/*.md
   ↓
3. Finds skills with filePatterns: "**/*.cs"
   ↓
4. Loads those skills into context
   ↓
5. Copilot suggestions follow skill rules
```

**You don't need to do anything special** - just code normally!

---

## 📝 Example: Creating a New Service Class

### Without Skills
```csharp
// Copilot might suggest outdated patterns
public class UserService
{
    public static UserService Instance;
    
    public void GetUser(int id)
    {
        var user = db.Users.Find(id);
        return user;
    }
}
```

### With dotnet-backend Skill Active
```csharp
// Copilot follows modern patterns from the skill
public class UserService(
    IUserRepository repository,
    ILogger<UserService> logger)
{
    public async Task<User?> GetUserAsync(int id, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(repository);
        
        var user = await repository.GetByIdAsync(id, cancellationToken);
        if (user is null)
            logger.LogWarning("User {UserId} not found", id);
            
        return user;
    }
}
```

**What the skill enforced:**
- ✅ Primary constructor (C# 12 feature)
- ✅ Constructor injection for dependencies
- ✅ Async/await patterns
- ✅ Nullable reference types (`User?`)
- ✅ CancellationToken support
- ✅ Structured logging
- ✅ Null checking with modern syntax

---

## 📋 Common Scenarios

### Scenario 1: Creating an API Controller

**File:** `UsersController.cs`

**Skills activated:**
- `api-controller-generator` (specific patterns)
- `dotnet-backend` (general standards)
- `fluent-validation` (if validators exist)

**What you get:**
```csharp
[ApiController]
[Route("api/[controller]")]
public class UsersController(
    IMediator mediator,
    ILogger<UsersController> logger) : ControllerBase
{
    [HttpGet("{id:int}")]
    [ProducesResponseType<UserDto>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<UserDto>> GetUser(
        int id, 
        CancellationToken cancellationToken)
    {
        var query = new GetUserQuery { UserId = id };
        var result = await mediator.Send(query, cancellationToken);
        
        return result.IsSuccess 
            ? Ok(result.Value) 
            : NotFound();
    }
}
```

### Scenario 2: Setting Up DbContext

**File:** `ApplicationDbContext.cs`

**Skills activated:**
- `ef-core-configuration`
- `dotnet-backend`

**What you get:**
```csharp
public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) 
    : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        
        // Apply all configurations from assembly
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(ApplicationDbContext).Assembly);
        
        // Global query filters
        modelBuilder.Entity<User>()
            .HasQueryFilter(u => !u.IsDeleted);
    }
}

// Entity configuration in separate file
public class UserConfiguration : IEntityTypeConfiguration<User>
{
    public void Configure(EntityTypeBuilder<User> builder)
    {
        builder.HasKey(u => u.Id);
        builder.Property(u => u.Email).HasMaxLength(255).IsRequired();
        builder.HasIndex(u => u.Email).IsUnique();
    }
}
```

### Scenario 3: Creating a Repository

**File:** `UserRepository.cs`

**Skills activated:**
- `repository-pattern`
- `ef-core-configuration` (if using EF Core)
- `dapper-query-builder` (if using Dapper)

**What you get:**
```csharp
public interface IUserRepository
{
    Task<User?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task<IEnumerable<User>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<User> AddAsync(User user, CancellationToken cancellationToken = default);
    Task UpdateAsync(User user, CancellationToken cancellationToken = default);
    Task DeleteAsync(int id, CancellationToken cancellationToken = default);
}

public class UserRepository(ApplicationDbContext context) : IUserRepository
{
    public async Task<User?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        return await context.Users
            .AsNoTracking()
            .FirstOrDefaultAsync(u => u.Id == id, cancellationToken);
    }
    
    // ... other methods
}
```

---

## 🎓 Beginner Tips

### Tip 1: Trust the Suggestions

When Copilot suggests code, it's following your organization's standards from the skills. The suggestions are **tailored to your team's practices**.

### Tip 2: Use Copilot Chat for Explanations

If you don't understand a suggestion:

```
Why did Copilot suggest using primary constructors here?
```

Copilot will explain based on the skill rules.

### Tip 3: Skills Apply to Chat Too

When you ask Copilot Chat questions, it follows the same skills:

```
How do I create a new service class that calls the database?
```

The answer will follow `dotnet-backend`, `repository-pattern`, and `ef-core-configuration` standards.

### Tip 4: Check Which Skills Are Active

Look in `.github/.ai/skills/` to see what skills your repository has.

### Tip 5: Skills Prevent Common Mistakes

Skills automatically prevent:
- ❌ Using outdated .NET Framework patterns
- ❌ Forgetting async/await
- ❌ Missing null checks
- ❌ Improper dependency injection
- ❌ SQL injection vulnerabilities
- ❌ Missing cancellation tokens

---

## 🔍 Verifying Skills Are Working

### Test 1: Check Inline Suggestions

1. Create a new file: `TestService.cs`
2. Type: `public class TestService`
3. Hit Enter

**Expected:** Copilot suggests a constructor with dependency injection parameters.

### Test 2: Check Chat Responses

1. Open Copilot Chat
2. Ask: `Create a new API controller for managing products`

**Expected:** Response follows API controller patterns, includes proper route attributes, status codes, and async methods.

### Test 3: Verify File Patterns

1. Open `.github/.ai/skills/dotnet-backend.md`
2. Look for `filePatterns:` section
3. Should include: `**/*.cs`, `**/*.csproj`, etc.

---

## ⚙️ Customizing Skills (For Admins)

Skills are maintained in the [Zelis.AI.Studio](https://github.com/Price-Optimization/Zelis.AI.Studio) repository. To request changes:

1. Open an issue describing the change needed
2. Or submit a PR modifying the skill file in `skills/dotnet-backend/*/SKILL.md`

**Common customizations:**
- Adding new patterns
- Updating framework versions (e.g., .NET 10)
- Adding organization-specific conventions
- Including new NuGet packages

---

## 🆘 Troubleshooting

### Problem: Skills don't seem to be working

**Checklist:**
- [ ] Are you using **VS Code** (not Visual Studio)?
- [ ] Is GitHub Copilot extension installed and active?
- [ ] Does `.github/.ai/skills/` folder exist?
- [ ] Do skills have `.md` extension?
- [ ] Are you signed in to GitHub Copilot?

### Problem: Suggestions don't match the skills

**Solution:** Reload VS Code window:
1. Open Command Palette (`Ctrl+Shift+P` or `Cmd+Shift+P`)
2. Type: `Developer: Reload Window`
3. Try again

### Problem: Missing skills in my repository

**Solution:** Ask your organization admin to:
1. Add the GitHub topic `ai-rules-backend-dotnet` to your repo
2. Wait for the next Zelis.AI.Studio release
3. Or manually request skill distribution

---

## 📚 Related Skills

Skills often work together:

```
Creating a CQRS Feature:
  ↓
  api-controller-generator (controller)
  ↓
  pipeline-behaviors (MediatR setup)
  ↓
  fluent-validation (request validation)
  ↓
  repository-pattern (data access)
  ↓
  ef-core-configuration (DbContext)
```

---

## 🎯 Best Practices

1. **Let Copilot generate boilerplate** - Skills make generated code production-ready
2. **Review suggestions** - Skills guide, but you still review and approve
3. **Use consistent naming** - Skills enforce naming conventions
4. **Follow file patterns** - Name files to match skill activation patterns
5. **Keep skills updated** - Skills improve over time with new releases

---

## 📖 Further Reading

- [CONTRIBUTING.md](../CONTRIBUTING.md) - How skills are structured
- [Zelis.AI.Studio Repository](https://github.com/Price-Optimization/Zelis.AI.Studio) - Source of all skills
- [GitHub Copilot Documentation](https://docs.github.com/en/copilot) - Official Copilot docs

---

**Questions?** Contact your organization's AI/DevOps team or open an issue in [Zelis.AI.Studio](https://github.com/Price-Optimization/Zelis.AI.Studio).
