# How to Use AWS Migration Skills

## 🎯 Overview

AWS Migration Skills provide **step-by-step guidance** for migrating .NET applications from Azure SDKs to AWS SDKs. These skills help you convert Azure services (Key Vault, Blob Storage, Functions, etc.) to their AWS equivalents while preserving your existing extension method signatures.

**⚠️ IMPORTANT: Skills only work in VS Code (Visual Studio Code)**
- ❌ NOT available in Visual Studio 2022
- ❌ NOT available in Visual Studio for Mac
- ✅ Only works in VS Code with GitHub Copilot extension

---

## 📦 Available AWS Migration Skills

| Skill | Azure Service | AWS Service | Complexity |
|-------|--------------|-------------|------------|
| **azure-keyvault-to-secrets** | Key Vault | Secrets Manager | Medium |
| **azure-appconfig-to-aws-appconfig** | App Configuration | AWS AppConfig | Medium-High |
| **azure-appinsights-to-cloudwatch** | Application Insights | CloudWatch + X-Ray | Medium-High |
| **azure-storagequeues-to-sqs** | Storage Queues | SQS | Medium |
| **azure-storage-to-s3** | Blob Storage | S3 | Medium |
| **azure-servicebus-to-sqs-sns** | Service Bus | SQS + SNS | High |
| **azure-functions-to-lambda** | Azure Functions | Lambda | **Very High** |

---

## 🚀 Quick Start

### Step 1: Get Migration Skills in Your Repository

**Option A: Automatic Distribution (Recommended)**

Your organization admin adds the GitHub topic to your repo:
1. Go to your repository → Settings → Topics
2. Add topic: `ai-rules-aws-migration`
3. Wait for automatic PR with skills (created on next Zelis.AI.Studio release)

**Option B: Manual Copy (For Individual Skills)**

1. Browse to [Zelis.AI.Studio/skills/aws-migration](https://github.com/Price-Optimization/Zelis.AI.Studio/tree/main/skills/aws-migration)
2. Select the specific skill you need (e.g., `azure-keyvault-to-secrets/`)
3. Copy the `SKILL.md` file content
4. In your repository, create `.github/.ai/skills/` folder (if it doesn't exist)
5. Create a new file: `.github/.ai/skills/{skill-name}.md` (e.g., `azure-keyvault-to-secrets.md`)
6. Paste the skill content
7. Commit and push to your repository
8. Reload VS Code window to activate the skill

**Option C: Manual Request**

Contact your organization admin to manually distribute all skills to your repository.

### Step 2: Verify Skills Are Installed

Check that your repository has the migration skills:

```
your-repo/
└── .github/
    └── .ai/
        └── skills/
            ├── azure-keyvault-to-secrets.md
            ├── azure-appconfig-to-aws-appconfig.md
            ├── azure-appinsights-to-cloudwatch.md
            ├── azure-storagequeues-to-sqs.md
            ├── azure-storage-to-s3.md
            ├── azure-servicebus-to-sqs-sns.md
            └── azure-functions-to-lambda.md
```

### Step 3: Open Your Project in VS Code

**Requirements:**
- VS Code (latest version)
- GitHub Copilot extension installed
- Signed in to GitHub Copilot

### Step 4: Start Migration!

Skills activate **automatically** when you work on Azure SDK code. Copilot will suggest AWS equivalents following the skill guidance.

---

## 💡 How Migration Skills Work

```
1. You open a file using Azure SDK (e.g., BlobService.cs)
   ↓
2. GitHub Copilot detects Azure packages
   ↓
3. Loads matching migration skills
   ↓
4. Suggests AWS SDK equivalents
   ↓
5. Preserves your extension method signatures
```

---

## 📝 Example Migration: Azure Key Vault → AWS Secrets Manager

### Before (Azure Key Vault)

```csharp
// Using Azure.Security.KeyVault.Secrets
public class AzureSecretService : ISecretService
{
    private readonly SecretClient _client;

    public AzureSecretService(SecretClient client)
    {
        _client = client;
    }

    public async Task<string?> GetSecretAsync(string secretName)
    {
        KeyVaultSecret secret = await _client.GetSecretAsync(secretName);
        return secret.Value;
    }
}
```

### After (AWS Secrets Manager) - With Skill Guidance

**Step 1:** Ask Copilot Chat

```
@workspace I need to migrate this Azure Key Vault service to AWS Secrets Manager. 
The extension method signatures must stay the same.
```

**Step 2:** Copilot follows the `azure-keyvault-to-secrets` skill and suggests:

```csharp
// Using AWSSDK.SecretsManager
public class AwsSecretService : ISecretService
{
    private readonly IAmazonSecretsManager _client;
    private readonly string _secretPrefix;

    public AwsSecretService(IAmazonSecretsManager client, IConfiguration configuration)
    {
        _client = client;
        _secretPrefix = configuration["SecretsManager:SecretPrefix"] ?? string.Empty;
    }

    public async Task<string?> GetSecretAsync(string secretName)
    {
        try
        {
            var request = new GetSecretValueRequest
            {
                SecretId = $"{_secretPrefix}{secretName}"
            };
            
            var response = await _client.GetSecretValueAsync(request);
            return response.SecretString;
        }
        catch (ResourceNotFoundException)
        {
            return null;
        }
    }
}
```

**What the skill provided:**
- ✅ Correct AWS package reference
- ✅ IAM requirements documentation
- ✅ Configuration pattern
- ✅ Same method signature (`GetSecretAsync(string)`)
- ✅ Error handling for not-found scenarios
- ✅ Terraform infrastructure examples

---

## 📋 Migration Workflow (Recommended Approach)

### Phase 1: Foundation Services (Start Here)

Migrate in this order:

1. **Azure Key Vault → AWS Secrets Manager**
   - Easiest migration
   - Required by other services
   - Critical for configuration

2. **Azure App Configuration → AWS AppConfig**
   - Handles Labels → Profiles + Environments mapping
   - Foundation for feature flags

3. **Azure Application Insights → CloudWatch + X-Ray**
   - Set up observability FIRST
   - Critical for monitoring migration progress

### Phase 2: Storage & Messaging

4. **Azure Storage Queues → SQS**
   - Simple queue patterns
   - Foundation for async processing

5. **Azure Blob Storage → S3**
   - File storage migration
   - Larger surface area but straightforward

6. **Azure Service Bus → SQS + SNS** (Optional)
   - If you use topics/subscriptions
   - More complex (combines two AWS services)

### Phase 3: Compute (Last)

7. **Azure Functions → Lambda**
   - Most complex migration
   - Do this AFTER all dependencies migrated
   - Requires significant refactoring

---

## 🎓 Beginner Guide: Migrating Your First Service

### Example: Migrating a Key Vault Service

**Step 1: Identify Azure SDK Usage**

Open Copilot Chat:
```
@workspace Find all files using Azure.Security.KeyVault
```

**Step 2: Ask for Migration Plan**

```
@workspace I need to migrate our Azure Key Vault service to AWS Secrets Manager.
Show me what needs to change.
```

**Step 3: Update NuGet Packages**

Copilot will suggest updating your `.csproj`:

```xml
<!-- Remove -->
<PackageReference Include="Azure.Security.KeyVault.Secrets" Version="4.x.x" />

<!-- Add -->
<PackageReference Include="AWSSDK.SecretsManager" Version="3.7.x" />
```

**Step 4: Update Service Registration**

In `Program.cs`:

```csharp
// Before (Azure)
services.AddSingleton(sp =>
{
    var vaultUri = new Uri(config["KeyVault:VaultUri"]!);
    return new SecretClient(vaultUri, new DefaultAzureCredential());
});

// After (AWS) - Copilot suggests
services.AddDefaultAWSOptions(configuration.GetAWSOptions());
services.AddAWSService<IAmazonSecretsManager>();
```

**Step 5: Convert Implementation**

Select your Azure service class code, open Copilot Chat:

```
Convert this to use AWS Secrets Manager, keeping the same interface
```

**Step 6: Update Configuration**

In `appsettings.json`:

```json
// Before (Azure)
{
  "KeyVault": {
    "VaultUri": "https://my-vault.vault.azure.net/"
  }
}

// After (AWS) - Copilot suggests
{
  "AWS": {
    "Region": "us-east-1"
  },
  "SecretsManager": {
    "SecretPrefix": "myapp/"
  }
}
```

**Step 7: Review IAM Requirements**

Ask Copilot:
```
What IAM permissions do I need for Secrets Manager?
```

Copilot will show you the required policy (from the skill).

**Step 8: Test Locally**

Set up Localstack (Copilot provides docker-compose):
```
@workspace How do I test Secrets Manager locally?
```

---

## 🔍 Using the Migration Orchestrator Agent

For comprehensive migration across multiple Azure services, use the orchestrator:

### Option 1: VS Code Chat

```
@workspace Run aws-migration-orchestrator to analyze this repository
```

The orchestrator will:
1. ✅ Scan for all Azure SDK dependencies
2. ✅ Generate migration plan (phased approach)
3. ✅ Identify which skills to use
4. ✅ Validate extension methods preserved
5. ✅ Generate IAM policies
6. ✅ Create complete documentation in `docs/aws-migration/`

### Option 2: Mission Control (For Multiple Repos)

1. Open GitHub Copilot Mission Control
2. Select repositories to migrate
3. Select agent: `aws-migration-orchestrator`
4. Prompt: `Analyze for Azure SDK dependencies and generate AWS migration plan`

---

## 💡 Common Migration Scenarios

### Scenario 1: Simple Key-Value Storage

**What you're migrating:**
- Azure Key Vault (secrets only)
- Azure App Configuration (basic config)

**Skills needed:**
- `azure-keyvault-to-secrets`
- `azure-appconfig-to-aws-appconfig`

**Effort:** 2-3 days

### Scenario 2: Queue-Based Processing

**What you're migrating:**
- Azure Storage Queues
- Azure Blob Storage (for message payloads)

**Skills needed:**
- `azure-storagequeues-to-sqs`
- `azure-storage-to-s3`

**Effort:** 1 week

### Scenario 3: Full Serverless Application

**What you're migrating:**
- Azure Functions (HTTP + Queue triggers)
- Azure Key Vault
- Azure Storage
- Application Insights

**Skills needed:**
- All 7 migration skills

**Effort:** 3-4 weeks

---

## 📊 Complexity Guide

### 🟢 Low Complexity (Good Starting Points)

- **Azure Key Vault → Secrets Manager**
  - Direct API mapping
  - Few configuration changes
  - Straightforward IAM policies

- **Azure Storage Queues → SQS**
  - Similar concepts (queues, messages, visibility)
  - Minor API differences

### 🟡 Medium Complexity

- **Azure Blob Storage → S3**
  - Large API surface
  - Different access control model
  - Multipart upload patterns

- **Azure App Configuration → AWS AppConfig**
  - Labels → Environments mapping required
  - Deployment model different

- **Application Insights → CloudWatch + X-Ray**
  - Two services instead of one
  - Different query languages (KQL → Insights queries)

### 🔴 High Complexity (Do Last)

- **Azure Service Bus → SQS + SNS**
  - Topic/subscription model requires two AWS services
  - Message envelope unwrapping needed
  - No native session support

- **Azure Functions → Lambda**
  - Complete programming model change
  - DI setup different
  - Separate deployment per function
  - API Gateway integration required
  - Trigger patterns different

---

## ⚙️ Best Practices

### 1. Preserve Extension Methods

**DO:**
```csharp
// Keep the same interface
public interface ISecretService
{
    Task<string?> GetSecretAsync(string secretName);
}
```

**DON'T:**
```csharp
// Don't change the interface
public interface ISecretService
{
    Task<string?> GetAwsSecretAsync(AwsSecretRequest request); // ❌
}
```

### 2. Use Environment Variables for AWS Credentials

**DO (Production):**
```csharp
// Let AWS SDK use IAM roles automatically
services.AddDefaultAWSOptions(configuration.GetAWSOptions());
services.AddAWSService<IAmazonS3>();
```

**DON'T:**
```csharp
// Don't hardcode credentials
var client = new AmazonS3Client("AKIAIOSFODNN7EXAMPLE", "secret"); // ❌
```

### 3. Test with Localstack First

Before deploying to AWS, test locally:

```yaml
# docker-compose.yml
services:
  localstack:
    image: localstack/localstack:latest
    ports:
      - "4566:4566"
    environment:
      - SERVICES=s3,sqs,secretsmanager
```

### 4. Migrate One Service at a Time

Don't try to migrate everything at once. Complete order:
1. Key Vault ✅
2. App Configuration ✅
3. Application Insights ✅
4. Storage Queues ✅
5. Blob Storage ✅
6. Service Bus (if needed) ✅
7. Functions ✅

### 5. Document IAM Policies

Every skill provides IAM policy examples. Collect them as you migrate:

```
docs/aws-migration/
├── iam-requirements.md
├── keyvault-conversion.md
├── storage-conversion.md
└── ...
```

---

## 🆘 Troubleshooting

### Problem: Skills not providing AWS-specific suggestions

**Solution:**
1. Ensure `.github/.ai/skills/azure-*-to-*.md` files exist
2. Make sure you're working on Azure SDK code (Copilot detects context)
3. Try explicitly asking: `@workspace How do I migrate this to AWS?`

### Problem: Suggestions don't match skill patterns

**Solution:** Reload VS Code:
1. Command Palette (`Ctrl+Shift+P`)
2. `Developer: Reload Window`

### Problem: Missing Terraform examples

**Solution:** Ask Copilot directly:
```
@workspace Show me the Terraform for deploying this to AWS
```

The skills include infrastructure-as-code examples.

### Problem: Don't understand AWS service differences

**Solution:** Ask for comparison:
```
What's the difference between Azure Key Vault and AWS Secrets Manager?
```

Each skill includes comparison tables.

---

## 📚 Additional Resources

### Each Skill Includes:

- ✅ Package migration guide
- ✅ Configuration examples (before/after)
- ✅ Code examples (before/after)
- ✅ IAM policies required
- ✅ Terraform infrastructure examples
- ✅ Localstack testing setup
- ✅ Common pitfalls and solutions
- ✅ Complete migration checklist

### Documentation Generated by Orchestrator:

When using `aws-migration-orchestrator`, you get:

```
docs/aws-migration/
├── README.md                    # Executive summary
├── migration-plan.md            # Phased approach
├── azure-dependencies.md        # What you're using
├── aws-equivalents.md           # Service mappings
├── contract-validation.md       # API compatibility
├── iam-requirements.md          # All policies
├── testing-strategy.md          # Localstack setup
└── configuration-changes.md     # Config migration
```

---

## 🎯 Success Checklist

Before marking migration complete:

- [ ] All Azure SDK packages removed
- [ ] All AWS SDK packages added
- [ ] Extension method signatures unchanged
- [ ] IAM policies created and applied
- [ ] Configuration migrated to AWS patterns
- [ ] Localstack tests passing
- [ ] Integration tests updated
- [ ] Documentation updated
- [ ] Team trained on AWS patterns
- [ ] Monitoring/alerting working in CloudWatch

---

## 📖 Related Documentation

- [HOW-TO-USE-MIGRATION-ANALYZER.md](HOW-TO-USE-MIGRATION-ANALYZER.md) - For .NET Framework → .NET migration
- [CONTRIBUTING.md](../CONTRIBUTING.md) - How skills are structured
- [Zelis.AI.Studio](https://github.com/Price-Optimization/Zelis.AI.Studio) - Source of all skills

---

**Questions?** Contact your organization's cloud migration team or open an issue in [Zelis.AI.Studio](https://github.com/Price-Optimization/Zelis.AI.Studio).
