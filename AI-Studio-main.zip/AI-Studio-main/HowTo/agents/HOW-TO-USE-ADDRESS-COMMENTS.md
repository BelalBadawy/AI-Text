# How to Use @address-comments (Automatic PR Mode)

## 🚀 Quick Start

### Automatic Mode (NEW!)

Simply provide the PR link:

```
@address-comments https://github.com/myorg/myrepo/pull/456
```

Or just the PR number:

```
@address-comments PR #456
```

The AI will:
1. ✅ Fetch all review comments from GitHub
2. ✅ Organize them by priority
3. ✅ Show you a summary
4. ✅ Fix each comment automatically
5. ✅ Run tests after each fix
6. ✅ Create commits with proper messages
7. ✅ Give you a final summary

---

## 📊 Example Session

### Input:
```
@address-comments https://github.com/zelis/payment-service/pull/789
```

### AI Response:
```
Fetching comments from PR #789...

Found 7 human review comments:
(Excluded 15 GitHub Copilot automated suggestions)

Priority 1 - Requested Changes (2):
  ❌ Services/UserService.cs:45 
     "Replace .Result with await to prevent deadlocks"
     
  ❌ Controllers/OrderController.cs:89
     "Add null check for customer parameter"

Priority 2 - Suggestions (3):
  💡 Services/PaymentService.cs:23
     "Consider extracting this complex validation logic"
     
  💡 Multiple files (3 locations)
     "Use ConfigureAwait(false) in library methods"
     
  💡 Repositories/OrderRepository.cs:156
     "Consider using async LINQ methods here"

Priority 3 - Nitpicks (2):
  📝 README.md:15
     "Fix typo: 'recieve' → 'receive'"
     
  📝 Tests/UserServiceTests.cs:89
     "Add empty line for readability"

Start addressing? 
  [yes] - Address all human comments
  [pick] - Choose which to address
  [show-copilot] - View excluded Copilot suggestions
  [all] - Include Copilot comments too
  [no] - Cancel
```

### You respond:
```
yes
```

### AI proceeds:
```
📍 [1/7] Services/UserService.cs:45
    Comment: "Replace .Result with await to prevent deadlocks"
    
    ✓ Located code
    ✓ Found 2 more instances of .Result in this file
    ✓ Replaced all with await
    ✓ Added async modifiers to calling methods
    ✓ Added ConfigureAwait(false)
    ✓ Tests passed ✅
    
    Committed:
    ─────────────────────────────────────────
    Address PR review: Replace .Result with await
    
    - Replaced .Result with await in 3 locations
    - Added async modifier to GetUserDetails method
    - Applied ConfigureAwait(false) for library code
    
    Addresses: #789 (Jane Reviewer)
    ─────────────────────────────────────────

📍 [2/7] Controllers/OrderController.cs:89
    Comment: "Add null check for customer parameter"
    
    ✓ Located code
    ✓ Added null validation with ArgumentNullException
    ✓ Added similar checks to other public methods
    ✓ Tests passed ✅
    
    Committed:
    ─────────────────────────────────────────
    Address PR review: Add null validation
    
    - Added null check for customer parameter
    - Throws ArgumentNullException with parameter name
    - Applied same pattern to 2 other methods
    
    Addresses: #789 (Jane Reviewer)
    ─────────────────────────────────────────

[Continues for remaining comments...]

✅ All 7 comments addressed!

Summary:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ 2 requested changes: Fixed
✅ 3 suggestions: Implemented
✅ 2 nitpicks: Fixed

📝 7 commits created
🧪 All tests passing

Ready to push these changes? (yes/no)
```

---

## 🤖 GitHub Copilot Comments (Automatic Exclusion)

**By default, GitHub Copilot review comments are automatically excluded!**

### Why Exclude Copilot?

1. **Focus on Human Feedback**: Human reviewers understand your specific context
2. **Generic Suggestions**: Copilot suggestions are often generic style preferences
3. **Volume**: Copilot can generate many comments that may not be relevant
4. **Priority**: Human reviewers' feedback should be addressed first

### What Gets Filtered Out

Comments from these sources are automatically excluded:
- `github-copilot[bot]`
- `copilot`
- `github-actions[bot]`
- Other automated review bots

### Example

```
@address-comments PR #789

AI: Found 7 human review comments:
    (Excluded 15 GitHub Copilot automated suggestions)
    
    Focusing on human reviewers: Jane Doe, John Smith
```

### Options for Copilot Comments

#### Option 1: View Excluded Copilot Comments
```
After seeing the summary, respond with:
show-copilot

AI will show:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Excluded Copilot suggestions (15):

💡 UserService.cs:23 (Copilot)
   "Consider using var for type inference"
   
💡 OrderService.cs:45 (Copilot)
   "Suggestion: Use string interpolation here"
   
💡 PaymentService.cs:67 (Copilot)
   "Consider adding XML documentation"
   
[... 12 more ...]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

These are NOT being addressed.
Still addressing only human comments? (yes/no)
```

#### Option 2: Include Copilot Comments
```
After seeing the summary, respond with:
all

AI will ask:
Now including 15 Copilot suggestions.
Total: 22 comments (7 human + 15 Copilot)

Would you like to:
[separate] - Address human comments first, then Copilot
[together] - Address all together by priority
```

#### Option 3: Only Process Copilot (Rare)
```
@address-comments PR #789 --only-copilot

AI will:
Found 15 Copilot suggestions:
(Ignoring 7 human comments)

Process Copilot suggestions? (yes/no)
```

### Recommended Workflow

1. **First**: Address human reviewer comments (default)
   ```
   @address-comments PR #789
   yes
   ```

2. **Then**: Review code after human comments fixed

3. **Optionally**: Review Copilot suggestions
   ```
   show-copilot
   ```

4. **Selectively**: Pick useful Copilot suggestions if any
   ```
   I'll manually fix the var inference and string interpolation suggestions
   ```

---

## 🎛️ Usage Options

### 1. Automatic - Process All
```
@address-comments https://github.com/org/repo/pull/123
yes
```

### 2. Automatic - Choose Specific Comments
```
@address-comments https://github.com/org/repo/pull/123
pick
```

AI will ask which ones to address:
```
Which comments? (enter numbers separated by commas, or 'all')
Examples: 1,2,5 or 1-3,7 or all
```

### 3. Automatic - Skip Nitpicks
```
@address-comments https://github.com/org/repo/pull/123 --skip-nitpicks
```

### 4. Manual Mode (Original)
```
@address-comments 

The reviewer said: "Add error handling for null responses"
File: PaymentService.cs, line 67
```

---

## 🎯 What Gets Addressed

### Priority 1: Requested Changes ❌
**These MUST be fixed** - They block PR approval

Examples:
- Security issues
- Breaking changes
- Critical bugs
- Reviewer marked "Request Changes"

**AI Action**: Addresses immediately, runs tests thoroughly

### Priority 2: Suggestions 💡
**These SHOULD be fixed** - Improve code quality

Examples:
- Performance improvements
- Refactoring suggestions
- Best practice recommendations
- Code organization

**AI Action**: Implements if it improves code, asks if unsure

### Priority 3: Nitpicks 📝
**Nice to have** - Minor style/formatting

Examples:
- Typos
- Whitespace
- Minor naming preferences
- Comment formatting

**AI Action**: Fixes quickly, can batch into one commit

---

## 📋 Commit Message Format

Each fix gets its own commit following this format:

```
Address PR review: [brief summary]

- [What was changed]
- [Why it was changed]
- [What else was affected]

Addresses: #[PR_NUMBER] ([Reviewer Name])
```

**Real Example:**
```
Address PR review: Use async/await instead of blocking calls

- Replaced .Result with await in UserService.GetUserAsync
- Replaced .Wait() with await in 2 other methods
- Added async modifier to calling methods
- Applied ConfigureAwait(false) for library code
- Updated tests to use async patterns

Addresses: #789 (Jane Reviewer)
```

---

## 🔧 Advanced Options

### Process Only Specific Files
```
@address-comments PR #123 --files "Services/*.cs"
```

### Batch Commits
```
@address-comments PR #123 --batch-commits
```
All fixes in one commit instead of one per comment

### Dry Run
```
@address-comments PR #123 --dry-run
```
Shows what would be fixed without making changes

### Skip Tests
```
@address-comments PR #123 --skip-tests
```
Don't run tests after each fix (not recommended!)

---

## ❓ Common Scenarios

### Scenario 1: Reviewer Requests Multiple Related Changes
```
@address-comments PR #456

AI will group related comments and fix them together
Example: All naming convention issues → One commit
```

### Scenario 2: Comment Needs Clarification
```
AI: ⚠️ Comment unclear: "Fix the thing in the controller"
    
    Found 3 possible interpretations:
    1. Add null check to CreateOrder method
    2. Extract validation logic
    3. Improve error handling
    
    Which did reviewer mean? (or should I ask them?)
```

### Scenario 3: You Disagree with a Comment
```
AI: 📍 Suggestion: "Add try-catch around everything"
    
    ⚠️ This may not be best practice. Adding blanket try-catch 
    can hide bugs and make debugging harder.
    
    Alternatives:
    1. Add specific try-catch for known exceptions
    2. Use global exception handler
    3. Let exceptions bubble up with proper logging
    
    What would you like to do?
    [1/2/3/implement anyway/discuss with reviewer]
```

### Scenario 4: Tests Fail After Fix
```
AI: ❌ Tests failed after fixing comment

    Failed: UserServiceTests.GetUser_WhenCalled_ReturnsUser
    
    Error: Expected async method but got sync
    
    This is because we changed the method to async.
    Fixing the test...
    
    ✓ Test updated to use async pattern
    ✓ Tests passed ✅
```

---

## 🚨 Troubleshooting

### "Can't fetch PR comments"

**Possible causes:**
- GitHub token not configured
- No internet connection
- PR URL is incorrect
- Repo is private and you don't have access

**Solution:**
```
@address-comments

Then provide comments manually:
"Reviewer said: [comment text]"
```

### "Can't find file mentioned in comment"

**Possible causes:**
- Wrong branch checked out
- File was renamed/moved
- Comment is on code that was removed

**Solution:**
AI will ask: 
```
Can't find Services/UserService.cs mentioned in comment.
- Is the PR branch checked out?
- Was this file renamed?
- Provide new location?
```

### "Don't know how to run tests"

**Solution:**
AI will ask:
```
How do I run tests for this project?
Examples:
- dotnet test
- npm test
- pytest
- mvn test
```

---

## 💡 Pro Tips

### 1. Check Out PR Branch First
```bash
git fetch origin pull/123/head:pr-123
git checkout pr-123
```
Then:
```
@address-comments PR #123
```

### 2. Review Changes Before Pushing
After AI addresses all comments:
```
no  # Don't push yet
```
Then review with:
```
git log -5 --oneline
git diff HEAD~5
```

### 3. Combine with Code Review Mode
```
@code-quality-guardian Review my changes
@address-comments PR #123
```

### 4. Create PR Comment Responses
After fixes:
```
@address-comments Reply to reviewer with summary
```

AI will generate:
```
Thanks for the review! I've addressed all comments:

✅ Replaced .Result with await (commit abc123)
✅ Added null validation (commit def456)
✅ Extracted validation logic (commit ghi789)
✅ Fixed typos (commit jkl012)

All tests passing. Ready for re-review!
```

---

## 📚 Summary

| What You Want | What to Type |
|---------------|--------------|
| Fix all PR comments (excludes Copilot) | `@address-comments https://github.com/org/repo/pull/123` |
| Fix only human comments | `@address-comments PR #123` then `yes` |
| View excluded Copilot comments | After summary, type `show-copilot` |
| Include Copilot comments too | After summary, type `all` |
| Only Copilot comments (rare) | `@address-comments PR #123 --only-copilot` |
| Choose which to fix | `@address-comments PR #123` then `pick` |
| Skip nitpicks | `@address-comments PR #123 --skip-nitpicks` |
| Manual mode | `@address-comments "reviewer comment text"` |
| Batch commits | `@address-comments PR #123 --batch-commits` |
| Preview only | `@address-comments PR #123 --dry-run` |

---

**The chatmode makes PR reviews painless!** 🎉

Just paste the PR link, confirm, and watch it automatically:
- Fetch comments
- Fix issues
- Run tests
- Create commits
- Provide summary

All you do is review and push! 🚀

