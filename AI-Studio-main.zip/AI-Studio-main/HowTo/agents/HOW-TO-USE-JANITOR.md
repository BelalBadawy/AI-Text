# How to Use @janitor

## 🎯 Overview

The `@janitor` chatmode is your **aggressive code cleanup specialist** that eliminates technical debt through ruthless simplification. Its philosophy: **Less Code = Less Debt**. Every line of code is potential maintenance burden - the janitor removes safely and simplifies aggressively.

**Core Principle:** Deletion is the most powerful refactoring.

---

## 🚀 Quick Start

### Full Codebase Cleanup

```
@janitor

Clean up this entire solution. Remove dead code, unused dependencies, and simplify where possible.
```

### Targeted Cleanup

```
@janitor

Clean up Services/ directory - remove unused methods and simplify complex code.
```

### Dependency Audit

```
@janitor

Audit all NuGet packages and remove unused dependencies.
```

---

## 🧹 What Gets Cleaned

The Janitor performs **6 major cleanup categories**:

### 1. Code Elimination 🗑️

**Targets:**
- Unused functions, classes, interfaces
- Dead variables and fields
- Unused imports and using statements
- Unreachable code paths
- Commented-out code blocks
- Debug statements left in code

**Example:**
```
Before: 450 lines, 23 unused methods
After:  287 lines, all code in use (-36% reduction)
```

### 2. Simplification ⚡

**Targets:**
- Complex patterns → simpler alternatives
- Single-use functions → inlined
- Nested conditionals → flattened
- Custom implementations → built-in features
- Verbose code → concise equivalents

**Example:**
```csharp
// BEFORE (10 lines)
public bool IsValidEmail(string email)
{
    if (string.IsNullOrEmpty(email))
        return false;
    
    var regex = new Regex(@"^[^@\s]+@[^@\s]+\.[^@\s]+$");
    if (regex.IsMatch(email))
        return true;
    else
        return false;
}

// AFTER (2 lines)  
public bool IsValidEmail(string email) =>
    !string.IsNullOrEmpty(email) && 
    new Regex(@"^[^@\s]+@[^@\s]+\.[^@\s]+$").IsMatch(email);
```

### 3. Dependency Hygiene 📦

**Targets:**
- Unused NuGet packages
- Outdated packages with security vulnerabilities
- Heavy dependencies with lighter alternatives
- Duplicate functionality across packages
- Unnecessary transitive dependencies

**Example:**
```
Before: 47 packages (including 23 unused)
After:  24 packages (security vulnerabilities: 0)
Saved: ~45 MB in package size
```

### 4. Test Optimization 🧪

**Targets:**
- Obsolete tests for removed features
- Duplicate test scenarios
- Flaky tests with race conditions
- Meaningless tests (assert true = true)
- Overly complex test setup
- Missing critical path tests (adds them!)

**Example:**
```
Before: 234 tests (15 failing, 23 flaky, 45 duplicates)
After:  167 tests (0 failing, 0 flaky, all meaningful)
Added:  12 critical path tests
```

### 5. Documentation Cleanup 📝

**Targets:**
- Outdated comments
- Auto-generated boilerplate
- Redundant inline comments
- Obvious comments (// increment i)
- Stale references and broken links
- XML doc for private methods

**Example:**
```csharp
// BEFORE
/// <summary>
/// Gets the user by their ID
/// </summary>
/// <param name="id">The ID of the user</param>
/// <returns>Returns the user</returns>
// This method gets the user from database
// TODO: Optimize this later
// Created by: John, Date: 2019-03-15
public User GetUser(int id) // gets user by id
{
    // Query the database
    return _context.Users.Find(id); // returns user
}

// AFTER (let code speak for itself)
public User GetUser(int id) => 
    _context.Users.Find(id);
```

### 6. Infrastructure as Code 🏗️

**Targets:**
- Unused cloud resources in configs
- Redundant deployment scripts
- Overly complex CI/CD pipelines
- Environment-specific hardcoding
- Duplicate infrastructure patterns

---

## 📊 Example Cleanup Session

### Full Session Flow

```
You: @janitor
     
     Clean up this solution. It's grown over 3 years and has
     a lot of cruft.

Janitor: 🧹 Universal Janitor - Debt Removal Mode
         ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         
         Analyzing solution for technical debt...
         
         📊 INITIAL SCAN RESULTS:
         ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         
         Files:           247 (.cs files)
         Lines of Code:   89,450
         
         🗑️  Dead Code:
         ├─ Unused classes: 23
         ├─ Unused methods: 156  
         ├─ Unused fields: 89
         ├─ Commented code blocks: 45 (2,340 lines!)
         └─ Unreachable code: 34 instances
         
         📦 Dependencies:
         ├─ Total packages: 67
         ├─ Unused packages: 18
         ├─ Outdated packages: 12
         └─ Security vulnerabilities: 3 (HIGH)
         
         🔄 Complexity:
         ├─ Overly complex methods: 23 (can be simplified)
         ├─ Duplicate code blocks: 45 instances
         └─ Single-use abstractions: 12
         
         📝 Documentation:
         ├─ Obvious comments: 234
         ├─ Outdated comments: 56
         └─ Auto-generated bloat: 89 blocks
         
         🧪 Tests:
         ├─ Obsolete tests: 34
         ├─ Duplicate tests: 23
         └─ Flaky tests: 8
         
         💾 POTENTIAL SAVINGS:
         ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         Lines of Code:    ~18,500 lines can be removed (21%)
         Package Size:     ~87 MB saved
         Build Time:       ~2 minutes faster
         Maintenance:      ~167 fewer things to maintain
         
         Proceed with cleanup? (yes/no/selective)

You: yes

Janitor: 🗑️  PHASE 1: CODE ELIMINATION
         ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         
         Removing dead code...
         
         ✓ Deleted: Helpers/OldPaymentProcessor.cs (347 lines)
           Reason: No references, last used 2 years ago
         
         ✓ Deleted: 23 unused classes (4,567 lines total)
         
         ✓ Removed 156 unused methods:
           - UserService: 12 methods
           - OrderService: 23 methods
           - PaymentService: 8 methods
           [... continues ...]
         
         ✓ Removed 2,340 lines of commented-out code:
           - Most from 2019-2021
           - No explanation for why kept
           - Safe to delete
         
         ✓ Removed 89 unused fields
         
         ✓ Fixed 34 unreachable code blocks
         
         Phase 1 Complete: -7,234 lines
         
         
         ⚡ PHASE 2: SIMPLIFICATION
         ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         
         Simplifying complex code...
         
         ✓ OrderService.ValidateOrder
           Before: 45 lines, complexity 18
           After:  12 lines, complexity 4
           Method: Extracted validation rules, used early returns
         
         ✓ Inlined 23 single-use methods:
           Example: GetUserName() used once → inlined
           Saved: 156 lines of unnecessary abstraction
         
         ✓ Replaced custom implementations with built-ins:
           - Custom string validation → Regex or string methods
           - Custom date parsing → DateTime.TryParse
           - Custom collection helpers → LINQ
           Saved: 267 lines
         
         ✓ Flattened 34 nested conditionals:
           Average nesting: 6 levels → 2 levels
         
         Phase 2 Complete: -423 lines, +significant readability
         
         
         📦 PHASE 3: DEPENDENCY HYGIENE
         ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         
         Cleaning up dependencies...
         
         ✓ Removed 18 unused packages:
           - Newtonsoft.Json (using System.Text.Json now)
           - AutoMapper (3 usages, inlined)
           - 16 others with 0 references
           
         ✓ Updated 12 outdated packages:
           Security fixes for:
           - Microsoft.Data.SqlClient (HIGH severity)
           - System.IdentityModel.Tokens.Jwt (MEDIUM)
           - Azure.Storage.Blobs (MEDIUM)
         
         ✓ Consolidated duplicate functionality:
           - Had both Serilog AND NLog → kept Serilog
           - Had 3 HTTP client wrappers → kept 1
         
         Package count: 67 → 24 (-64%)
         Security vulnerabilities: 3 → 0
         
         Phase 3 Complete: Cleaner, safer dependency tree
         
         
         🧪 PHASE 4: TEST OPTIMIZATION
         ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         
         Optimizing test suite...
         
         ✓ Removed 34 obsolete tests:
           - Tests for deleted features
           - Tests for refactored code
         
         ✓ Consolidated 23 duplicate test scenarios:
           Example: 5 tests for "null input" → 1 parameterized test
         
         ✓ Fixed 8 flaky tests:
           - 3 had race conditions → added proper async/await
           - 5 had timing dependencies → removed Thread.Sleep
         
         ✓ Removed meaningless tests:
           Example: Assert.True(true) // wat
         
         ✓ Added 12 missing critical tests:
           - Payment processing edge cases
           - Order validation scenarios
         
         Test count: 234 → 189 (-19%, but better coverage!)
         Test reliability: 100% (no flaky tests)
         
         Phase 4 Complete: Faster, more reliable test suite
         
         
         📝 PHASE 5: DOCUMENTATION CLEANUP
         ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         
         Cleaning documentation...
         
         ✓ Removed 234 obvious comments:
           // increment i → deleted (code is obvious)
           // return user → deleted (return statement says this)
         
         ✓ Removed 89 auto-generated blocks:
           /// <summary>
           /// Gets or sets the name.
           /// </summary>
           For trivial properties → deleted
         
         ✓ Updated 56 outdated comments:
           References to old APIs → updated or removed
         
         ✓ Kept meaningful comments:
           - Business logic explanations
           - Algorithm complexity notes  
           - Non-obvious workarounds
         
         Phase 5 Complete: Signal-to-noise ratio improved
         
         
         ✅ CLEANUP COMPLETE
         ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         
         📊 FINAL RESULTS:
         
         Lines of Code:    89,450 → 71,293 (-18,157 lines, -20%)
         Files:            247 → 224 (-23 files)
         Packages:         67 → 24 (-43 packages, -87 MB)
         Tests:            234 → 189 (-45 tests, +12 critical)
         Security Issues:  3 → 0
         Build Time:       ~8 min → ~5.5 min
         
         Code Quality Improvements:
         ✓ Average complexity: 12 → 7
         ✓ Code duplication: 18% → 5%
         ✓ Test coverage: 67% → 78%
         ✓ Technical debt: HIGH → LOW
         
         🎉 The codebase is now 20% smaller, faster to build,
         easier to maintain, and more secure!
         
         Next Steps:
         1. Run full test suite (should pass)
         2. Review changes with git diff
         3. Create PR with changes
         4. Consider setting up pre-commit hooks to prevent
            accumulation of dead code
```

---

## 🎯 Cleanup Strategies

### Strategy 1: Aggressive Cleanup (Default)

```
@janitor

Aggressive cleanup - remove everything that's not being used.
```

**Approach:**
- Delete unused code without hesitation
- Simplify aggressively
- Inline single-use abstractions
- Remove all obvious comments
- Clean up all dependencies

**Risk Level:** Low (everything is tested first)

### Strategy 2: Conservative Cleanup

```
@janitor --conservative

Clean up but keep anything that might be used later.
```

**Approach:**
- Only remove clearly unused code
- Keep abstractions even if single-use
- Preserve comments that might be useful
- Keep dependencies "just in case"

**Result:** Less savings, safer for uncertain codebases

### Strategy 3: Focused Cleanup

```
@janitor

Focus on:
1. Security vulnerabilities in dependencies
2. Dead code removal
Skip simplification for now.
```

**Approach:**
- Target specific categories
- Leave others untouched
- Good for phased cleanup

### Strategy 4: Exploratory Analysis

```
@janitor --dry-run

Show me what could be cleaned without making changes.
```

**Result:** Report only, no changes made

---

## 🎯 Common Scenarios

### Scenario 1: Legacy Codebase Cleanup

```
@janitor

This codebase is 5 years old with lots of dead code.
Clean it up but be extra careful with business logic.
```

**Janitor Approach:**
1. Identifies unused code through usage analysis
2. Separates business logic from infrastructure
3. Removes infrastructure cruft aggressively
4. Preserves all business logic (even if unused)
5. Flags unused business logic for manual review

### Scenario 2: Pre-Refactoring Cleanup

```
@janitor

We're about to refactor the payment system.
Clean up Services/Payment* files first.
```

**Janitor Approach:**
1. Removes dead code in target area
2. Simplifies complex methods
3. Reduces cognitive load
4. Makes refactoring easier by removing noise

### Scenario 3: Dependency Audit Before Update

```
@janitor

Audit all NuGet packages before upgrading to .NET 9.
Remove unused ones, update others.
```

**Janitor Approach:**
1. Scans all package references
2. Identifies unused packages
3. Finds outdated versions
4. Checks for security vulnerabilities
5. Provides upgrade roadmap

### Scenario 4: Post-Feature Cleanup

```
@janitor

We just removed the reporting feature.
Clean up all related code.
```

**Janitor Approach:**
1. Traces all references to reporting
2. Identifies orphaned code
3. Removes safely (tests confirm)
4. Updates documentation

### Scenario 5: Test Suite Optimization

```
@janitor

Our test suite takes 20 minutes to run.
Optimize it without losing coverage.
```

**Janitor Approach:**
1. Identifies slow tests
2. Removes duplicate scenarios
3. Fixes flaky tests
4. Consolidates similar tests
5. Parallelizes where possible
6. Result: Faster suite, same coverage

---

## ⚙️ Advanced Features

### Feature 1: Debt Tracking

```
@janitor --track-debt

Generate technical debt report over time.
```

**Output:**
```
Technical Debt Trend:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Jan 2024: 23,400 lines of debt (HIGH)
Apr 2024: 18,900 lines of debt (MEDIUM) ↓ 19%
Jul 2024: 12,300 lines of debt (LOW) ↓ 35%
Oct 2024:  8,100 lines of debt (LOW) ↓ 34%

Trend: ↓ Improving (65% reduction in 9 months)

Categories:
├─ Dead Code: 89% reduced
├─ Duplication: 67% reduced  
├─ Complexity: 42% reduced
└─ Documentation: 78% reduced

Next cleanup recommended: December 2024
```

### Feature 2: Cleanup Rules

```
@janitor --define-rules

Create custom cleanup rules for this project.
```

**Example Rules:**
```yaml
rules:
  - name: "Remove Debug Logs"
    pattern: "Console.WriteLine"
    action: delete
    except: ["Tests/*"]
  
  - name: "Simplify Boolean Returns"
    pattern: "if (condition) return true; else return false;"
    replacement: "return condition;"
  
  - name: "Remove Commented Code"
    pattern: "//.*{10,}" # 10+ lines commented
    action: delete
    confirm: true
```

### Feature 3: Incremental Cleanup

```
@janitor --incremental

Clean up modified files only (for CI/CD integration).
```

**Use Case:**
```yaml
# .github/workflows/cleanup.yml
on: [pull_request]
jobs:
  cleanup:
    - uses: janitor --incremental
    - commit if changes
```

### Feature 4: Cleanup Visualization

```
@janitor --visualize

Show me a visual breakdown of technical debt.
```

**Output:**
```
Technical Debt by Category:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Dead Code         ████████████████████ 8,234 lines (45%)
Commented Code    ████████████ 4,567 lines (25%)
Duplicate Code    ████████ 3,123 lines (17%)
Complex Methods   ████ 1,890 lines (10%)
Obvious Comments  ██ 589 lines (3%)
                  
Total Debt: 18,403 lines

Technical Debt by Module:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Services/         ████████████████ 7,234 lines
Controllers/      ██████████ 4,567 lines
Repositories/     ████████ 3,123 lines
Models/           ████ 2,109 lines
Helpers/          ██ 1,370 lines
```

---

## 💡 Best Practices

### Do's ✅

1. **Run Tests After Cleanup**
   ```
   @janitor Clean up Services/ then run all tests
   ```

2. **Review Before Commit**
   ```
   @janitor --dry-run  # Review first
   @janitor            # Then execute
   ```

3. **Clean Incrementally**
   ```
   Week 1: Clean Services/
   Week 2: Clean Controllers/
   Week 3: Clean Infrastructure/
   ```

4. **Track Progress**
   ```
   @janitor --report
   # Save report, compare next month
   ```

### Don'ts ❌

1. **Don't Skip Tests**
   ```
   ❌ @janitor --skip-tests Clean everything
   ✅ @janitor Clean and verify with tests
   ```

2. **Don't Clean Without Version Control**
   ```
   ❌ Clean on uncommitted changes
   ✅ Commit first, then clean, then review diff
   ```

3. **Don't Remove "Unused" Public APIs**
   ```
   ❌ Delete public methods (might be used externally)
   ✅ Flag for manual review
   ```

4. **Don't Clean Before Understanding**
   ```
   ❌ Clean unfamiliar codebase blindly
   ✅ Understand architecture first, then clean
   ```

---

## 🚨 Safety Mechanisms

### 1. Test-Driven Cleanup

Before every deletion:
```
✓ Run affected tests
✓ Ensure all pass
✓ Only then delete
```

### 2. Backup Points

Creates restore points:
```
Cleanup started: commit sha abc123
Changes made: 234 files
Restore command: git reset --hard abc123
```

### 3. Review Mode

```
@janitor --review

Shows what would be deleted with justification.
You approve each change.
```

### 4. Confidence Scoring

```
High Confidence (95%+): Delete automatically
Medium Confidence (70-94%): Flag for review
Low Confidence (<70%): Skip, need human decision
```

---

## 📊 Metrics & Reporting

### Cleanup Report Format

```
🧹 JANITOR CLEANUP REPORT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Date: 2025-10-30
Duration: 18 minutes
Status: ✅ COMPLETE

📉 REDUCTIONS:
├─ Lines of Code: 89,450 → 71,293 (-20%)
├─ Files: 247 → 224 (-9%)
├─ Packages: 67 → 24 (-64%)
├─ Tests: 234 → 189 (-19%)
└─ Build Time: 8 min → 5.5 min (-31%)

🗑️  ELIMINATED:
├─ Dead Code: 18,157 lines
├─ Unused Classes: 23
├─ Unused Methods: 156
├─ Unused Fields: 89
├─ Commented Code: 2,340 lines
└─ Obsolete Tests: 45

⚡ SIMPLIFIED:
├─ Complex Methods: 23 refactored
├─ Duplicate Code: 45 instances consolidated
├─ Single-use Abstractions: 12 inlined
└─ Average Complexity: 12 → 7

📦 DEPENDENCIES:
├─ Removed: 18 packages
├─ Updated: 12 packages
├─ Security Fixes: 3
└─ Size Saved: 87 MB

📈 IMPROVEMENTS:
├─ Code Quality: +23%
├─ Test Coverage: 67% → 78%
├─ Build Speed: +31%
└─ Maintainability: HIGH

💰 ESTIMATED VALUE:
├─ Dev Time Saved: ~4 hrs/week
├─ Faster Onboarding: ~2 days reduced
├─ Lower Maintenance: ~$5,000/year
└─ Reduced Bugs: ~15% fewer incidents
```

---

## 📚 Summary

| What You Want | What to Type |
|---------------|--------------|
| Full cleanup | `@janitor Clean entire solution` |
| Specific directory | `@janitor Clean Services/ directory` |
| Remove dead code only | `@janitor Remove unused code` |
| Dependency audit | `@janitor Audit and clean dependencies` |
| Test optimization | `@janitor Optimize test suite` |
| Dry run (preview) | `@janitor --dry-run Show cleanup plan` |
| Conservative mode | `@janitor --conservative Clean safely` |
| Track debt | `@janitor --track-debt Generate report` |
| Custom rules | `@janitor --define-rules Create cleanup rules` |
| Incremental (CI/CD) | `@janitor --incremental Clean changed files` |

---

**The Janitor ruthlessly eliminates technical debt through aggressive simplification!** 🧹

- **Less Code = Less Debt**: Every deletion makes the codebase stronger
- **Safe Deletion**: Test-driven cleanup ensures nothing breaks
- **Aggressive Simplification**: Complex code → simple code
- **Dependency Hygiene**: Clean, secure, minimal dependencies

Point the janitor at your codebase and watch the technical debt disappear! 🚀

---

## 💪 Cleanup Philosophy

The Janitor operates on these principles:

1. **Deletion > Addition**: Removing code is better than adding
2. **Simple > Complex**: Flat is better than nested
3. **Built-in > Custom**: Use language features over custom code
4. **Few > Many**: Fewer dependencies = fewer problems
5. **Clear > Clever**: Obvious code beats clever code
6. **Tests Prove Safety**: Delete with confidence when tests pass
7. **Continuous Cleanup**: Small, frequent cleanups > big rewrites

Let the janitor keep your codebase clean and maintainable! 🎯

