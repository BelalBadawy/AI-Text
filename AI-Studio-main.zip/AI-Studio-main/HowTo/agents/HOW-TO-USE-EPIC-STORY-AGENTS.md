# How to Use Epic & Story Agents

Automate Agile work breakdown from Product Requirements Documents (PRDs) to fully-specified, AI-ready User Stories with Gherkin acceptance criteria.

## 🎯 Overview

The **Epic Agent** and **Story Agent** work together to transform product requirements into actionable development work:

1. **Epic Agent** → Creates technical Epics from PRDs or standalone technical work
2. **Story Agent** → Breaks Epics into 3-5 point User Stories with Gherkin acceptance criteria and AI Autonomy scoring

**Perfect For:**
- 📋 Product Managers decomposing features
- 👨‍💻 Tech Leads planning sprints
- 🤖 Enabling AI agents to implement stories autonomously
- 📊 Estimating and tracking work

---

## 🚀 Quick Start

### Create Epic from PRD

```
@epic-agent

Create an Epic from this PRD:
https://confluence.company.com/display/PRODUCT/User-Profile-Feature
```

### Create Standalone Technical Epic

```
@epic-agent

Create a Tech Debt Epic for refactoring the payment service to use 
async/await patterns throughout.
```

### Break Epic into Stories

```
@story-agent

Break down Epic PROJ-123 into User Stories.
```

---

## 📦 What Gets Created

### Epic Agent Output

Creates a Jira Epic with the **CREATE framework**:

```
C - Context: Business problem, stakeholders, strategic alignment
R - Result: Engineering objectives, success criteria, DoD
E - Explain: Architecture, integrations, constraints
A - Approach: Phases, milestones, testing strategy
T - Tone: Technical, precise, action-oriented
E - Edit: Well-structured for Jira
```

### Story Agent Output

Creates Jira User Stories with:

- **User Story Format**: "As a... I want... So that..."
- **Functional Examples**: Real-world scenarios
- **Business Rules**: Testable conditions
- **Gherkin Acceptance Criteria**: Given-When-Then scenarios
- **Technical Notes**: Architecture context
- **AI Autonomy Score**: 0-100 rating for agent readiness
- **Story Points**: 3-5 maximum

---

## 🎬 Complete Workflow Example

### Scenario: New User Profile Feature

**Step 1: Create Epic from PRD**

```
You: @epic-agent

     Create Epic from PRD:
     https://confluence.company.com/display/PRODUCT/User-Profile-Feature

Agent: 📄 Fetching PRD from Confluence...
      
      ✅ Retrieved: "User Profile Management Feature"
      
      Summary:
      - Enable users to create and manage profiles
      - Include avatar upload, bio, social links
      - Privacy controls for profile visibility
      - Activity feed showing recent actions
      
      Stakeholders: Product (Sarah), Design (Mike), Backend (Team Alpha)
      Target: Q2 2026
      
      Proceed with Epic creation? (yes/no)

You: yes

Agent: 📝 Generating Epic using CREATE framework...
      
      ✅ Created Epic: PROJ-145
      
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      Epic: User Profile Management
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      
      Context:
      - Business Problem: Users cannot personalize experience
      - Strategic Alignment: Increase engagement by 25%
      - Stakeholders: Product, Design, Backend Team Alpha
      
      Result:
      - Objectives:
        1. Build RESTful profile API
        2. Implement secure avatar storage (S3)
        3. Add privacy controls (public/private/friends)
      
      - Success Criteria:
        ☑ API response time < 200ms
        ☑ Support 1M+ profiles
        ☑ Pass security review
      
      Explain:
      - Architecture: React frontend → .NET Core API → PostgreSQL
      - Integrations: S3 for avatars, CDN for delivery
      - Constraints: GDPR compliance, 5MB avatar limit
      
      Approach:
      - Phase 1: Profile CRUD API (1 sprint)
      - Phase 2: Avatar upload + storage (1 sprint)
      - Phase 3: Privacy controls (1 sprint)
      - Phase 4: Activity feed (1 sprint)
      
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      
      Link: https://jira.company.com/browse/PROJ-145
      
      Next: Use @story-agent to break into User Stories
```

---

**Step 2: Break Epic into Stories**

```
You: @story-agent

     Break down Epic PROJ-145 into User Stories.

Agent: 📋 Fetching Epic PROJ-145 from Jira...
      
      ✅ Retrieved: "User Profile Management"
      
      Parsing CREATE-formatted content...
      
      Identified work units:
      1. Profile CRUD operations
      2. Avatar upload and storage
      3. Privacy controls
      4. Activity feed
      5. Profile validation
      
      Generating 5 User Stories (all ≤ 5 points)...
      
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      ✅ Created 5 User Stories
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      
      PROJ-146: Create and retrieve user profiles
      - Story Points: 5
      - AI Autonomy: 85/100 (Autonomous)
      - Gherkin Scenarios: 4 (CRUD happy paths + validation)
      
      PROJ-147: Update user profile information
      - Story Points: 3
      - AI Autonomy: 80/100 (Autonomous)
      - Gherkin Scenarios: 3 (Update, partial update, validation)
      
      PROJ-148: Upload and display profile avatars
      - Story Points: 5
      - AI Autonomy: 70/100 (Assisted)
      - Gherkin Scenarios: 5 (Upload, formats, size limits, S3 integration)
      
      PROJ-149: Configure profile privacy settings
      - Story Points: 4
      - AI Autonomy: 75/100 (Autonomous)
      - Gherkin Scenarios: 3 (Public/private/friends settings)
      
      PROJ-150: Display user activity feed
      - Story Points: 5
      - AI Autonomy: 65/100 (Assisted)
      - Gherkin Scenarios: 4 (Feed display, pagination, privacy filtering)
      
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      Total Story Points: 22
      Autonomous Stories: 3
      Assisted Stories: 2
      
      All stories linked to Epic PROJ-145
      
      Next: Assign stories to sprint and implement!
```

---

**Step 3: View a Generated Story**

```
PROJ-146: Create and retrieve user profiles
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Epic: PROJ-145 - User Profile Management
Story Points: 5
Figma: https://figma.com/design/profiles

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

User Story:
As a registered user, I want to create and view my profile, so that 
I can share information about myself with other users.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Functional Explanation with Examples:

- Example 1: "Sarah signs up and immediately creates her profile with 
  display name 'Sarah Chen', bio 'Software Engineer at Acme', and 
  website 'sarahchen.dev'. Her profile is visible at /profiles/sarah-chen."

- Example 2: "Bob views Sarah's profile and sees her display name, bio, 
  website link, and join date. Avatar shows default icon since she 
  hasn't uploaded one yet."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Business Rules:

1. Display name must be 3-50 characters, unique across platform
2. Bio is optional, max 500 characters
3. Website must be valid URL format or empty
4. Profile creation requires authenticated user
5. Default avatar assigned if none uploaded

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Acceptance Criteria (Gherkin):

Scenario 1: Happy Path - Create New Profile
Given I am a registered and authenticated user
  And I do not have an existing profile
When I submit profile data:
  | Field        | Value                    |
  | DisplayName  | Sarah Chen               |
  | Bio          | Software Engineer        |
  | Website      | https://sarahchen.dev    |
Then a new profile is created with ID
  And the profile is associated with my user account
  And I receive HTTP 201 Created
  And the response includes profile ID and username slug

Scenario 2: Validation - Display Name Required
Given I am a registered and authenticated user
When I submit profile data with empty display name
Then I receive HTTP 400 Bad Request
  And error message: "Display name is required (3-50 characters)"
  And no profile is created

Scenario 3: Happy Path - Retrieve Own Profile
Given I have an existing profile
When I request GET /api/profiles/me
Then I receive HTTP 200 OK
  And response includes my display name, bio, website
  And response includes my user ID and join date
  And response includes avatar URL (default if not uploaded)

Scenario 4: Happy Path - Retrieve Other User Profile
Given another user "Bob" has a public profile
When I request GET /api/profiles/bob
Then I receive HTTP 200 OK
  And response includes Bob's public profile data
  And response does NOT include Bob's private data (email, phone)

Scenario 5: Error Handling - Duplicate Display Name
Given another user has display name "Sarah Chen"
When I attempt to create profile with same display name
Then I receive HTTP 409 Conflict
  And error message: "Display name already taken"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Technical Notes:

- API Endpoints:
  POST   /api/profiles          (Create)
  GET    /api/profiles/me       (Get own)
  GET    /api/profiles/{slug}   (Get by username slug)

- Database: PostgreSQL profiles table
  - user_id (FK to users table, unique)
  - display_name (unique index)
  - bio (text, nullable)
  - website (varchar, nullable)
  - avatar_url (varchar, nullable)
  - created_at, updated_at

- Validation: Use FluentValidation
- Authorization: Require [Authorize] attribute
- Slug Generation: Convert display name to URL-safe slug

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Definition of Ready Checklist:

☑ User story follows "As a... I want... So that..." format
☑ Acceptance criteria in Gherkin format
☑ Story points assigned (5)
☑ Business rules documented (5 rules)
☑ Dependencies identified (database schema)
☑ Figma designs linked

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

AI Autonomy Assessment:

Autonomy Score: 85/100
Label: Autonomous

Scoring Breakdown:
| Factor            | Score | Notes                           |
|-------------------|-------|---------------------------------|
| Gherkin Clarity   | 55/60 | 5 comprehensive scenarios       |
| INVEST Compliance | 35/40 | Independent, testable, small    |
| Complexity        | -5    | Standard CRUD with validation   |

Recommendation: This story is AGENT-READY.
- All acceptance criteria are executable as tests
- Business rules are explicit and testable
- Technical implementation is straightforward
- An AI agent can implement this autonomously with minimal guidance

Suggested Agent Workflow:
1. Generate ProfilesController with CRUD endpoints
2. Create Profile entity and DbContext configuration
3. Implement FluentValidation rules
4. Write xUnit tests matching Gherkin scenarios
5. Generate Swagger documentation
```

---

## 📋 Epic Agent Modes

### Mode 1: PRD-Based Epic

**When to Use:** Product Manager has written a PRD in Confluence/SharePoint.

**Process:**
1. Agent fetches PRD via Rovo MCP
2. Extracts: Problem, Value, Users, Requirements, Success Criteria
3. Transforms into CREATE-formatted technical Epic
4. Creates Epic in Jira with appropriate labels

**Example Sources:**
- Confluence pages
- SharePoint documents (if available)
- Google Docs (if Rovo supports)

---

### Mode 2: Standalone Technical Epic

**When to Use:** No PRD exists, creating technical work directly.

**Common Types:**

| Type | When | Example |
|------|------|---------|
| **Tech Debt** | Code quality improvement | "Refactor payment service to async patterns" |
| **Bug Fix** | Complex bugs needing coordination | "Fix memory leak in image processing pipeline" |
| **Infrastructure** | Platform/tooling changes | "Migrate CI/CD from Jenkins to GitHub Actions" |
| **Performance** | Optimization efforts | "Reduce API response time from 800ms to 200ms" |
| **Security** | Security enhancements | "Implement OAuth2 authentication flow" |

**Process:**
1. Agent asks clarifying questions:
   - What is the current problem?
   - What is the desired outcome?
   - What systems are affected?
   - Are there dependencies or blockers?
2. Generates CREATE-formatted Epic
3. Creates Epic in Jira

---

## 🎯 Story Agent Features

### INVEST Principles

All generated stories follow INVEST:

- **I**ndependent: Can be implemented in any order
- **N**egotiable: Details can be discussed
- **V**aluable: Delivers user value
- **E**stimable: Can be sized (3-5 points)
- **S**mall: Fits in one sprint
- **T**estable: Clear acceptance criteria

### Gherkin Scenarios

Every story includes 3-5 Gherkin scenarios:

1. **Happy Path**: Primary use case
2. **Edge Cases**: Boundary conditions
3. **Error Handling**: Failure modes
4. **Validation**: Input validation
5. **Integration**: External system interactions

**Format:**
```gherkin
Given [precondition]
  And [additional context]
When [action performed]
Then [expected outcome]
  And [additional verification]
```

### AI Autonomy Scoring

Each story is scored 0-100 for AI agent readiness:

| Score | Label | Meaning |
|-------|-------|---------|
| 80-100 | **Autonomous** | Agent can implement independently |
| 60-79 | **Assisted** | Agent needs guidance/review |
| 0-59 | **Human-Driven** | Requires human developer |

**Scoring Factors:**
- **Gherkin Clarity** (60 points): How well scenarios define behavior
- **INVEST Compliance** (40 points): Independent, testable, small
- **Complexity Deductions**: Novel algorithms, complex integrations

---

## 💡 Use Cases

### Use Case 1: Feature Breakdown from PRD

**Scenario:** Product Manager writes "Social Sharing" feature PRD.

**Workflow:**
```
1. @epic-agent → Create Epic from PRD URL
2. @story-agent → Break Epic PROJ-XXX into stories
3. Assign stories to sprint
4. Use agents to implement autonomous stories
```

**Benefit:** Transforms 5-page PRD into actionable 3-5 point stories in minutes.

---

### Use Case 2: Tech Debt Sprint Planning

**Scenario:** Tech Lead wants to dedicate sprint to refactoring legacy code.

**Workflow:**
```
@epic-agent

Create Tech Debt Epic:
- Refactor OrderService to use async/await
- Remove blocking .Result calls
- Add cancellation token support
- Improve error handling

Then:
@story-agent Break down Epic TECH-XXX
```

**Benefit:** Structures technical work with same rigor as features.

---

### Use Case 3: Sprint Planning Automation

**Scenario:** Tech Lead planning sprint for 3 developers (60 story points capacity).

**Workflow:**
```
1. Create Epic from PRD
2. Break into stories (automatically sized 3-5 points)
3. Review autonomy scores:
   - Autonomous stories → Assign to AI agents
   - Assisted stories → Assign to junior devs with agent help
   - Human-driven → Assign to senior devs
```

**Benefit:** Optimal work distribution based on complexity.

---

## 🔧 Configuration

### Team Configuration File

**Location:** `agents/config/team-config.yml`

**Contents:**
```yaml
jira:
  project_key: "PROJ"
  project_id: "10001"
  issue_types:
    epic: "10000"
    story: "10001"
  
story_constraints:
  max_story_points: 5
  min_story_points: 3
  
autonomy:
  autonomous_threshold: 80
  assisted_threshold: 60
  
labels:
  epic:
    - "epic"
    - "feature"
  story:
    - "story"
    - "ready-for-dev"
```

Agents automatically load this configuration before creating Jira issues.

---

## 🐛 Troubleshooting

### Problem: "Cannot fetch PRD from Confluence"

**Cause:** Rovo MCP not configured or missing permissions.

**Solution:**
1. Verify Confluence connection in VS Code
2. Check you have read access to the page
3. Try copying content directly:
   ```
   @epic-agent Create Epic from this content:
   [paste PRD text]
   ```

---

### Problem: "Story exceeds 5 points"

**Cause:** Story Agent detected work too large for one story.

**Solution:** Agent automatically splits:
```
Original story too large (estimated 8 points).

Split into 2 stories:
1. PROJ-XXX: [Part 1] (5 points)
2. PROJ-YYY: [Part 2] (3 points)
```

---

### Problem: "Low autonomy score (45/100)"

**Cause:** Story has ambiguous requirements or high complexity.

**Solution:**
```
Story PROJ-XXX has low autonomy (45/100).

Issues:
- Acceptance criteria lack detail
- Novel algorithm required (dynamic pricing)
- Multiple complex integrations

Recommendation: Assign to senior developer.
Consider breaking into:
1. Research spike (2 points)
2. Implementation story (5 points)
```

---

### Problem: "Epic missing technical details"

**Cause:** PRD lacks technical specifications.

**Solution:** Agent prompts:
```
PRD missing technical information.

Please provide:
1. Target architecture (monolith/microservices)
2. Database choice (SQL/NoSQL)
3. Performance requirements
4. Security requirements

Or create as draft and refine later.
```

---

## ✅ Success Checklist

### After Creating Epic:

- [ ] Context section explains business problem clearly
- [ ] Result section has measurable success criteria
- [ ] Explain section includes architecture approach
- [ ] Approach section has realistic phases
- [ ] Epic linked to PRD (if applicable)
- [ ] Stakeholders identified
- [ ] Labels applied correctly

### After Creating Stories:

- [ ] All stories are 3-5 points
- [ ] User story format followed ("As a... I want... So that...")
- [ ] Gherkin scenarios cover happy path + edge cases + errors
- [ ] Business rules are explicit and testable
- [ ] Technical notes reference Epic's architecture
- [ ] Autonomy score calculated
- [ ] Stories linked to parent Epic
- [ ] Definition of Ready met

---

## 🎯 Best Practices

### 1. Always Start with Epic

Don't create stories without an Epic - the Epic provides essential context.

### 2. Review Generated Content

Agents are smart but not perfect:
- Verify business rules match product intent
- Check Gherkin scenarios are realistic
- Confirm technical approach aligns with architecture

### 3. Use Autonomy Scores

- **80-100 (Autonomous)**: Perfect for AI agents or junior devs with agent assist
- **60-79 (Assisted)**: Mid-level devs with agent guidance
- **0-59 (Human-Driven)**: Senior developers only

### 4. Keep Stories Small

If a story feels too large, ask Story Agent to split it:
```
@story-agent Split PROJ-XXX into smaller stories (3 points max)
```

### 5. Iterate on Acceptance Criteria

If Gherkin scenarios are unclear:
```
@story-agent Expand Gherkin scenarios for PROJ-XXX
Include more edge cases for validation.
```

---

## 🚀 Advanced Workflows

### Workflow 1: Quarterly Planning

```bash
# Step 1: Create Epics for all features in roadmap
@epic-agent Create Epic from PRD: <URL-1>
@epic-agent Create Epic from PRD: <URL-2>
@epic-agent Create Epic from PRD: <URL-3>

# Step 2: Break all Epics into stories
@story-agent Break EPIC-1
@story-agent Break EPIC-2
@story-agent Break EPIC-3

# Step 3: Review total story points
Total capacity: 240 points (4 devs × 60 points)
Total stories: 235 points ✅ Fits in quarter!
```

---

### Workflow 2: Agent-First Development

```bash
# Step 1: Create Epic + Stories
@epic-agent + @story-agent workflow

# Step 2: Filter autonomous stories
Search Jira: "Autonomy Score >= 80"

# Step 3: Assign to AI agents
Use GitHub Copilot Workspace or custom agents to implement

# Step 4: Human review
Senior dev reviews AI-generated code
```

---

## 📚 Related Resources

- **CREATE Framework**: See `agents/epic-agent.agent.md` for details
- **Gherkin Guide**: [Cucumber Gherkin Reference](https://cucumber.io/docs/gherkin/reference/)
- **INVEST Principles**: [Agile Alliance INVEST](https://www.agilealliance.org/glossary/invest/)
- **AI Autonomy**: See AGENTS.md for scoring methodology

---

## 🎯 Quick Reference

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Epic & Story Agents - Command Reference
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Epic from PRD:          @epic-agent Create Epic from <URL>
Standalone Epic:        @epic-agent Create <Type> Epic for <work>
Break into Stories:     @story-agent Break Epic <EPIC-KEY>
Split Large Story:      @story-agent Split <STORY-KEY>
Expand Acceptance:      @story-agent Expand Gherkin for <STORY-KEY>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Epic Types: Feature | Tech Debt | Bug Fix | Infrastructure
            Performance | Security

Story Sizing: 3-5 points maximum
Autonomy: 80-100 (Autonomous) | 60-79 (Assisted) | 0-59 (Human)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Start your first Epic:**
```
@epic-agent Create Epic from PRD: <your-prd-url>
```
