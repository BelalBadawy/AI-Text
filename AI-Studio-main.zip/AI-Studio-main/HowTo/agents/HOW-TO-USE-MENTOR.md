# How to Use @mentor

## 🎯 Overview

The `@mentor` chatmode is your **Socratic teaching companion** that helps you find the right solution through guided questioning and critical thinking. Instead of giving direct answers, the mentor challenges your assumptions, encourages exploration, and helps you develop deeper understanding.

**Important:** The mentor **does NOT write code** - it guides you to write better code yourself.

---

## 🚀 Quick Start

### Get Guidance on New Feature

```
@mentor

I need to add user authentication to the app.
I'm thinking of storing passwords in plain text in the database.
```

### Design Review

```
@mentor

I'm designing a payment processing system.
Here's my approach: [describe your design]

What am I missing?
```

### Learning Session

```
@mentor

I need to understand dependency injection better.
Can you help me think through why we need it?
```

---

## 🎓 The Socratic Approach

The mentor uses **Socratic questioning** to guide your learning:

### Example Session

```
You: @mentor
     
     I want to cache user data to improve performance.
     I'll just store everything in a static dictionary.

Mentor: Let's think through this design together. 🤔
        
        A few questions to consider:
        
        1. **Scope & Lifetime**
           - Static dictionaries live for the application lifetime.
           - What happens when you deploy a new version?
           - What happens if you scale to multiple instances?
        
        2. **Memory Management**  
           - How much user data are we talking about?
           - What if you have 1 million users?
           - Do you have a plan for cache eviction?
        
        3. **Thread Safety**
           - Multiple requests will access this dictionary concurrently.
           - What happens if two threads modify it simultaneously?
           - Have you considered race conditions?
        
        4. **Data Freshness**
           - If user data changes in the database, how does 
             your cache know to update?
           - What's your cache invalidation strategy?
        
        Before we continue, can you walk me through:
        - How many users do you expect?
        - How often does user data change?
        - Are you running on single server or multiple instances?

You: We have about 100k users, running on 3 servers.
     User data changes occasionally when they update profile.

Mentor: Good information! Now let's reason through this. 🎓
        
        Given 3 servers, your static dictionary approach has 
        a critical problem:
        
        ┌─────────┐  ┌─────────┐  ┌─────────┐
        │Server 1 │  │Server 2 │  │Server 3 │
        │Cache A  │  │Cache B  │  │Cache C  │
        └─────────┘  └─────────┘  └─────────┘
        
        Each server has its OWN static dictionary. When user
        updates profile on Server 1, Servers 2 & 3 still have
        old data.
        
        Questions:
        1. How would you solve the cache synchronization problem?
        2. What if Server 2 goes down - is it ok to lose its cache?
        3. Have you considered using a distributed cache?
        
        Think about:
        - Redis (distributed, persistent)
        - IMemoryCache (in-process, includes eviction)
        - IDistributedCache (abstraction for distributed scenarios)
        
        Which makes sense for your scenario and why?

You: I think Redis because we have multiple servers.
     But isn't that more complex to set up?

Mentor: Great reasoning! You've identified the right tool and 
        the right tradeoff. 👍
        
        Let's weigh the options:
        
        **Option 1: No Caching (Baseline)**
        ├─ Pros: Simple, always fresh data
        └─ Cons: Database hit on every request
        
        **Option 2: In-Memory Cache (IMemoryCache)**
        ├─ Pros: Easy to implement, fast
        ├─ Cons: Stale data across servers, memory limits
        └─ Use case: Single server or data rarely changes
        
        **Option 3: Redis (Distributed)**
        ├─ Pros: Shared across servers, fast, reliable
        ├─ Cons: External dependency, network latency
        └─ Use case: Multiple servers, frequently accessed data
        
        You said "more complex to set up" - let's quantify that:
        
        Setup complexity: ~2 hours
        Maintenance overhead: Minimal (managed service)
        
        Now ask yourself:
        - How many database queries will you save per day?
        - What's the cost of slower page loads vs Redis setup?
        - What's the risk of serving stale data to users?
        
        Do the costs justify the benefits for your use case?
```

---

## 🤔 What Makes Mentor Different

### Mentor Mode ≠ Regular Chat

| Regular Assistant | Mentor Mode |
|-------------------|-------------|
| "Here's the code" | "Why do you think that approach would work?" |
| Gives direct answers | Asks guiding questions |
| Writes code for you | Helps you understand what to write |
| "Use this pattern" | "What are the tradeoffs of different patterns?" |
| Fast solutions | Deep understanding |

### The 5 Whys Technique

Mentor uses the "5 Whys" to get to root understanding:

```
You: I need to add error handling to catch all exceptions.

Mentor: Why do you want to catch all exceptions?

You: So the app doesn't crash.

Mentor: Why would the app crash from exceptions?

You: Because unhandled exceptions terminate the process.

Mentor: Why not let some exceptions bubble up to a global handler?

You: I guess... that would centralize error handling.

Mentor: Why would centralization be better?

You: Consistent error responses, logging in one place,
     and I don't have to add try-catch everywhere.

Mentor: Now you're thinking architecturally! 🎯
        
        You've discovered that:
        1. Not all exceptions need local handling
        2. Global handlers provide consistency  
        3. Try-catch everywhere is an anti-pattern
        
        So the real question isn't "how do I catch everything"
        but rather:
        - What exceptions need local handling? (expected scenarios)
        - What should bubble to global handler? (unexpected errors)
        
        Can you categorize your exceptions into these two groups?
```

---

## 🎯 Common Mentor Scenarios

### Scenario 1: Architecture Decision

```
@mentor

Should I use microservices or monolith for my new e-commerce platform?
```

**Mentor Response:**
```
Let's explore the tradeoffs through questions:

1. **Team & Organization**
   - How large is your development team?
   - Do you have separate teams for different domains?
   - What's your DevOps maturity level?

2. **Scale & Complexity**
   - Expected traffic: 100 requests/sec or 10,000/sec?
   - How many distinct business domains? (payments, inventory, etc.)
   - Do different parts need to scale independently?

3. **Time to Market**
   - When do you need to launch?
   - Can you afford the complexity of distributed systems upfront?
   - What's the cost of choosing wrong initially?

4. **Existing Constraints**
   - Any existing systems to integrate with?
   - Technology restrictions?
   - Budget for infrastructure?

Walk me through your answers, and let's reason through 
which architecture fits YOUR specific context.

Remember: Most successful companies started with monoliths
and evolved to microservices when they needed to.
```

### Scenario 2: Code Review Request

```
@mentor

Review my OrderService class:
[paste code]

Is this good?
```

**Mentor Response:**
```
Rather than me telling you if it's good, let's review it 
together using critical thinking:

**SOLID Principles Check:**

1. **Single Responsibility**
   - Your OrderService handles: validation, database access,
     email sending, payment processing, and logging.
   - Question: Does it have ONE reason to change or MANY?
   - Exercise: List each responsibility. Which could be 
     extracted to their own classes?

2. **Open/Closed**
   - You have a switch statement for different payment types.
   - Question: What happens when you add a new payment type?
   - Exercise: How could you use strategy pattern instead?

3. **Dependency Inversion**
   - You're newing up EmailService directly in the code.
   - Question: How would you test this without sending real emails?
   - Exercise: What interface could you inject instead?

Let's start with question #1. What are the distinct 
responsibilities you can identify?
```

### Scenario 3: Learning Concepts

```
@mentor

I keep hearing about CQRS but don't understand why I'd use it.
```

**Mentor Response:**
```
Great question! Let's discover CQRS through reasoning. 🎓

First, observe your current system:

**Traditional Approach:**
```
Controller → Service → Repository → Database
(reads and writes use same models)
```

Now let's think through problems this causes:

1. **Query Complexity**
   - You need to show order history with customer, items, 
     shipping address, payment details.
   - Question: How many joins in your query?
   - Problem: Complex read queries slowing down simple writes?

2. **Model Mismatch**  
   - Your Order entity has validation for creating orders.
   - But when READING orders for reports, you don't need validation.
   - Question: Why load all that overhead for reads?

3. **Scale Differences**
   - Most systems: 90% reads, 10% writes
   - Question: Why use same infrastructure for both?
   - Insight: Could you optimize reads and writes separately?

**CQRS Insight:**

What if we separated the concerns?

```
Commands (Write)         Queries (Read)
     ↓                        ↓
Write Model              Read Model
     ↓                        ↓
Write DB           →     Read DB (denormalized)
```

Now consider:
- Write model: Highly normalized, validated, transactional
- Read model: Denormalized, fast, optimized for queries

Questions for YOU to think through:
1. What's the complexity cost of maintaining two models?
2. When is that cost justified?
3. For your current project, what's the read/write ratio?

Should you use CQRS? Let's figure that out together based 
on YOUR specific needs, not general hype.
```

### Scenario 4: Performance Problem

```
@mentor

My API is slow. I added caching everywhere but it's still slow.
```

**Mentor Response:**
```
Hmm, adding caching "everywhere" but still slow? 🤔
Let's investigate the reasoning behind your approach.

Critical questions:

1. **Measure First**
   - Have you profiled to find the ACTUAL bottleneck?
   - Question: What if database isn't the problem?
   - Scenario: If slow because of CPU-bound calculation,
     caching won't help. Do you know what's slow?

2. **Cache Effectiveness**
   - You cached "everywhere" - but is that data cacheable?
   - Question: How often does the data change?
   - Example: Caching data that changes every second
     means cache misses constantly. High churn?

3. **Cache Overhead**
   - Question: Did you measure if caching made it SLOWER?
   - Scenario: Serialization/deserialization overhead
     can exceed database query time for simple queries.
     
4. **Real Bottleneck**
   - Could be: Network latency, algorithm complexity,
     N+1 queries, missing indexes, blocking I/O
   - Question: Have you profiled to know for sure?

**Exercise:**
1. Use a profiler (dotTrace, MiniProfiler)
2. Identify the slowest operation  
3. Share the findings with me
4. THEN we'll reason through the best solution

Remember: "Make it work, make it right, make it fast"
You might be optimizing the wrong thing!
```

### Scenario 5: Security Concern

```
@mentor

I'm implementing authentication. Should I hash passwords
with MD5 or SHA-1?
```

**Mentor Response:**
```
⚠️ STOP! Before you choose, let's think critically about 
password security. This is important to get right.

**Red Flags in Your Question:**

1. **Both MD5 and SHA-1 are broken**
   - MD5: Cryptographically broken since 2004
   - SHA-1: Deprecated for cryptographic use
   - Neither is appropriate for passwords

**Why This Matters:**

Let me challenge your assumptions with questions:

1. **Hashing vs. Password Hashing**
   - Question: Do you know the difference?
   - Insight: SHA-256 is great for checksums, terrible for passwords
   - Why? It's designed to be FAST. Attackers can try
     billions of hashes per second.

2. **What Makes Password Storage Secure?**
   - Slow computation (expensive for attackers)
   - Built-in salting (prevents rainbow tables)
   - Adaptive cost (can increase over time)
   
   Question: Do MD5/SHA-1 have these properties?

3. **The Right Tools**
   - bcrypt (recommended, adaptive cost)
   - Argon2 (modern, won PBKDF competition)
   - PBKDF2 (standards-compliant, widely supported)
   
   These are PURPOSE-BUILT for password hashing.

**Real-World Impact:**

Scenario: Your database leaks (happens to major companies).
- With MD5: Attacker cracks passwords in hours
- With bcrypt: Attacker needs years even with GPU farms

**Exercise for Understanding:**

1. Research: Why is bcrypt slower than MD5?
2. Answer: Why is slower GOOD for password hashing?
3. Think: What's the tradeoff? (user waits 100ms vs 1ms at login)

This is a case where I'm being FIRM in my guidance:
❌ Do NOT use MD5 or SHA-1 for passwords
✅ DO use bcrypt, Argon2, or PBKDF2

The long-term cost of this mistake is too high. This is 
a security fundamental, not a tradeoff discussion.

Want to understand the math behind why these are safer?
```

---

## 💡 Mentor's Teaching Techniques

### 1. Socratic Questioning

Drawing out knowledge through questions:
```
Instead of: "Use dependency injection"
Mentor asks: "How would you test this class that creates 
              its own dependencies?"
```

### 2. The 5 Whys

Getting to root understanding:
```
"Why do you need this feature?"
"Why would that solve the problem?"
"Why is that the real problem?"
"Why did it become a problem?"
"Why wasn't it designed differently?"

→ Reveals underlying assumptions and root causes
```

### 3. Tradeoff Analysis

Nothing is free - everything has costs:
```
Instead of: "Microservices are better"
Mentor shows:
├─ Pros: Independent scaling, team autonomy
├─ Cons: Complexity, networking overhead, debugging
└─ Question: Do the benefits outweigh costs for YOUR case?
```

### 4. First Principles Thinking

Breaking down to fundamental truths:
```
"Let's forget frameworks and patterns for a moment.
 What are you ACTUALLY trying to achieve?
 What are the fundamental constraints?
 Now let's build up from there."
```

### 5. Learning from Examples

Real-world cautionary tales:
```
"Company X used MongoDB for everything because it was trendy.
 They had relational data and fought the database constantly.
 Eventually migrated to PostgreSQL after 2 years of pain.
 
 Question: How could they have made a better decision upfront?"
```

---

## 🎨 Mentor Response Patterns

### Pattern 1: Challenge Assumptions

```
You: I'll use NoSQL because it's faster.

Mentor: Let's examine that assumption. 🤔
        
        "NoSQL is faster" - faster at WHAT specifically?
        - Reads? Writes? Aggregations?
        - Faster than what? (PostgreSQL? MySQL? MongoDB?)
        - Under what load? (1 req/sec vs 10,000 req/sec)
        
        Have you benchmarked for YOUR specific use case?
        Or is this based on general marketing claims?
```

### Pattern 2: Explore Alternatives

```
You: I'll catch all exceptions and return 500.

Mentor: That's one approach. Let's explore alternatives:
        
        **Option A:** Catch all → Return 500
        ├─ Pro: Simple
        └─ Con: Client doesn't know what went wrong
        
        **Option B:** Specific catches + ProblemDetails
        ├─ Pro: Useful error messages
        └─ Con: More code
        
        **Option C:** Global exception middleware
        ├─ Pro: Centralized, consistent
        └─ Con: Less local control
        
        For your API that external clients will use,
        which provides the best developer experience?
```

### Pattern 3: Long-Term Thinking

```
You: I'll just add this as a quick fix.

Mentor: "Quick fix" - let's think long-term: ⏰
        
        **Today:**
        ├─ Fix takes: 5 minutes
        └─ Tech debt created: small workaround
        
        **Next Month:**
        ├─ Another dev sees pattern, copies it: 3 more places
        └─ Tech debt: multiplied by 4
        
        **In 6 Months:**
        ├─ Need to refactor all 4 instances
        └─ Cost: 2 days of work
        
        **Alternative - Do it Right:**
        ├─ Time now: 30 minutes
        └─ Time saved later: 2 days (minus 25 minutes)
        
        Question: Is the 25 extra minutes now worth avoiding
        2 days of work later?
        
        Remember: Code is read 10x more than it's written.
```

### Pattern 4: Quantify the Risk

```
You: I think this approach might work.

Mentor: "Might work" - let's quantify that risk: 📊
        
        **Confidence Level:** How sure are you? (50%? 90%?)
        
        **If it WORKS:**
        ├─ Benefits: [what do you gain?]
        └─ Cost: [time invested]
        
        **If it FAILS:**
        ├─ Cost: [time wasted + rework]
        └─ Impact: [blocked features? missed deadline?]
        
        Expected value = (Probability × Benefit) - (Risk × Cost)
        
        Humans are notoriously bad at estimating risk.
        Let's do the math together.
        
        Can you afford to be wrong?
        Is there a safer way to validate first?
```

---

## 🚨 When Mentor Is Firm

While mentor usually guides with questions, there are times for direct warnings:

### ❌ Security Issues

```
You: I'll store passwords in plain text for now, encrypt later.

Mentor: ⛔ STOP. This is NOT a learning moment - this is critical.
        
        This is a SECURITY FUNDAMENTAL, not a design choice:
        
        ❌ NEVER store plain text passwords
        ❌ NEVER plan to "add security later"
        ❌ NEVER think "encrypt" - think "hash + salt"
        
        Why I'm being firm:
        1. Security bugs have severe consequences
        2. "Later" often never comes
        3. Breach = legal liability, reputation damage
        
        This is non-negotiable. Use bcrypt/Argon2 from day 1.
```

### ❌ Data Loss Risks

```
You: I'll skip transaction boundaries for performance.

Mentor: 🛑 Hold on. Data integrity is not optional.
        
        Without transactions, you can have:
        - Partial order (payment taken, but no order record)
        - Orphaned data (order exists, inventory not reduced)
        - Inconsistent state (A sees X, B sees Y)
        
        The "performance" savings are minimal vs the risk.
        
        Question: Are you willing to explain to a customer
        why they were charged but have no order?
        
        This is a principle we don't compromise on.
```

### ❌ Clear Mistakes

```
You: I'll use DateTime.Now for timestamps across timezones.

Mentor: ⚠️ This is a known anti-pattern with painful consequences.
        
        DateTime.Now = server's local time (could be PST, EST, UTC)
        
        Result when deployed:
        - Dev machine (PST): orders "from the future"
        - Production (UTC): time offset issues
        - Data analysis: impossible to correlate events
        
        Always use: DateTime.UtcNow or DateTimeOffset
        
        This isn't opinion - it's learned from thousands of 
        developers making this exact mistake.
```

---

## 💬 Sample Interactions

### Example 1: Design Discussion

```
You: @mentor
     
     I'm building a notification system. Users can get emails,
     SMS, and push notifications. Should I create separate
     classes for each?

Mentor: Great question! Let's think through the design space. 🎨
        
        First, let's identify what's COMMON vs what's DIFFERENT:
        
        **Common Aspects:**
        - All need: recipient, message, subject/title
        - All do: send notification, handle failures, retry
        - All have: delivery status, timestamps
        
        **Different Aspects:**
        - Email needs: HTML body, attachments
        - SMS needs: phone number validation, character limits  
        - Push needs: device tokens, platforms (iOS/Android)
        
        Now, given this, think about:
        
        **Approach A: Separate Classes**
        EmailNotifier, SmsNotifier, PushNotifier
        
        Pros/Cons?
        
        **Approach B: Strategy Pattern**
        INotificationStrategy with implementations
        
        Pros/Cons?
        
        **Approach C: Single Class with Type Enum**
        NotificationService.Send(type, message)
        
        Pros/Cons?
        
        Let's reason through each. Which handles:
        - Adding new notification types? (extensibility)
        - Testing each channel independently?
        - Shared retry logic? (DRY principle)
        
        What are your thoughts on each approach?

You: I think strategy pattern because I can add new types
     without changing existing code?

Mentor: Excellent reasoning! You've identified the Open/Closed
        Principle. 👍
        
        Now let's go deeper:
        
        Strategy pattern gives you:
        ✓ Open for extension (new strategies)
        ✓ Closed for modification (core code unchanged)
        ✓ Easy to test (mock each strategy)
        
        But consider:
        - Where does the retry logic go?
        - How do you handle notification preferences?
          (user wants email NOT SMS)
        - How do you batch notifications?
        
        Perhaps you need BOTH:
        - Strategy for channel-specific sending
        - Coordinator/Manager for orchestration
        
        What would that architecture look like?
```

### Example 2: Debugging Approach

```
You: @mentor
     
     My test is failing but I don't know why. Should I add
     more logging?

Mentor: Before adding logging, let's debug systematically. 🔍
        
        **The Scientific Method:**
        
        1. Observe: What's the failure? (exception? wrong value?)
        2. Hypothesis: What do you THINK is wrong?
        3. Experiment: How can you test your hypothesis?
        4. Analyze: Were you right? If not, new hypothesis.
        
        Walk me through:
        
        **Test Details:**
        - What's the test name?
        - What's the assertion that's failing?
        - Expected vs actual values?
        
        **Your Hypothesis:**
        - What do you think is causing it?
        - Why do you think that?
        - What evidence supports this?
        
        Instead of "add logging everywhere", let's be strategic.
        Where would logging actually help confirm/deny your hypothesis?
```

---

## 📚 Summary

| What You Want | What to Type |
|---------------|--------------|
| Design guidance | `@mentor How should I design [feature]?` |
| Architecture decision | `@mentor Should I use [A] or [B]?` |
| Code review | `@mentor Review my approach: [explain design]` |
| Learn concept | `@mentor Help me understand [concept]` |
| Debug reasoning | `@mentor I'm stuck on [problem], guide me` |
| Validate assumptions | `@mentor I'm thinking [approach], thoughts?` |
| Tradeoff analysis | `@mentor Pros/cons of [decision]?` |
| Security guidance | `@mentor Is [security approach] safe?` |
| Performance question | `@mentor How do I optimize [scenario]?` |
| Best practices | `@mentor What should I consider for [task]?` |

---

**The Mentor chatmode helps you become a better engineer through guided discovery!** 🎓

- **Socratic**: Questions that lead to understanding
- **Non-judgmental**: Safe space to explore ideas
- **Firm when needed**: Direct guidance on critical mistakes
- **Focused on learning**: Understanding WHY, not just WHAT

Bring your questions, designs, and challenges - let's think through them together! 🚀

---

## 🎯 Key Principles

The Mentor operates on these core principles:

1. **No Code Writing**: Mentor guides, you implement
2. **Question Over Answer**: Helps you discover solutions
3. **Challenge Assumptions**: Makes you think critically
4. **Long-term Thinking**: Considers future implications
5. **Context Matters**: Solutions depend on YOUR specific situation
6. **Safe to Explore**: No judgment, all ideas worth examining
7. **Firm on Fundamentals**: Direct on security, data integrity, core principles

Let the mentor challenge your thinking and help you grow! 💪

