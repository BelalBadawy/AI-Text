# How to Use @code-quality-guardian

> ⚠️ **NOTE**: This agent is currently **not implemented** in the agents/ directory. This documentation describes planned functionality. Check with your organization admin for availability.

## 🎯 Overview

The `@code-quality-guardian` chatmode is your **comprehensive C# code quality and security analyst** that performs deep analysis across 12 critical dimensions including security vulnerabilities, async patterns, naming conventions, complexity, test coverage, logging standards, and dead code detection.

---

## 🚀 Quick Start

### Automatic Full Scan

```
@code-quality-guardian Analyze this project for security and quality issues
```

### Targeted Analysis

```
@code-quality-guardian Check Services/PaymentService.cs for security vulnerabilities
```

### Specific Category Focus

```
@code-quality-guardian Review async patterns in Controllers/
```

---

## 📊 What Gets Analyzed

The Guardian performs analysis across **12 comprehensive categories**:

| Category | What's Checked | Priority |
|----------|----------------|----------|
| **🔒 Security Vulnerabilities** | SQL injection, XSS, auth issues, data exposure | Critical |
| **⚠️ Error Handling** | Exception swallowing, improper propagation, resource leaks | Critical |
| **📝 Logging Standards** | Structured logging, sensitive data, log levels | High |
| **⚡ Async Patterns** | Deadlocks, missing ConfigureAwait, async void | High |
| **🗑️ Dead Code** | Unused methods/classes, unreachable code, orphaned files | Medium |
| **🔄 Complexity** | Cyclomatic complexity, method length, nesting depth | Medium |
| **📝 Naming Conventions** | PascalCase, camelCase, interface prefixes, async suffix | Medium |
| **🧪 Test Coverage** | Line coverage, branch coverage, missing tests | High |
| **🔧 Maintainability** | SOLID principles, code duplication, parameter count | Medium |
| **📖 Documentation** | Missing comments, outdated docs, XML documentation | Low |
| **🏗️ Architectural Obsolescence** | Deprecated APIs, outdated patterns, legacy frameworks | Medium |
| **💨 Code Smells** | Bloaters, couplers, primitive obsession | Low |

---

## 📋 Analysis Modes

### Mode 1: Full Project Scan

Comprehensive analysis of entire codebase:

```
@code-quality-guardian

Perform full security and quality scan on this solution.
```

**Output:**
```
🔍 Code Quality Guardian - Full Analysis
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 SUMMARY DASHBOARD:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔒 Security: 12 vulnerabilities (Critical: 3, High: 5, Medium: 4)
⚠️  Error Handling: 8 improper patterns detected
📝 Logging: 23 issues (Sensitive Data: 4, Unstructured: 15, Wrong Level: 4)
🔧 Maintainability: 45 issues (SOLID: 12, Duplication: 18, Complexity: 15)
📖 Documentation: 67 missing/poor documentation instances
🏗️  Architecture: 9 obsolete patterns detected
💨 Code Smells: 34 smells (Bloaters: 12, Couplers: 15, Others: 7)
🗑️  Dead Code: 28 instances (Unused: 18, Unreachable: 7, Commented: 3)
⚡ Async: 14 pattern violations
📝 Naming: 31 convention violations
🔄 Complexity: 8 methods exceed threshold
🧪 Coverage: 67% line coverage, 54% branch coverage
✅ Tests: 23 missing, 2 failing, 5 slow

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

❌ CRITICAL ISSUES (Must Fix Immediately):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. SQL Injection Vulnerability
   Location: Repositories/UserRepository.cs:45
   Severity: CRITICAL
   
   Current Code:
   string sql = $"SELECT * FROM Users WHERE Email = '{email}'";
   
   Issue: Direct string interpolation allows SQL injection attacks
   
   Fix:
   string sql = "SELECT * FROM Users WHERE Email = @Email";
   command.Parameters.AddWithValue("@Email", email);
   
   Impact: Database compromise, data theft, unauthorized access

2. Sensitive Data in Logs
   Location: Services/AuthService.cs:89
   Severity: CRITICAL
   
   Current Code:
   _logger.LogInformation($"User login: {username} with password {password}");
   
   Issue: Passwords logged in plain text
   
   Fix:
   _logger.LogInformation("User login attempt for {Username}", username);
   
   Impact: Credential exposure, compliance violations

[... continues with detailed analysis ...]
```

### Mode 2: File-Specific Analysis

Focus on specific files or directories:

```
@code-quality-guardian

Analyze Services/PaymentService.cs for all quality issues.
```

### Mode 3: Category-Specific Scan

Target specific quality dimensions:

```
@code-quality-guardian

Check for security vulnerabilities only in Controllers/
```

```
@code-quality-guardian

Review async patterns and potential deadlocks in the entire solution.
```

```
@code-quality-guardian

Find all dead code and unused methods in Services/
```

### Mode 4: Pre-Commit Review

Quick scan before committing:

```
@code-quality-guardian

Quick review of my recent changes for critical issues only.
```

---

## 🔒 Security Analysis Details

### What Gets Detected

**Input Validation Issues:**
- SQL injection vulnerabilities
- XSS (Cross-Site Scripting) risks
- Command injection possibilities
- Path traversal vulnerabilities

**Authentication/Authorization:**
- Weak authentication patterns
- Missing authorization checks
- Privilege escalation risks
- Session management issues

**Data Protection:**
- Sensitive data exposure
- Improper encryption usage
- Hardcoded credentials
- Insecure data storage

**Dependencies:**
- Vulnerable NuGet packages
- Outdated libraries with known CVEs
- Unnecessary dependencies

**Example Output:**
```
🔒 SECURITY VULNERABILITIES (12 found):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

❌ CRITICAL - SQL Injection (3 instances):
   
   1. UserRepository.cs:45 - GetUserByEmail
      string sql = "SELECT * FROM Users WHERE Id = " + userId;
      → Use parameterized queries
   
   2. OrderRepository.cs:123 - SearchOrders  
      var query = $"SELECT * FROM Orders WHERE Status = '{status}'";
      → Use EF Core or parameters
   
   3. ReportService.cs:67 - GetCustomReport
      command.CommandText = "SELECT * WHERE " + filter;
      → Sanitize input, use parameters

❌ CRITICAL - Hardcoded Credentials (2 instances):
   
   1. appsettings.json:12
      "ConnectionString": "Server=prod;Password=Admin123"
      → Use Azure Key Vault or environment variables
   
   2. EmailService.cs:23
      var password = "smtp_password_123";
      → Use secret management

⚠️ HIGH - Missing Authorization (5 instances):
   
   1. AdminController.cs:34 - DeleteUser
      Missing [Authorize(Roles = "Admin")] attribute
      → Add authorization check
```

---

## 📝 Logging Standards Analysis

### What Gets Detected

**Unstructured Logging:**
```csharp
// ❌ BAD - String interpolation loses structure
_logger.LogInformation($"User {userId} processed order {orderId}");

// ✅ GOOD - Structured logging
_logger.LogInformation("User processed order with {UserId} and {OrderId}", userId, orderId);
```

**Sensitive Data Exposure:**
```csharp
// ❌ BAD - Logging sensitive information
_logger.LogInformation($"Payment with card {cardNumber}");

// ✅ GOOD - Mask sensitive data
_logger.LogInformation("Payment processed for {MaskedCard}", MaskCard(cardNumber));
```

**Wrong Log Levels:**
```csharp
// ❌ BAD - Using wrong severity
_logger.LogError("User clicked button"); // Not an error!
_logger.LogInformation(ex, "Database connection failed"); // Should be Error!

// ✅ GOOD - Appropriate levels
_logger.LogDebug("User clicked button");
_logger.LogError(ex, "Database connection failed");
```

**Example Output:**
```
📝 LOGGING ISSUES (23 found):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

❌ CRITICAL - Sensitive Data in Logs (4 instances):
   
   1. AuthService.cs:45
      _logger.LogInformation($"Login: {username}:{password}");
      → Remove password, use structured logging
   
   2. PaymentService.cs:89
      _logger.LogDebug($"Card: {cardNumber}, CVV: {cvv}");
      → Never log PII or payment data

⚠️ HIGH - Unstructured Logging (15 instances):
   
   1. OrderService.cs:23
      _logger.LogInformation("Processing order " + orderId);
      → Use: _logger.LogInformation("Processing {OrderId}", orderId)
   
   2. UserService.cs:67
      _logger.LogWarning($"User {id} not found");
      → Use structured properties

💡 MEDIUM - Wrong Log Levels (4 instances):
   
   1. HomeController.cs:12
      _logger.LogError("Page loaded"); // Not an error!
      → Use LogInformation or LogDebug
```

---

## ⚡ Async Pattern Analysis

### What Gets Detected

**Deadlock Risks:**
```csharp
// ❌ BAD - Blocking async code
var result = GetDataAsync().Result; // Deadlock risk!
GetDataAsync().Wait(); // Deadlock risk!

// ✅ GOOD - Proper async/await
var result = await GetDataAsync();
```

**Missing ConfigureAwait:**
```csharp
// ❌ BAD - Library code without ConfigureAwait
await httpClient.GetAsync(url); // Can cause deadlocks in library

// ✅ GOOD - Use ConfigureAwait(false) in libraries
await httpClient.GetAsync(url).ConfigureAwait(false);
```

**Async Void:**
```csharp
// ❌ BAD - async void (can't catch exceptions)
public async void ProcessData() { }

// ✅ GOOD - Return Task
public async Task ProcessDataAsync() { }
```

**Example Output:**
```
⚡ ASYNC PATTERN VIOLATIONS (14 found):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

❌ CRITICAL - Deadlock Risks (6 instances):
   
   1. UserService.cs:45
      var user = GetUserAsync().Result;
      → Change to: var user = await GetUserAsync();
   
   2. PaymentController.cs:89
      ProcessPaymentAsync().Wait();
      → Change to: await ProcessPaymentAsync();

❌ CRITICAL - Async Void (3 instances):
   
   1. EventHandler.cs:23
      public async void OnDataReceived() { }
      → Return Task, not void

⚠️ HIGH - Missing ConfigureAwait (5 instances):
   
   1. PaymentService.cs (library code):23
      await httpClient.PostAsync(url, content);
      → Add .ConfigureAwait(false)
```

---

## 🗑️ Dead Code Detection

### What Gets Identified

**Unused Code:**
- Methods with no references
- Classes never instantiated
- Properties never accessed
- Fields declared but unused
- Unused method parameters
- Unused local variables

**Unreachable Code:**
- Code after return/throw statements
- Impossible conditional branches
- Dead switch cases

**Commented Code:**
- Large blocks of commented-out code
- No explanation for why code is commented

**Example Output:**
```
🗑️ DEAD CODE (28 instances):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Unused Methods (12):
   1. UserService.cs:145 - private void ValidateEmail()
      No references found → Safe to delete
   
   2. PaymentHelper.cs:89 - public static decimal CalculateDiscount()
      No references found → Safe to delete

Unused Classes (3):
   1. Models/LegacyUser.cs
      Never instantiated → Remove entire file
   
   2. Helpers/OldPaymentProcessor.cs
      No usages found → Delete

Unreachable Code (7):
   1. OrderService.cs:67
      return result;
      LogInformation("Order processed"); // Never executes!
      → Remove unreachable line
   
   2. PaymentService.cs:123
      if (false) { ... } // Always false!
      → Remove dead branch

Commented Code (3):
   1. UserRepository.cs:45-89 (45 lines commented)
      No explanation provided
      → Delete or document why it's kept

Unused Parameters (3):
   1. CalculateTotal(decimal price, int quantity, bool isActive)
      Parameter 'isActive' never used → Remove or use discard (_)
```

---

## 🔄 Complexity Analysis

### Metrics Tracked

**Cyclomatic Complexity:**
- Method complexity (decision points)
- Class complexity (aggregate)
- File complexity (total)

**Code Size:**
- Method length (lines)
- Class size (lines)
- Parameter count

**Nesting Depth:**
- Conditional nesting levels
- Loop nesting depth

**Thresholds:**
```
Method Complexity:  ≤ 10 (Warning), ≤ 15 (Error)
Method Length:      ≤ 50 lines (Warning), ≤ 100 lines (Error)
Class Size:         ≤ 500 lines (Warning), ≤ 1000 lines (Error)
Parameters:         ≤ 5 (Warning), ≤ 8 (Error)
Nesting Depth:      ≤ 4 levels (Warning), ≤ 6 levels (Error)
```

**Example Output:**
```
🔄 COMPLEXITY ANALYSIS (8 methods exceed threshold):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

❌ CRITICAL - High Complexity:
   
   1. OrderService.ProcessOrder() - Complexity: 23
      Location: Services/OrderService.cs:45-189 (145 lines)
      Issues:
      - 23 decision points (if/while/for/switch)
      - 145 lines (threshold: 100)
      - 8 parameters (threshold: 5)
      - 6 levels of nesting (threshold: 4)
      
      Refactoring Suggestions:
      ✓ Extract validation logic → ValidateOrder()
      ✓ Extract payment processing → ProcessPayment()
      ✓ Extract notification → SendNotifications()
      ✓ Use parameter object for 8 parameters
      ✓ Apply early returns to reduce nesting

   2. UserService.AuthenticateUser() - Complexity: 18
      Location: Services/UserService.cs:234-312 (79 lines)
      Issues:
      - 18 decision points
      - Deep nesting (5 levels)
      
      Refactoring Suggestions:
      ✓ Extract to separate methods per auth type
      ✓ Use strategy pattern for different auth methods
      ✓ Apply guard clauses to reduce nesting
```

---

## 🧪 Test Coverage Analysis

### What Gets Analyzed

**Coverage Metrics:**
- Line coverage percentage
- Branch coverage percentage
- Method coverage
- Critical path coverage

**Missing Tests:**
- Untested public methods
- Uncovered exception paths
- Missing edge case tests
- Untested critical business logic

**Coverage Targets:**
```
Line Coverage:      ≥ 80% (Good), ≥ 90% (Excellent)
Branch Coverage:    ≥ 70% (Good), ≥ 85% (Excellent)
Critical Methods:   100% coverage required
```

**Example Output:**
```
🧪 TEST COVERAGE ANALYSIS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Overall Coverage: 67% line, 54% branch

❌ CRITICAL - Untested Critical Methods:
   
   1. PaymentService.ProcessPayment() - 0% coverage
      Critical: Handles financial transactions
      Missing tests:
      ✓ Successful payment scenario
      ✓ Insufficient funds handling
      ✓ Network failure retry logic
      ✓ Invalid card data validation
   
   2. AuthService.ValidateToken() - 0% coverage
      Critical: Security-sensitive method
      Missing tests:
      ✓ Valid token acceptance
      ✓ Expired token rejection
      ✓ Tampered token detection
      ✓ Null/empty token handling

⚠️ HIGH - Low Coverage Areas:

   Services/OrderService.cs - 45% line coverage
   Missing coverage for:
   - Exception handling paths (12 catch blocks untested)
   - Edge cases (null inputs, empty collections)
   - Error scenarios (database failures, timeouts)

   Controllers/PaymentController.cs - 38% branch coverage
   Untested branches:
   - Lines 45-67: Error handling code path
   - Lines 89-102: Validation failure branch
   - Lines 145-178: Refund processing logic
```

---

## 🎯 Usage Scenarios

### Scenario 1: Pre-Release Security Audit

```
@code-quality-guardian

Perform comprehensive security audit before production release.
Focus on critical and high severity issues only.
```

### Scenario 2: Legacy Code Assessment

```
@code-quality-guardian

Analyze Services/LegacyPaymentService.cs for:
1. Security vulnerabilities
2. Architectural obsolescence
3. Dead code that can be removed
4. Complexity that needs refactoring
```

### Scenario 3: Code Review Assistant

```
@code-quality-guardian

Review my recent changes in PR #456:
- Services/UserService.cs
- Controllers/AuthController.cs

Check for security, async patterns, and naming issues.
```

### Scenario 4: Technical Debt Assessment

```
@code-quality-guardian

Calculate technical debt in this solution:
- Dead code to remove
- Code smells to fix
- Complexity to reduce
- Tests to add

Prioritize by effort vs impact.
```

### Scenario 5: Logging Audit

```
@code-quality-guardian

Audit all logging statements for:
- Sensitive data exposure
- Unstructured logging
- Wrong log levels
- Missing correlation IDs
```

### Scenario 6: Test Coverage Improvement

```
@code-quality-guardian

Identify untested code paths and suggest test cases:
- Focus on Services/ directory
- Prioritize critical business logic
- Include exception handling paths
```

---

## 🔧 Remediation Workflow

The Guardian not only finds issues but helps fix them:

### Step 1: Analysis
```
@code-quality-guardian Analyze Services/PaymentService.cs
```

### Step 2: Review Priority
Guardian presents issues by severity:
1. Critical (security, data loss risks)
2. High (deadlocks, error handling)
3. Medium (complexity, maintainability)
4. Low (naming, documentation)

### Step 3: Fix Issues
```
Fix all critical security issues in PaymentService.cs
```

### Step 4: Verify
```
Re-analyze PaymentService.cs to verify fixes
```

### Step 5: Iterate
```
Now fix high priority async issues
```

---

## 📈 Quality Metrics Dashboard

After analysis, get an executive summary:

```
@code-quality-guardian Generate quality metrics dashboard for management
```

**Output:**
```
📊 CODE QUALITY METRICS DASHBOARD
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Project: Zelis.Payment.Service
Analysis Date: 2025-10-30
Files Analyzed: 127 (.cs files)
Lines of Code: 45,230

SECURITY SCORE: 6/10 ⚠️
├─ Critical Issues: 3 ❌
├─ High Issues: 5 ⚠️
└─ Medium Issues: 4 💡

CODE QUALITY SCORE: 7/10 💡
├─ Maintainability Index: 72/100
├─ Average Complexity: 8.5 (target: ≤10)
├─ Code Duplication: 12% (target: <10%)
└─ Dead Code: 28 instances

TEST COVERAGE: 67% ⚠️
├─ Line Coverage: 67% (target: ≥80%)
├─ Branch Coverage: 54% (target: ≥70%)
├─ Critical Methods: 12 untested ❌
└─ Test Quality: Good ✅

TECHNICAL DEBT:
├─ Estimated Effort: 23 developer days
├─ High Priority: 8 days
├─ Medium Priority: 10 days
└─ Low Priority: 5 days

TREND: ↗️ Improving
(+8% from last analysis)

TOP PRIORITIES:
1. Fix 3 critical security vulnerabilities (2 days)
2. Add tests for 12 critical methods (5 days)
3. Refactor 8 high-complexity methods (4 days)
4. Remove 28 dead code instances (1 day)
5. Fix 23 logging issues (2 days)
```

---

## 💡 Pro Tips

### Tip 1: Run Before Every PR

```bash
# Add to pre-push hook
@code-quality-guardian Quick scan of staged changes
```

### Tip 2: Focus on Your Changes

```
@code-quality-guardian

Analyze only files I modified in the last commit.
Focus on critical and high issues.
```

### Tip 3: Combine with Testing

```
@code-quality-guardian

After analysis, run all tests and correlate failures with quality issues found.
```

### Tip 4: Track Progress Over Time

```
@code-quality-guardian

Compare quality metrics vs last analysis.
Show improvements and regressions.
```

### Tip 5: Use for Learning

```
@code-quality-guardian

Explain each security vulnerability you find.
Help me understand why it's dangerous and how to prevent it.
```

---

## 🚨 Integration with CI/CD

### GitHub Actions Example

```yaml
- name: Quality Guardian Analysis
  run: |
    @code-quality-guardian Analyze Services/ Controllers/
    Exit with code 1 if critical issues found
```

### Quality Gates

Fail build if:
- ❌ Any critical security issues
- ❌ Coverage drops below 80%
- ❌ New code has complexity > 15
- ⚠️ More than 5 high priority issues

---

## 📚 Summary

| What You Want | What to Type |
|---------------|--------------|
| Full project scan | `@code-quality-guardian Analyze entire solution` |
| Security audit only | `@code-quality-guardian Security scan` |
| Check specific file | `@code-quality-guardian Review Services/PaymentService.cs` |
| Find dead code | `@code-quality-guardian Find unused code and methods` |
| Async pattern check | `@code-quality-guardian Check for async deadlock risks` |
| Logging audit | `@code-quality-guardian Review all logging for sensitive data` |
| Complexity analysis | `@code-quality-guardian Find overly complex methods` |
| Coverage gaps | `@code-quality-guardian Identify untested code paths` |
| Pre-commit check | `@code-quality-guardian Quick scan of my changes` |
| Quality dashboard | `@code-quality-guardian Generate metrics report` |

---

**The Code Quality Guardian ensures your C# codebase is secure, maintainable, and production-ready!** 🛡️

- **Comprehensive**: 12 analysis categories covering everything from security to documentation
- **Actionable**: Prioritized issues with specific fixes
- **Intelligent**: Understands C# best practices and industry standards
- **Thorough**: From critical security flaws to minor naming issues

Just point it at your code and let it guard your quality! 🚀

