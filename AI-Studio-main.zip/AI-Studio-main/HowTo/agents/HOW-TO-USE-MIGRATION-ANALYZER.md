# How to Use Migration Analyzer

> **📝 Note on Agent Names**: 
> - **Interactive chatmode**: Use `@migration-orchestrator` in VS Code
> - **Mission Control**: Select the `migration-orchestrator` agent
> - This guide uses "migration analyzer" generically to refer to migration analysis capabilities

Analyze legacy .NET Framework codebases for containerization and modernization planning. Identifies migration blockers, generates architecture diagrams, and provides remediation guidance.

## Three Ways to Use

| Mode | How to Invoke | Output | Best For |
|------|---------------|--------|----------|
| **Interactive** | `@migration-orchestrator` | Answers to specific questions | Exploration, follow-up questions, specific queries |
| **Mission Control (Org Agent)** | GitHub Copilot Mission Control → select `migration-orchestrator` | PR with `docs/migration-readiness/*` | Batch analysis across many repos, audit + planning PRs |

### Interactive Mode (Chatmode)

Use `@migration-orchestrator` for iterative Q&A:

```
@migration-orchestrator What WCF services exist in this codebase?
@migration-orchestrator What components depend on OrderService?
@migration-orchestrator Can we deploy to Linux containers?
```

### One-Shot Documentation Mode (Prompt)

> ⚠️ **NOTE**: The one-shot prompt file is not yet available in this repository. Use Interactive Mode or Mission Control instead.

For comprehensive migration documentation, request all deliverables in the interactive session:

```
@migration-orchestrator Analyze this repository and generate complete migration documentation including:
- Migration readiness score
- Blocker inventory with file/line references
- C4 container diagram (Mermaid)
- Project dependency graph
- Container target recommendation
- Migration roadmap with effort estimates
- Remediation code examples
```

---

## Mission Control (Organization Agent)

Use this when you want to run migration analysis **across multiple repositories** from a centralized dashboard.

### Prerequisites

- Your org must have the custom agent profiles available (org/enterprise-level custom agents), hosted in your org agent repo (for example: `.github-private`).
- Select the main agent **`migration-orchestrator`**. Subagents (Reader/Searcher/Writer/Verifier) are internal-only.

### How to Run

1. Open GitHub Copilot **Mission Control / Agent HQ**.
2. Select one (or many) repositories you want to analyze.
3. Select the custom agent **`migration-orchestrator`**.
4. Prompt example:

```
Perform a full migration readiness analysis for modernization + containerization.
Produce a PR with the deliverables under docs/migration-readiness/.
```

### Expected Output

The agent will create a PR that adds/updates:

- `docs/migration-readiness/README.md`
- `docs/migration-readiness/readiness-score.md`
- `docs/migration-readiness/blockers.md`
- `docs/migration-readiness/architecture.md`
- `docs/migration-readiness/roadmap.md`

## Quick Start (Interactive)

```
@migration-orchestrator Analyze this solution for containerization blockers
```

## When to Use

- Planning migration from .NET Framework 4.x to .NET 8/9/10+
- Assessing feasibility of Linux vs Windows containers
- Identifying WCF, ASMX, COM+, and other legacy technology usage
- Generating architecture documentation for migration planning
- Estimating effort for modernization projects

## Example Queries

### Discovery & Analysis

```
@migration-orchestrator What is the target framework for all projects in this solution?

@migration-orchestrator Find all WCF services in this codebase

@migration-orchestrator Are there any Windows Registry usages that would block Linux containers?

@migration-orchestrator List all P/Invoke declarations and assess Linux compatibility
```

### Architecture Documentation

```
@migration-orchestrator Generate a C4 container diagram for this system

@migration-orchestrator Create a project dependency graph showing blocked components

@migration-orchestrator Show the data flow between this application and external systems
```

### Migration Planning

```
@migration-orchestrator Can we deploy this to Linux containers? What blockers exist?

@migration-orchestrator What is our Migration Readiness Score for .NET 9?

@migration-orchestrator What's the estimated effort to migrate this solution to .NET 9?

@migration-orchestrator Create a phased migration roadmap for this application

@migration-orchestrator What are the top 5 risks for this migration?
```

### Database Migration (SQL Server → AWS Aurora PostgreSQL)

Use these when your system relies on SQL Server schemas, stored procedures, and triggers, and you plan to migrate to **AWS Aurora PostgreSQL**.

#### Interactive (Chatmode) examples

```
@migration-orchestrator Identify all SQL Server dependencies in this repo (providers, connection strings, ORM usage).

@migration-orchestrator Find any stored procedures, triggers, or views checked into the repo and summarize business logic in the database.

@migration-orchestrator List T-SQL features that will block or complicate migration to Postgres (MERGE, TOP, NOLOCK, OUTPUT INSERTED, GO, TRY/CATCH, SQL Agent jobs, CLR).

@migration-orchestrator Propose a strategy to move business logic out of stored procedures and triggers into application services, with phases and risks.
```

#### Mission Control (Org Agent) examples

When using **Mission Control** with `migration-orchestrator`, include a prompt like:

```
Include database migration analysis for SQL Server → AWS Aurora PostgreSQL.
Create docs/migration-readiness/database.md with blockers and a plan to move business logic out of the database.
```

### Remediation Guidance

```
@migration-orchestrator How do I replace this WCF service with gRPC?

@migration-orchestrator Show me how to convert this Windows Service to a Worker Service

@migration-orchestrator What's the recommended replacement for System.Web.HttpContext.Current?
```

## Blocker Categories

The analyzer detects these migration blocker categories:

| Severity | Category | Impact |
|----------|----------|--------|
| 🔴 High | WCF Services | Must replace with gRPC or REST |
| 🔴 High | ASMX Web Services | Must replace with Web API |
| 🔴 High | .NET Remoting | Must replace with gRPC or messaging |
| 🔴 High | COM+ / Enterprise Services | Must refactor to managed code |
| 🟡 Medium | Windows Registry | Use config files or environment variables |
| 🟡 Medium | Windows Services | Convert to Worker Service |
| 🟡 Medium | P/Invoke (Windows DLLs) | Find cross-platform alternatives |
| 🟡 Medium | System.Web | Migrate to ASP.NET Core |
| 🟢 Low | System.Drawing | Use System.Drawing.Common or SkiaSharp |
| 🟢 Low | BinaryFormatter | Use JSON or Protobuf |

## Output Formats

### Blocker Inventory Table

The analyzer produces tables like:

| Component | Blocker Type | File | Line | Severity | Effort |
|-----------|--------------|------|------|----------|--------|
| OrderService | WCF | Services/OrderService.svc.cs | 15 | High | 5-10 days |
| ConfigHelper | Registry | Utils/ConfigHelper.cs | 42 | Medium | 1-2 days |

### Mermaid Diagrams

The analyzer generates:

- **C4 Container Diagrams** - System architecture overview
- **Dependency Graphs** - Project relationships with blocker highlighting
- **Data Flow Diagrams** - Integration points and data movement

## Full Documentation Generation

For comprehensive migration documentation, use **Mission Control** with the `migration-orchestrator` agent, or request all deliverables in Interactive Mode:

```
@migration-orchestrator Generate complete migration documentation with:
- Target framework: .NET 8+
- Container target: Linux
- Include all diagrams (C4, dependency graph, data flow)
- Include code examples for each blocker type
- Output to docs/migration-readiness/
```

This approach allows configurable options:

- Target framework (.NET 8, 9, or 10)
- Container target (Linux or Windows)
- Detail level (Executive Summary to Comprehensive)
- Diagram types
- Code examples

## Tips for Best Results

1. **Open the solution file** before starting analysis - this gives context about all projects

2. **Be specific** about what you're looking for:
   - ❌ "Analyze this code"
   - ✅ "Find all WCF service contracts and their dependencies"

3. **Ask follow-up questions** - the chatmode maintains context:
   ```
   @migration-orchestrator Find all WCF services
   @migration-orchestrator For the OrderService you found, what components depend on it?
   ```

4. **Request diagrams** for complex systems - visual documentation helps stakeholders understand impact

5. **Verify findings** - always review line numbers and confirm blockers exist before planning remediation

## Related Resources

- [.NET Upgrade Assistant](https://learn.microsoft.com/en-us/dotnet/core/porting/upgrade-assistant-overview)
- [Porting from .NET Framework](https://learn.microsoft.com/en-us/dotnet/core/porting/)
- [gRPC for WCF Developers](https://learn.microsoft.com/en-us/dotnet/architecture/grpc-for-wcf-developers/)
- [Worker Services in .NET](https://learn.microsoft.com/en-us/dotnet/core/extensions/workers)

