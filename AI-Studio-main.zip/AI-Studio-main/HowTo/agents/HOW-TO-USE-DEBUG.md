# How to Use @debug

## 🎯 Overview

The `@debug` chatmode is your **systematic debugging partner** that follows a structured 4-phase process to identify, analyze, and resolve bugs in your application. It emphasizes understanding the problem before attempting fixes and ensures thorough verification after each change.

---

## 🚀 Quick Start

### Simple Bug Fix

```
@debug

My application is crashing when users click the submit button.
Error: NullReferenceException at line 45 in OrderController.cs
```

### Test Failure Investigation

```
@debug

Tests are failing: UserServiceTests.GetUser_WithValidId_ReturnsUser
```

### Production Issue

```
@debug

Production issue: Users report intermittent 500 errors on checkout.
Error logs attached: [paste logs]
```

---

## 🔄 The 4-Phase Debug Process

The debug mode follows a systematic methodology:

```
Phase 1: Problem Assessment
    ↓
Phase 2: Investigation  
    ↓
Phase 3: Resolution
    ↓
Phase 4: Quality Assurance
```

---

## 📋 Phase 1: Problem Assessment

### What Happens

1. **Gathers Context**
   - Reads error messages and stack traces
   - Examines recent code changes
   - Reviews relevant test failures
   - Identifies expected vs actual behavior

2. **Reproduces the Bug**
   - Runs application or tests to confirm the issue
   - Documents exact reproduction steps
   - Captures error outputs and logs

3. **Creates Bug Report**
   - Steps to reproduce
   - Expected behavior
   - Actual behavior
   - Error messages/stack traces
   - Environment details

### Example Session

```
You: @debug
     
     Application crashes when saving orders.
     Error: Object reference not set to an instance of an object

AI:  🐛 Debug Mode - Problem Assessment
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     
     Let me gather information about this issue...
     
     ✓ Reading stack trace
     ✓ Examining OrderController.cs and related files
     ✓ Checking recent git history
     ✓ Reviewing related test files
     
     📊 BUG REPORT:
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     
     Issue: NullReferenceException when saving orders
     
     Stack Trace:
       at OrderController.CreateOrder(OrderRequest request) 
          in Controllers/OrderController.cs:line 45
       at OrderService.SaveOrder(Order order)
          in Services/OrderService.cs:line 89
     
     Steps to Reproduce:
       1. Navigate to /orders/create
       2. Fill out order form
       3. Click "Submit Order" button
       4. Application crashes
     
     Expected Behavior:
       Order should be saved to database and confirmation shown
     
     Actual Behavior:
       NullReferenceException thrown, no order saved
     
     Environment:
       - .NET 8+
       - SQL Server database
       - Running locally in Development mode
     
     Recent Changes (last 3 commits):
       - Added customer validation
       - Modified order creation logic
       - Updated payment processing
     
     Attempting to reproduce...
```

---

## 🔍 Phase 2: Investigation

### What Happens

1. **Root Cause Analysis**
   - Traces code execution path
   - Examines variable states and data flows
   - Checks for common issues:
     - Null references
     - Off-by-one errors
     - Race conditions
     - Incorrect assumptions
   - Reviews how components interact

2. **Hypothesis Formation**
   - Creates specific hypotheses about the cause
   - Prioritizes by likelihood and impact
   - Plans verification steps

### Example Continuation

```
AI:  🔍 Investigation Phase
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     
     ✓ Bug reproduced successfully
     ✓ Exception occurs at line 45: order.Customer.Name
     
     Tracing execution path:
     
     OrderController.CreateOrder (line 45)
       ↓
     order.Customer.Name accessed
       ↓
     ISSUE: order.Customer is NULL
     
     Examining why Customer is null...
     
     Found in OrderService.SaveOrder (line 89):
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     var order = new Order 
     {
         OrderNumber = GenerateOrderNumber(),
         OrderDate = DateTime.UtcNow,
         TotalAmount = CalculateTotal(request.Items)
         // Customer property NOT set!
     };
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     
     🎯 ROOT CAUSE IDENTIFIED:
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     
     The Customer property is not being assigned when creating
     the Order object in OrderService.SaveOrder method.
     
     This was introduced in commit abc123 (2 days ago) when 
     order creation logic was refactored.
     
     Hypothesis: Developer forgot to map Customer from request
     
     Verification: Checking request object structure...
     ✓ request.CustomerId exists
     ✓ Customer lookup method exists (GetCustomerById)
     ✓ Other code references show Customer should be populated
     
     Confidence: HIGH (95%)
```

---

## 🔧 Phase 3: Resolution

### What Happens

1. **Implements Fix**
   - Makes targeted, minimal changes
   - Follows existing code patterns
   - Adds defensive programming where appropriate
   - Considers edge cases and side effects

2. **Verification**
   - Runs tests to verify fix
   - Executes original reproduction steps
   - Checks for regressions
   - Tests edge cases

### Example Continuation

```
AI:  🔧 Resolution Phase
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     
     Implementing fix...
     
     File: Services/OrderService.cs
     
     BEFORE (lines 85-92):
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     public async Task<Order> SaveOrder(OrderRequest request)
     {
         var order = new Order 
         {
             OrderNumber = GenerateOrderNumber(),
             OrderDate = DateTime.UtcNow,
             TotalAmount = CalculateTotal(request.Items)
         };
         
         await _repository.SaveAsync(order);
         return order;
     }
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     
     AFTER (lines 85-98):
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     public async Task<Order> SaveOrder(OrderRequest request)
     {
         // Validate customer exists
         var customer = await _customerRepository
             .GetByIdAsync(request.CustomerId);
         
         if (customer == null)
             throw new InvalidOperationException(
                 $"Customer {request.CustomerId} not found");
         
         var order = new Order 
         {
             OrderNumber = GenerateOrderNumber(),
             OrderDate = DateTime.UtcNow,
             TotalAmount = CalculateTotal(request.Items),
             Customer = customer  // FIX: Assign customer
         };
         
         await _repository.SaveAsync(order);
         return order;
     }
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     
     Changes made:
     ✓ Added customer lookup
     ✓ Added null check with descriptive error
     ✓ Assigned customer to order
     ✓ Added defensive validation
     
     Running verification...
     
     ✓ Original reproduction steps: PASS
     ✓ Unit tests: OrderServiceTests - PASS (12/12)
     ✓ Integration tests: OrderIntegrationTests - PASS (5/5)
     
     Testing edge cases...
     ✓ Invalid customer ID - throws appropriate exception
     ✓ Null customer ID - validation catches it
     ✓ Concurrent order creation - no race conditions
     
     ✅ FIX VERIFIED - Bug resolved!
```

---

## ✅ Phase 4: Quality Assurance

### What Happens

1. **Code Quality Review**
   - Reviews fix for quality and maintainability
   - Ensures code follows conventions
   - Checks for similar bugs elsewhere

2. **Test Enhancement**
   - Adds or updates tests to prevent regression
   - Ensures edge cases are covered

3. **Documentation**
   - Updates documentation if needed
   - Suggests preventive measures

4. **Final Report**
   - Summarizes what was fixed and how
   - Explains root cause
   - Documents preventive measures

### Example Conclusion

```
AI:  ✅ Quality Assurance Phase
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     
     Code Quality Review:
     ✓ Fix follows SOLID principles
     ✓ Error handling is appropriate
     ✓ Async patterns used correctly
     ✓ Code is readable and maintainable
     
     Checking for similar issues...
     
     ⚠️  Found similar pattern in InvoiceService.CreateInvoice
         - Also missing Customer assignment
         - Applying same fix...
         ✓ Fixed
     
     ⚠️  Found similar pattern in ShipmentService.CreateShipment
         - Also missing validation
         - Applying same fix...
         ✓ Fixed
     
     Adding regression tests...
     
     Created: Tests/OrderServiceTests.cs
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     [Fact]
     public async Task SaveOrder_WithInvalidCustomerId_ThrowsException()
     {
         // Arrange
         var request = new OrderRequest { CustomerId = 999 };
         
         // Act & Assert
         await Assert.ThrowsAsync<InvalidOperationException>(
             () => _service.SaveOrder(request));
     }
     
     [Fact]
     public async Task SaveOrder_WithValidCustomer_AssignsCustomerToOrder()
     {
         // Arrange
         var customer = new Customer { Id = 1, Name = "Test" };
         var request = new OrderRequest { CustomerId = 1 };
         
         // Act
         var order = await _service.SaveOrder(request);
         
         // Assert
         Assert.NotNull(order.Customer);
         Assert.Equal(customer.Id, order.Customer.Id);
     }
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     
     ✓ All new tests passing (2/2)
     
     
     📊 FINAL REPORT
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     
     🐛 Bug: NullReferenceException in order creation
     
     🎯 Root Cause:
        Order.Customer property not assigned during order creation.
        Introduced in commit abc123 during refactoring.
     
     🔧 Fix Applied:
        - Added customer lookup in SaveOrder method
        - Added validation to ensure customer exists
        - Assigned customer to order object
        - Fixed 2 similar issues in other services
     
     ✅ Verification:
        - Original bug: Fixed ✓
        - All existing tests: Passing (17/17) ✓
        - New regression tests: Added (2) ✓
        - Edge cases: Tested ✓
        - Similar bugs: Fixed (2) ✓
     
     🛡️ Prevention Measures:
        1. Added validation pattern to prevent null references
        2. Created unit tests to catch this regression
        3. Consider adding code analyzer rule to detect 
           uninitialized navigation properties
     
     💡 Recommendations:
        1. Add integration test for full order flow
        2. Consider using required properties (C# 11)
        3. Add code review checklist item: "Are all 
           navigation properties initialized?"
     
     Time to fix: 12 minutes
     Files changed: 3
     Tests added: 2
     Similar bugs fixed: 2
```

---

## 🎯 Common Debugging Scenarios

### Scenario 1: Application Crash

```
@debug

Application crashes with OutOfMemoryException after running for 2 hours.
```

**Debug Process:**
1. ✓ Reproduces with memory profiler
2. ✓ Identifies memory leak in event handler
3. ✓ Fixes by unsubscribing from events
4. ✓ Adds IDisposable pattern
5. ✓ Verifies with extended run test

### Scenario 2: Intermittent Test Failure

```
@debug

Test fails randomly: UserServiceTests.GetUsers_ReturnsCorrectOrder

Sometimes passes, sometimes fails. No clear pattern.
```

**Debug Process:**
1. ✓ Runs test multiple times to reproduce
2. ✓ Identifies race condition in test setup
3. ✓ Finds shared state between tests
4. ✓ Fixes by making tests independent
5. ✓ Runs 100 times to verify stability

### Scenario 3: Performance Degradation

```
@debug

API endpoint /api/orders is taking 30 seconds to respond.
Used to take 2 seconds last week.
```

**Debug Process:**
1. ✓ Profiles the endpoint
2. ✓ Identifies N+1 query problem
3. ✓ Fixes with .Include() for eager loading
4. ✓ Adds caching layer
5. ✓ Verifies response time < 500ms

### Scenario 4: Logic Error

```
@debug

Discount calculation is wrong.
Expected: $10 discount (10%)
Actual: $1 discount (1%)
```

**Debug Process:**
1. ✓ Traces calculation logic
2. ✓ Identifies integer division issue
3. ✓ Fixes by using decimal arithmetic
4. ✓ Adds test cases for edge values
5. ✓ Verifies all scenarios

### Scenario 5: Production Exception

```
@debug

Production error logs show:
[ERROR] Database connection timeout
Occurs during peak hours (12pm-2pm)
```

**Debug Process:**
1. ✓ Analyzes error patterns
2. ✓ Identifies connection pool exhaustion
3. ✓ Finds long-running queries not disposed
4. ✓ Implements connection pooling best practices
5. ✓ Adds monitoring and alerts

---

## 🔍 Advanced Debugging Features

### Multi-Layer Debugging

```
@debug

Issue spans multiple layers:
- Frontend: Button not responding
- Backend: 500 error in logs
- Database: Deadlock detected

Trace the complete flow.
```

**Debug walks through:**
1. Frontend event handlers
2. API request/response
3. Service layer logic
4. Database transaction
5. Identifies deadlock in stored procedure

### Historical Analysis

```
@debug

This used to work last month. What changed?

Compare: 
- Current: v2.1.0 (broken)
- Previous: v2.0.5 (working)
```

**Debug process:**
1. Reviews git history between versions
2. Runs git bisect to find breaking commit
3. Identifies exact change that broke functionality
4. Fixes and adds regression test

### Concurrency Issues

```
@debug

Race condition suspected.
Bug only appears under high load.
```

**Debug approach:**
1. Uses thread analysis tools
2. Identifies shared state without locking
3. Applies appropriate synchronization
4. Load tests to verify fix

---

## 💡 Debugging Best Practices

### DO's ✅

1. **Provide Context**
   - Error messages and stack traces
   - Steps to reproduce
   - Recent changes
   - Environment details

2. **Let Debug Follow the Process**
   - Don't skip to solution
   - Let it reproduce first
   - Review the hypothesis
   - Verify the fix

3. **Include Test Failures**
   - Failing test output
   - Test code
   - Expected vs actual values

4. **Share Logs**
   - Error logs
   - Application logs
   - Debug output

### DON'Ts ❌

1. **Don't Jump to Conclusions**
   ```
   ❌ @debug Fix the null reference error by adding null checks everywhere
   ✅ @debug NullReferenceException at line 45, help me find the root cause
   ```

2. **Don't Skip Reproduction**
   ```
   ❌ Just fix it without testing
   ✅ Let's reproduce first, then fix, then verify
   ```

3. **Don't Ignore Edge Cases**
   ```
   ❌ Works for this input, ship it!
   ✅ Test edge cases: null, empty, extreme values
   ```

---

## 🎨 Debug Output Styles

### Concise Mode

```
@debug --concise

Quick fix for NullReferenceException at line 45
```

**Output:** Short, direct fix without detailed analysis

### Verbose Mode (Default)

```
@debug

Detailed investigation of memory leak issue
```

**Output:** Complete 4-phase process with explanations

### Learn Mode

```
@debug --explain

Fix this bug and teach me why it happened and how to prevent it
```

**Output:** Educational commentary throughout process

---

## 🚨 When Debug Can't Fix

Sometimes issues need human input:

```
AI:  ⚠️  Unable to Determine Root Cause
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     
     I've identified several possible causes:
     
     1. Network timeout (40% likely)
        - Slow external API
        - Solution: Add timeout handling
     
     2. Database locking (35% likely)
        - Concurrent access
        - Solution: Optimize transaction scope
     
     3. Cache invalidation issue (25% likely)
        - Stale data
        - Solution: Fix cache strategy
     
     I need more information:
     
     Questions:
     - Does this happen with specific data?
     - What's the network latency to external API?
     - How often are cache entries invalidated?
     
     Or would you like me to:
     [1] Investigate option 1 first
     [2] Add logging to gather more data
     [3] Try each hypothesis systematically
```

---

## 📊 Debug Session Summary

After each session, get a summary:

```
📊 DEBUG SESSION SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Session ID: DBG-2025-1030-001
Duration: 18 minutes
Status: ✅ RESOLVED

Bug: NullReferenceException in order processing
Severity: HIGH
Impact: Order creation blocked for all users

Timeline:
├─ 00:00 - Problem assessment started
├─ 02:30 - Bug reproduced
├─ 05:00 - Root cause identified
├─ 08:00 - Fix implemented
├─ 12:00 - Tests passing
└─ 18:00 - Quality assurance complete

Changes Made:
├─ Services/OrderService.cs (modified)
├─ Services/InvoiceService.cs (modified)
├─ Services/ShipmentService.cs (modified)
└─ Tests/OrderServiceTests.cs (added 2 tests)

Test Results:
├─ Existing tests: 17/17 passing ✓
├─ New tests: 2/2 passing ✓
└─ Edge cases: 4/4 passing ✓

Similar Issues Fixed: 2
Prevention Measures: 3 recommendations
```

---

## 📚 Summary

| What You Want | What to Type |
|---------------|--------------|
| Fix application crash | `@debug App crashes with [error message]` |
| Investigate test failure | `@debug Test failing: [test name]` |
| Performance issue | `@debug Endpoint slow: [details]` |
| Logic error | `@debug Wrong calculation: expected X, got Y` |
| Production bug | `@debug Production error: [logs]` |
| Intermittent issue | `@debug Random failures in [component]` |
| Memory leak | `@debug OutOfMemoryException after [time]` |
| Race condition | `@debug Concurrency issue under load` |
| Quick fix | `@debug --concise Fix [error]` |
| Learning mode | `@debug --explain Help me understand this bug` |

---

**The Debug chatmode is your systematic debugging partner!** 🐛

- **Structured**: 4-phase process ensures thorough investigation
- **Comprehensive**: From reproduction to prevention
- **Educational**: Learn why bugs happen and how to prevent them
- **Thorough**: Finds and fixes similar bugs proactively

Just describe your bug and let the systematic process guide you to resolution! 🚀

