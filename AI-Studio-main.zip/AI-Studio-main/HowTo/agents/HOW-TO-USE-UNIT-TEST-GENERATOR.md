# How to Use Unit Test Generator

Generate comprehensive xUnit unit tests for C#/.NET code with data-driven tests, mocking, and best practices built-in.

## 🎯 Overview

The `unit-test-generator` agent is your **automated testing assistant** that creates high-quality xUnit tests following best practices. It understands your code, generates appropriate test cases, handles mocking, and follows the Arrange-Act-Assert (AAA) pattern.

**Key Features:**
- ✅ Generates xUnit [Fact] and [Theory] tests
- ✅ Implements data-driven tests with multiple scenarios
- ✅ Creates mocks for dependencies (Moq/NSubstitute)
- ✅ Follows AAA (Arrange-Act-Assert) pattern
- ✅ Handles async/await patterns
- ✅ Generates edge cases and error scenarios
- ✅ Creates test fixtures and shared context

---

## 🚀 Quick Start

### Generate Tests for a Class

```
@unit-test-generator

Generate unit tests for src/Services/PaymentService.cs
```

### Generate Tests for Specific Methods

```
@unit-test-generator

Create tests for:
- CalculateTotal() method in OrderService
- Include edge cases: null items, negative prices, discounts
```

### Generate Data-Driven Tests

```
@unit-test-generator

Generate parameterized tests for ValidateEmail() with multiple test cases.
```

---

## 📦 What Gets Generated

### Test Project Structure

```
YourProject.Tests/
├── Services/
│   ├── PaymentServiceTests.cs
│   ├── OrderServiceTests.cs
│   └── UserServiceTests.cs
├── Controllers/
│   └── UserControllerTests.cs
├── Utilities/
│   └── ValidationTests.cs
└── Fixtures/
    └── DatabaseFixture.cs
```

### Test File Example

**Generated: `PaymentServiceTests.cs`**

```csharp
using Xunit;
using Moq;
using FluentAssertions;
using YourProject.Services;
using YourProject.Models;

namespace YourProject.Tests.Services
{
    public class PaymentServiceTests
    {
        private readonly Mock<IPaymentGateway> _mockGateway;
        private readonly Mock<ILogger<PaymentService>> _mockLogger;
        private readonly PaymentService _sut; // System Under Test

        public PaymentServiceTests()
        {
            // Arrange - Setup common dependencies
            _mockGateway = new Mock<IPaymentGateway>();
            _mockLogger = new Mock<ILogger<PaymentService>>();
            _sut = new PaymentService(_mockGateway.Object, _mockLogger.Object);
        }

        [Fact]
        public async Task ProcessPaymentAsync_ValidPayment_ReturnsSuccess()
        {
            // Arrange
            var payment = new Payment 
            { 
                Amount = 100.00m, 
                Currency = "USD",
                CardNumber = "4111111111111111"
            };
            
            _mockGateway
                .Setup(g => g.ChargeAsync(It.IsAny<Payment>()))
                .ReturnsAsync(new PaymentResult { Success = true, TransactionId = "TXN123" });

            // Act
            var result = await _sut.ProcessPaymentAsync(payment);

            // Assert
            result.Should().NotBeNull();
            result.Success.Should().BeTrue();
            result.TransactionId.Should().Be("TXN123");
            _mockGateway.Verify(g => g.ChargeAsync(payment), Times.Once);
        }

        [Theory]
        [InlineData(0)]
        [InlineData(-10)]
        [InlineData(-100.50)]
        public async Task ProcessPaymentAsync_InvalidAmount_ThrowsArgumentException(decimal amount)
        {
            // Arrange
            var payment = new Payment { Amount = amount, Currency = "USD" };

            // Act & Assert
            await Assert.ThrowsAsync<ArgumentException>(
                () => _sut.ProcessPaymentAsync(payment)
            );
        }

        [Theory]
        [MemberData(nameof(GetInvalidCurrencies))]
        public async Task ProcessPaymentAsync_InvalidCurrency_ThrowsArgumentException(string currency)
        {
            // Arrange
            var payment = new Payment { Amount = 100m, Currency = currency };

            // Act & Assert
            await Assert.ThrowsAsync<ArgumentException>(
                () => _sut.ProcessPaymentAsync(payment)
            );
        }

        public static IEnumerable<object[]> GetInvalidCurrencies()
        {
            yield return new object[] { null };
            yield return new object[] { "" };
            yield return new object[] { "INVALID" };
            yield return new object[] { "US" }; // Too short
        }

        [Fact]
        public async Task ProcessPaymentAsync_GatewayTimeout_ThrowsTimeoutException()
        {
            // Arrange
            var payment = new Payment { Amount = 100m, Currency = "USD" };
            
            _mockGateway
                .Setup(g => g.ChargeAsync(It.IsAny<Payment>()))
                .ThrowsAsync(new TimeoutException("Gateway timeout"));

            // Act & Assert
            await Assert.ThrowsAsync<TimeoutException>(
                () => _sut.ProcessPaymentAsync(payment)
            );
            
            _mockLogger.Verify(
                l => l.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.IsAny<It.IsAnyType>(),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()
                ),
                Times.Once
            );
        }
    }
}
```

---

## 📋 Test Patterns Generated

### 1. Simple Facts

**When:** Testing a single scenario.

```csharp
[Fact]
public void CalculateTotal_SingleItem_ReturnsItemPrice()
{
    // Arrange
    var calculator = new OrderCalculator();
    var order = new Order { Items = new[] { new Item { Price = 50m } } };

    // Act
    var total = calculator.CalculateTotal(order);

    // Assert
    Assert.Equal(50m, total);
}
```

---

### 2. Theory with InlineData

**When:** Testing multiple simple input/output combinations.

```csharp
[Theory]
[InlineData(100, 10, 90)]
[InlineData(50, 5, 45)]
[InlineData(200, 20, 180)]
public void ApplyDiscount_ValidInputs_ReturnsDiscountedPrice(
    decimal price, 
    decimal discount, 
    decimal expected)
{
    // Arrange
    var calculator = new PriceCalculator();

    // Act
    var result = calculator.ApplyDiscount(price, discount);

    // Assert
    Assert.Equal(expected, result);
}
```

---

### 3. Theory with MemberData

**When:** Testing complex data sets or objects.

```csharp
[Theory]
[MemberData(nameof(GetOrderTestData))]
public void CalculateTotal_VariousOrders_ReturnsCorrectTotal(
    Order order, 
    decimal expectedTotal)
{
    // Arrange
    var calculator = new OrderCalculator();

    // Act
    var total = calculator.CalculateTotal(order);

    // Assert
    Assert.Equal(expectedTotal, total);
}

public static IEnumerable<object[]> GetOrderTestData()
{
    yield return new object[] 
    { 
        new Order { Items = new[] { new Item { Price = 50m } } }, 
        50m 
    };
    
    yield return new object[] 
    { 
        new Order 
        { 
            Items = new[] 
            { 
                new Item { Price = 50m }, 
                new Item { Price = 30m } 
            } 
        }, 
        80m 
    };
    
    yield return new object[] 
    { 
        new Order { Items = Array.Empty<Item>() }, 
        0m 
    };
}
```

---

### 4. Async Tests

**When:** Testing async methods.

```csharp
[Fact]
public async Task GetUserAsync_ValidId_ReturnsUser()
{
    // Arrange
    var mockRepo = new Mock<IUserRepository>();
    mockRepo
        .Setup(r => r.GetByIdAsync(1))
        .ReturnsAsync(new User { Id = 1, Name = "John" });
    
    var service = new UserService(mockRepo.Object);

    // Act
    var user = await service.GetUserAsync(1);

    // Assert
    Assert.NotNull(user);
    Assert.Equal("John", user.Name);
}
```

---

### 5. Exception Tests

**When:** Testing error handling.

```csharp
[Fact]
public void Divide_ByZero_ThrowsDivideByZeroException()
{
    // Arrange
    var calculator = new Calculator();

    // Act & Assert
    Assert.Throws<DivideByZeroException>(() => calculator.Divide(10, 0));
}

[Fact]
public async Task GetUserAsync_InvalidId_ThrowsArgumentException()
{
    // Arrange
    var service = new UserService();

    // Act & Assert
    var exception = await Assert.ThrowsAsync<ArgumentException>(
        () => service.GetUserAsync(-1)
    );
    
    Assert.Equal("userId", exception.ParamName);
}
```

---

### 6. Mocking Dependencies

**When:** Testing classes with dependencies.

```csharp
[Fact]
public async Task SendEmailAsync_ValidEmail_CallsEmailService()
{
    // Arrange
    var mockEmailService = new Mock<IEmailService>();
    var notifier = new UserNotifier(mockEmailService.Object);
    
    var email = new Email 
    { 
        To = "user@example.com", 
        Subject = "Welcome" 
    };

    // Act
    await notifier.SendEmailAsync(email);

    // Assert
    mockEmailService.Verify(
        s => s.SendAsync(It.Is<Email>(e => e.To == "user@example.com")),
        Times.Once
    );
}
```

---

### 7. Test Fixtures (Shared Context)

**When:** Multiple tests need the same setup.

```csharp
public class DatabaseFixture : IDisposable
{
    public ApplicationDbContext Context { get; private set; }

    public DatabaseFixture()
    {
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase("TestDatabase")
            .Options;
        
        Context = new ApplicationDbContext(options);
        
        // Seed test data
        Context.Users.Add(new User { Id = 1, Name = "Test User" });
        Context.SaveChanges();
    }

    public void Dispose()
    {
        Context.Dispose();
    }
}

public class UserServiceTests : IClassFixture<DatabaseFixture>
{
    private readonly DatabaseFixture _fixture;

    public UserServiceTests(DatabaseFixture fixture)
    {
        _fixture = fixture;
    }

    [Fact]
    public async Task GetUserAsync_ExistingUser_ReturnsUser()
    {
        // Arrange
        var service = new UserService(_fixture.Context);

        // Act
        var user = await service.GetUserAsync(1);

        // Assert
        Assert.NotNull(user);
        Assert.Equal("Test User", user.Name);
    }
}
```

---

## 🎬 Complete Example Session

### Scenario: Generate Tests for OrderService

```
You: @unit-test-generator

     Generate comprehensive unit tests for src/Services/OrderService.cs
     
     The class has these methods:
     - CalculateTotal(Order order)
     - ApplyDiscount(Order order, Coupon coupon)
     - ValidateOrder(Order order)
     
     Include edge cases and error scenarios.

Agent: 📋 Analyzing OrderService.cs...
      
      ✅ Found class: OrderService
      ✅ Identified dependencies: IDiscountService, ILogger<OrderService>
      ✅ Detected methods: 3
      
      Planning test scenarios:
      
      CalculateTotal:
      - Happy path: Single item
      - Happy path: Multiple items
      - Edge case: Empty order
      - Edge case: Null items
      
      ApplyDiscount:
      - Happy path: Valid coupon
      - Happy path: Percentage discount
      - Happy path: Fixed amount discount
      - Edge case: Expired coupon
      - Edge case: Invalid coupon
      - Error: Null coupon
      
      ValidateOrder:
      - Happy path: Valid order
      - Error: Null order
      - Error: Empty items
      - Error: Negative prices
      - Error: Missing customer info
      
      Generating OrderServiceTests.cs...
      
      ✅ Created YourProject.Tests/Services/OrderServiceTests.cs
      
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      Generated Tests Summary
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      
      Total Tests: 15
      - Facts: 8
      - Theories: 7
      - Async tests: 0
      - Mock setups: 5
      
      Test Categories:
      ✅ Happy paths: 6 tests
      ✅ Edge cases: 5 tests
      ✅ Error scenarios: 4 tests
      
      Coverage Estimate: 95% (based on identified code paths)
      
      Next Steps:
      1. Review generated tests
      2. Run: dotnet test
      3. Add any domain-specific scenarios I might have missed
```

---

**Generated File: OrderServiceTests.cs**

```csharp
using Xunit;
using Moq;
using FluentAssertions;
using YourProject.Services;
using YourProject.Models;

namespace YourProject.Tests.Services
{
    public class OrderServiceTests
    {
        private readonly Mock<IDiscountService> _mockDiscountService;
        private readonly Mock<ILogger<OrderService>> _mockLogger;
        private readonly OrderService _sut;

        public OrderServiceTests()
        {
            _mockDiscountService = new Mock<IDiscountService>();
            _mockLogger = new Mock<ILogger<OrderService>>();
            _sut = new OrderService(_mockDiscountService.Object, _mockLogger.Object);
        }

        #region CalculateTotal Tests

        [Fact]
        public void CalculateTotal_SingleItem_ReturnsItemPrice()
        {
            // Arrange
            var order = new Order
            {
                Items = new List<OrderItem>
                {
                    new OrderItem { ProductId = 1, Quantity = 1, UnitPrice = 50m }
                }
            };

            // Act
            var total = _sut.CalculateTotal(order);

            // Assert
            total.Should().Be(50m);
        }

        [Fact]
        public void CalculateTotal_MultipleItems_ReturnsSumOfPrices()
        {
            // Arrange
            var order = new Order
            {
                Items = new List<OrderItem>
                {
                    new OrderItem { ProductId = 1, Quantity = 2, UnitPrice = 50m },
                    new OrderItem { ProductId = 2, Quantity = 1, UnitPrice = 30m }
                }
            };

            // Act
            var total = _sut.CalculateTotal(order);

            // Assert
            total.Should().Be(130m); // (2 * 50) + (1 * 30)
        }

        [Fact]
        public void CalculateTotal_EmptyOrder_ReturnsZero()
        {
            // Arrange
            var order = new Order { Items = new List<OrderItem>() };

            // Act
            var total = _sut.CalculateTotal(order);

            // Assert
            total.Should().Be(0m);
        }

        [Fact]
        public void CalculateTotal_NullItems_ThrowsArgumentNullException()
        {
            // Arrange
            var order = new Order { Items = null };

            // Act
            Action act = () => _sut.CalculateTotal(order);

            // Assert
            act.Should().Throw<ArgumentNullException>()
                .WithParameterName("Items");
        }

        #endregion

        #region ApplyDiscount Tests

        [Fact]
        public void ApplyDiscount_ValidPercentageCoupon_AppliesDiscount()
        {
            // Arrange
            var order = new Order
            {
                Items = new List<OrderItem>
                {
                    new OrderItem { Quantity = 1, UnitPrice = 100m }
                },
                Total = 100m
            };
            
            var coupon = new Coupon
            {
                Code = "SAVE10",
                DiscountType = DiscountType.Percentage,
                DiscountValue = 10m,
                ExpirationDate = DateTime.UtcNow.AddDays(1)
            };

            _mockDiscountService
                .Setup(s => s.CalculateDiscount(100m, coupon))
                .Returns(10m);

            // Act
            var discountedOrder = _sut.ApplyDiscount(order, coupon);

            // Assert
            discountedOrder.Total.Should().Be(90m);
            discountedOrder.AppliedCoupon.Should().Be("SAVE10");
        }

        [Fact]
        public void ApplyDiscount_ValidFixedAmountCoupon_AppliesDiscount()
        {
            // Arrange
            var order = new Order
            {
                Items = new List<OrderItem>
                {
                    new OrderItem { Quantity = 1, UnitPrice = 100m }
                },
                Total = 100m
            };
            
            var coupon = new Coupon
            {
                Code = "SAVE20",
                DiscountType = DiscountType.FixedAmount,
                DiscountValue = 20m,
                ExpirationDate = DateTime.UtcNow.AddDays(1)
            };

            _mockDiscountService
                .Setup(s => s.CalculateDiscount(100m, coupon))
                .Returns(20m);

            // Act
            var discountedOrder = _sut.ApplyDiscount(order, coupon);

            // Assert
            discountedOrder.Total.Should().Be(80m);
        }

        [Fact]
        public void ApplyDiscount_ExpiredCoupon_ThrowsInvalidOperationException()
        {
            // Arrange
            var order = new Order { Total = 100m };
            var coupon = new Coupon
            {
                Code = "EXPIRED",
                ExpirationDate = DateTime.UtcNow.AddDays(-1)
            };

            // Act
            Action act = () => _sut.ApplyDiscount(order, coupon);

            // Assert
            act.Should().Throw<InvalidOperationException>()
                .WithMessage("*expired*");
        }

        [Theory]
        [InlineData(null)]
        public void ApplyDiscount_NullCoupon_ThrowsArgumentNullException(Coupon coupon)
        {
            // Arrange
            var order = new Order { Total = 100m };

            // Act
            Action act = () => _sut.ApplyDiscount(order, coupon);

            // Assert
            act.Should().Throw<ArgumentNullException>()
                .WithParameterName("coupon");
        }

        #endregion

        #region ValidateOrder Tests

        [Fact]
        public void ValidateOrder_ValidOrder_ReturnsTrue()
        {
            // Arrange
            var order = new Order
            {
                CustomerId = 1,
                Items = new List<OrderItem>
                {
                    new OrderItem { ProductId = 1, Quantity = 1, UnitPrice = 50m }
                },
                ShippingAddress = new Address { Street = "123 Main St" }
            };

            // Act
            var isValid = _sut.ValidateOrder(order);

            // Assert
            isValid.Should().BeTrue();
        }

        [Fact]
        public void ValidateOrder_NullOrder_ThrowsArgumentNullException()
        {
            // Act
            Action act = () => _sut.ValidateOrder(null);

            // Assert
            act.Should().Throw<ArgumentNullException>()
                .WithParameterName("order");
        }

        [Fact]
        public void ValidateOrder_EmptyItems_ReturnsFalse()
        {
            // Arrange
            var order = new Order
            {
                CustomerId = 1,
                Items = new List<OrderItem>()
            };

            // Act
            var isValid = _sut.ValidateOrder(order);

            // Assert
            isValid.Should().BeFalse();
        }

        [Theory]
        [InlineData(-10)]
        [InlineData(-1)]
        [InlineData(0)]
        public void ValidateOrder_InvalidPrice_ReturnsFalse(decimal price)
        {
            // Arrange
            var order = new Order
            {
                CustomerId = 1,
                Items = new List<OrderItem>
                {
                    new OrderItem { ProductId = 1, Quantity = 1, UnitPrice = price }
                }
            };

            // Act
            var isValid = _sut.ValidateOrder(order);

            // Assert
            isValid.Should().BeFalse();
        }

        [Fact]
        public void ValidateOrder_MissingCustomerId_ReturnsFalse()
        {
            // Arrange
            var order = new Order
            {
                CustomerId = 0,
                Items = new List<OrderItem>
                {
                    new OrderItem { ProductId = 1, Quantity = 1, UnitPrice = 50m }
                }
            };

            // Act
            var isValid = _sut.ValidateOrder(order);

            // Assert
            isValid.Should().BeFalse();
        }

        #endregion
    }
}
```

---

## 💡 Use Cases

### Use Case 1: TDD (Test-Driven Development)

**Scenario:** Write tests before implementing feature.

**Workflow:**
```
1. @unit-test-generator Create tests for UserService.Authenticate()
2. Review generated test scenarios
3. Implement UserService.Authenticate() to pass tests
4. Run: dotnet test
```

**Benefit:** Tests define expected behavior before writing code.

---

### Use Case 2: Legacy Code Testing

**Scenario:** Add tests to existing code with no coverage.

**Workflow:**
```
@unit-test-generator

Generate comprehensive tests for legacy PaymentProcessor class.
Focus on edge cases and error handling - this code has bugs.
```

**Benefit:** Catch existing bugs and prevent regressions.

---

### Use Case 3: Increase Coverage

**Scenario:** Current coverage is 45%, goal is 80%.

**Workflow:**
```
# Generate coverage report
dotnet test --collect:"XPlat Code Coverage"

# Identify untested classes
@unit-test-generator

Generate tests for untested classes:
- Services/EmailService.cs
- Utilities/ValidationHelper.cs
- Repositories/OrderRepository.cs
```

**Benefit:** Systematic coverage improvement.

---

## 🔧 Advanced Features

### Custom Test Data Builders

```csharp
public class OrderBuilder
{
    private readonly Order _order = new Order();

    public OrderBuilder WithCustomer(int customerId)
    {
        _order.CustomerId = customerId;
        return this;
    }

    public OrderBuilder WithItem(int productId, int quantity, decimal unitPrice)
    {
        _order.Items.Add(new OrderItem
        {
            ProductId = productId,
            Quantity = quantity,
            UnitPrice = unitPrice
        });
        return this;
    }

    public Order Build() => _order;
}

// Usage in tests
[Fact]
public void CalculateTotal_ComplexOrder_ReturnsCorrectTotal()
{
    // Arrange
    var order = new OrderBuilder()
        .WithCustomer(1)
        .WithItem(productId: 1, quantity: 2, unitPrice: 50m)
        .WithItem(productId: 2, quantity: 1, unitPrice: 30m)
        .Build();

    // Act
    var total = _sut.CalculateTotal(order);

    // Assert
    total.Should().Be(130m);
}
```

---

### Integration Tests with Testcontainers

```csharp
public class UserRepositoryIntegrationTests : IAsyncLifetime
{
    private readonly PostgreSqlContainer _dbContainer;
    private ApplicationDbContext _context;

    public UserRepositoryIntegrationTests()
    {
        _dbContainer = new PostgreSqlBuilder()
            .WithDatabase("testdb")
            .WithUsername("test")
            .WithPassword("test")
            .Build();
    }

    public async Task InitializeAsync()
    {
        await _dbContainer.StartAsync();
        
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseNpgsql(_dbContainer.GetConnectionString())
            .Options;
        
        _context = new ApplicationDbContext(options);
        await _context.Database.EnsureCreatedAsync();
    }

    public async Task DisposeAsync()
    {
        await _context.DisposeAsync();
        await _dbContainer.StopAsync();
    }

    [Fact]
    public async Task SaveUser_ValidUser_PersistsToDatabase()
    {
        // Arrange
        var repository = new UserRepository(_context);
        var user = new User { Name = "John Doe", Email = "john@example.com" };

        // Act
        await repository.SaveAsync(user);
        var retrieved = await repository.GetByIdAsync(user.Id);

        // Assert
        retrieved.Should().NotBeNull();
        retrieved.Name.Should().Be("John Doe");
    }
}
```

---

## ✅ Best Practices

### 1. One Assert Per Test (When Possible)

```csharp
// Good
[Fact]
public void GetUser_ValidId_ReturnsUser()
{
    var user = _service.GetUser(1);
    Assert.NotNull(user);
}

[Fact]
public void GetUser_ValidId_ReturnsCorrectName()
{
    var user = _service.GetUser(1);
    Assert.Equal("John", user.Name);
}

// Acceptable when testing related properties
[Fact]
public void CreateUser_ValidData_ReturnsUserWithAllProperties()
{
    var user = _service.CreateUser("John", "john@example.com");
    
    Assert.NotNull(user);
    Assert.Equal("John", user.Name);
    Assert.Equal("john@example.com", user.Email);
    Assert.NotEqual(0, user.Id);
}
```

---

### 2. Use Descriptive Test Names

```csharp
// Good: MethodName_Scenario_ExpectedBehavior
[Fact]
public void CalculateTotal_EmptyOrder_ReturnsZero() { }

// Bad: Not descriptive
[Fact]
public void Test1() { }

[Fact]
public void TestTotal() { }
```

---

### 3. Test Behavior, Not Implementation

```csharp
// Good: Tests observable behavior
[Fact]
public void SendEmail_ValidEmail_EmailIsSent()
{
    _service.SendEmail("user@example.com", "Subject", "Body");
    
    _mockEmailService.Verify(
        s => s.Send(It.IsAny<Email>()),
        Times.Once
    );
}

// Bad: Tests internal implementation
[Fact]
public void SendEmail_CallsValidateEmailMethod()
{
    // Don't test private method calls
}
```

---

### 4. Keep Tests Independent

```csharp
// Good: Each test has own setup
public class UserServiceTests
{
    [Fact]
    public void Test1()
    {
        var user = new User { Id = 1 };
        // test using user
    }

    [Fact]
    public void Test2()
    {
        var user = new User { Id = 2 };
        // test using different user
    }
}

// Bad: Tests share state
public class UserServiceTests
{
    private User _sharedUser = new User { Id = 1 };

    [Fact]
    public void Test1()
    {
        _sharedUser.Name = "John"; // Modifies shared state!
    }

    [Fact]
    public void Test2()
    {
        // Depends on Test1's modifications
    }
}
```

---

## 🐛 Troubleshooting

### Problem: "Method is too complex to test"

**Cause:** Method has too many responsibilities.

**Solution:**
```
@unit-test-generator

This method is complex. Suggest refactoring:
- Extract smaller methods
- Identify responsibilities
- Propose testable design
```

Agent will suggest refactoring before generating tests.

---

### Problem: Tests fail with "NullReferenceException"

**Cause:** Missing mock setup.

**Solution:**
```csharp
// Ensure all dependencies are mocked
_mockRepository
    .Setup(r => r.GetAsync(It.IsAny<int>()))
    .ReturnsAsync(new User()); // Don't return null by default
```

---

### Problem: Async tests hang

**Cause:** Deadlock or missing await.

**Solution:**
```csharp
// Good
[Fact]
public async Task GetUserAsync_ValidId_ReturnsUser()
{
    var user = await _service.GetUserAsync(1); // await!
    Assert.NotNull(user);
}

// Bad
[Fact]
public void GetUserAsync_ValidId_ReturnsUser()
{
    var user = _service.GetUserAsync(1).Result; // Deadlock risk!
}
```

---

### Problem: "Test passes locally but fails in CI"

**Cause:** Environment differences (timezone, culture, etc.).

**Solution:**
```csharp
// Use fixed dates/times in tests
var fixedDate = new DateTime(2026, 1, 29, 12, 0, 0, DateTimeKind.Utc);

// Mock time-dependent operations
_mockTimeProvider
    .Setup(t => t.UtcNow)
    .Returns(fixedDate);
```

---

## ✅ Success Checklist

After generating tests:

- [ ] All tests pass: `dotnet test`
- [ ] Test names are descriptive (MethodName_Scenario_ExpectedBehavior)
- [ ] AAA pattern followed (Arrange-Act-Assert)
- [ ] No hard-coded values (use constants or test data)
- [ ] Mocks are set up correctly
- [ ] Edge cases covered (null, empty, negative)
- [ ] Error scenarios tested (exceptions)
- [ ] Async methods tested with async tests
- [ ] No test interdependencies
- [ ] Code coverage improved (check with `dotnet test --collect:"XPlat Code Coverage"`)

---

## 🎯 Quick Reference

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Unit Test Generator - Command Reference
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Generate Tests:         @unit-test-generator Generate tests for <class>
Specific Method:        @unit-test-generator Test <MethodName> in <class>
Data-Driven:            @unit-test-generator Create Theory tests for <method>
With Coverage:          @unit-test-generator Generate tests to reach 80% coverage

Run Tests:              dotnet test
With Coverage:          dotnet test --collect:"XPlat Code Coverage"
Watch Mode:             dotnet watch test

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Test Patterns: [Fact] | [Theory] | [InlineData] | [MemberData]
Assertions: Assert.Equal | Assert.Throws | Assert.NotNull
Mocking: Mock<T>, Setup(), Verify(), Times.Once
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Generate your first tests:**
```
@unit-test-generator Generate tests for <your-class-name>
```

---

## 📚 Related Resources

- [xUnit Documentation](https://xunit.net/)
- [Moq Documentation](https://github.com/moq/moq4)
- [FluentAssertions](https://fluentassertions.com/)
- [Testcontainers](https://dotnet.testcontainers.org/)
- [.NET Testing Best Practices](https://learn.microsoft.com/en-us/dotnet/core/testing/unit-testing-best-practices)
