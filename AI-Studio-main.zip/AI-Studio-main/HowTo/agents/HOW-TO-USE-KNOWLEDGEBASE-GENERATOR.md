# How to Use Repository Documentation Generator

Generate comprehensive, professional documentation for any codebase including architecture diagrams, component catalogs, and developer onboarding guides.

## 🎯 Overview

The `knowledgebase-orchestrator` agent is your **automated technical documentation system** that analyzes your repository and generates complete documentation following best practices. Perfect for:

- 📚 Documenting undocumented legacy codebases
- 🆕 Onboarding new developers quickly
- 📊 Creating architecture diagrams for stakeholders
- 🔍 Understanding complex dependency relationships
- 📖 Maintaining up-to-date technical documentation

---

## 🚀 Quick Start

### Interactive Mode (VS Code)

```
@knowledgebase-orchestrator

Generate complete documentation for this repository.
```

### Mission Control Mode (Organization-Level)

1. Open **GitHub Copilot Mission Control**
2. Select one or more repositories
3. Select the **`knowledgebase-orchestrator`** agent
4. Prompt:
   ```
   Generate comprehensive repository documentation with architecture diagrams.
   Output to docs/knowledgebase/
   ```

---

## 📦 What Gets Generated

The agent creates a complete documentation package under `docs/knowledgebase/`:

```
docs/knowledgebase/
├── README.md                   # Repository overview, quick start
├── architecture.md             # System design, Mermaid diagrams
├── components/
│   ├── index.md                # Service catalog with descriptions
│   ├── auth-service.md         # Individual component docs
│   ├── payment-service.md
│   └── user-management.md
├── getting-started.md          # Developer onboarding guide
├── dependencies.md             # Dependency graph explanation
├── tech-stack.md               # Technology inventory
└── database/                   # Database architecture (if applicable)
    ├── schema-overview.md
    └── stored-procedures.md
```

---

## 📋 Documentation Contents

### 1. README.md - Repository Overview

**What's Included:**
- Project description and purpose
- Quick start instructions (clone, build, run)
- Key features and capabilities
- Team contacts and support channels

**Example Output:**
```markdown
# Payment Processing System

Enterprise payment gateway for processing credit card transactions.

## Quick Start

```bash
git clone https://github.com/org/payment-system.git
cd payment-system
dotnet restore
dotnet build
dotnet run --project src/PaymentGateway
```

## Key Features
- Multi-currency support (USD, EUR, GBP)
- PCI-DSS compliant payment processing
- Real-time fraud detection
- Automated reconciliation
```

### 2. architecture.md - System Design

**What's Included:**
- High-level architecture overview
- **C4 Context Diagram** (system and external actors)
- **C4 Container Diagram** (applications and data stores)
- **Component Diagram** (internal structure)
- **Dependency Graph** (project relationships)
- Integration points and external services
- Data flow diagrams

**Example Mermaid Diagrams:**

**System Context:**
```mermaid
C4Context
  title System Context - Payment Gateway
  
  Person(customer, "Customer", "End user making payments")
  System(gateway, "Payment Gateway", "Processes card transactions")
  System_Ext(bank, "Bank API", "Card authorization")
  System_Ext(fraud, "Fraud Detection", "Risk analysis")
  
  Rel(customer, gateway, "Submits payment")
  Rel(gateway, bank, "Authorizes card")
  Rel(gateway, fraud, "Validates transaction")
```

**Dependency Graph:**
```mermaid
graph TD
  A[PaymentGateway.API] --> B[PaymentGateway.Core]
  A --> C[PaymentGateway.Data]
  C --> B
  A --> D[PaymentGateway.Integration]
  D --> B
```

### 3. components/ - Service Catalog

**What's Included (for each component):**
- **Purpose**: What the component does
- **Responsibilities**: Key functions and features
- **Dependencies**: What it depends on (with context)
- **Dependents**: What depends on it (impact analysis)
- **Technology Stack**: Languages, frameworks, libraries
- **API Surface**: Public interfaces, contracts
- **Configuration**: Environment variables, settings
- **Testing**: Test coverage, how to run tests

**Example Component Doc:**

```markdown
# PaymentGateway.Core

## Purpose
Core business logic for payment processing, validation, and workflow orchestration.

## Responsibilities
- Payment validation and formatting
- Card encryption/decryption
- Transaction state management
- Retry and idempotency logic
- Business rule enforcement

## Dependencies
- **PaymentGateway.Contracts**: Shared DTOs and interfaces
- **Microsoft.Extensions.Logging**: Application logging
- **FluentValidation**: Input validation

## Dependents
- **PaymentGateway.API**: REST API layer
- **PaymentGateway.Worker**: Background job processing
- **PaymentGateway.Integration**: Third-party integrations

## API Surface

### Public Interfaces
- `IPaymentProcessor`: Main payment processing contract
- `ICardEncryption`: PCI-compliant card encryption
- `ITransactionValidator`: Business rule validation

### Key Methods
- `ProcessPaymentAsync(PaymentRequest)`: Main payment flow
- `ValidateCardAsync(CardDetails)`: Card validation
- `EncryptSensitiveDataAsync(string)`: PCI encryption
```

### 4. getting-started.md - Developer Onboarding

**What's Included:**
- Prerequisites (SDKs, tools, accounts)
- Step-by-step setup instructions
- How to run the application locally
- How to run tests
- Development workflow (branches, PRs)
- Common tasks (add feature, fix bug, run migrations)
- Troubleshooting common issues

**Example:**
```markdown
# Developer Getting Started Guide

## Prerequisites

- .NET 8+ SDK
- SQL Server 2019+
- Redis (for caching)
- Visual Studio 2022 or VS Code
- Git

## Setup Steps

### 1. Clone Repository
```bash
git clone https://github.com/org/payment-gateway.git
cd payment-gateway
```

### 2. Configure Local Environment
Copy `.env.example` to `.env` and configure:
```
DATABASE_CONNECTION=Server=localhost;Database=PaymentGateway;...
REDIS_CONNECTION=localhost:6379
BANK_API_KEY=your-test-key
```

### 3. Initialize Database
```bash
dotnet ef database update --project src/PaymentGateway.Data
```

### 4. Run Application
```bash
dotnet run --project src/PaymentGateway.API
```

Navigate to: https://localhost:5001/swagger

## Common Tasks

### Add New Payment Provider
1. Create provider implementation in `src/Integration/Providers/`
2. Implement `IPaymentProvider` interface
3. Register in `PaymentProviderFactory`
4. Add integration tests
5. Update documentation
```

### 5. dependencies.md - Dependency Analysis

**What's Included:**
- Complete dependency graph explanation
- Processing order (leaf-to-root)
- Impact analysis (what breaks if X changes)
- Circular dependency warnings
- External package inventory

**Example:**
```markdown
# Dependency Architecture

## Processing Order (Leaf to Root)

This is the recommended order for migration, refactoring, or analysis:

1. **PaymentGateway.Contracts** (no dependencies)
   - Shared DTOs, interfaces, enums
   - Used by: All other projects

2. **PaymentGateway.Core** (depends on: Contracts)
   - Business logic
   - Used by: API, Worker, Integration

3. **PaymentGateway.Data** (depends on: Contracts, Core)
   - Database access
   - Used by: API, Worker

4. **PaymentGateway.Integration** (depends on: Contracts, Core)
   - External service integrations
   - Used by: API, Worker

5. **PaymentGateway.API** (depends on: All above)
   - REST API
   - Top-level entry point

## Impact Analysis

**If PaymentGateway.Core changes:**
- 🔴 **HIGH IMPACT**: API, Worker, Integration all affected
- ⚠️ Breaking changes require coordination across 3 projects
- ✅ Changes to Contracts have even wider impact

**If PaymentGateway.Integration changes:**
- 🟡 **MEDIUM IMPACT**: API and Worker affected
- ✅ Core and Data remain unaffected
```

### 6. tech-stack.md - Technology Inventory

**What's Included:**
- Languages and versions
- Frameworks and major libraries
- Build tools and CI/CD
- Infrastructure and deployment
- Development tools
- Testing frameworks

**Example:**
```markdown
# Technology Stack

## Languages
- **C# 12+** (.NET 8.0+)
- **TypeScript 5.x** (Admin UI)
- **SQL** (T-SQL for SQL Server)

## Backend Frameworks
- **ASP.NET Core 8** (Web API)
- **Entity Framework Core 8** (ORM)
- **MassTransit** (Message bus)
- **Serilog** (Structured logging)
- **FluentValidation** (Input validation)
- **Polly** (Resilience and retry)

## Frontend (Admin UI)
- **React 18**
- **TypeScript**
- **Vite** (Build tool)
- **React Query** (Data fetching)

## Database
- **SQL Server 2019**
- **Redis** (Caching and sessions)

## Testing
- **xUnit** (Unit tests)
- **Moq** (Mocking)
- **Testcontainers** (Integration tests)
- **k6** (Load testing)

## CI/CD
- **GitHub Actions**
- **Docker**
- **Azure Container Registry**

## Deployment
- **Azure Kubernetes Service (AKS)**
- **Terraform** (Infrastructure as Code)
```

### 7. database/ - Database Architecture (Optional)

**Generated if stored procedures detected:**

- Schema overview (tables, relationships)
- Stored procedure catalog with business logic
- Database integration points (how app calls DB)
- Migration strategy recommendations

---

## 🎬 Complete Example Session

### Scenario: Document Legacy .NET Codebase

```
You: @knowledgebase-orchestrator

     We have an undocumented legacy payment system that new developers struggle 
     with. Generate complete documentation.

Agent: Starting repository documentation generation...

Phase 1: Analyzing Dependencies
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ Found .NET solution: PaymentGateway.sln
✓ Detected 6 projects
✓ Built dependency graph
✓ Determined processing order

Processing Order (leaf → root):
1. PaymentGateway.Contracts
2. PaymentGateway.Core
3. PaymentGateway.Data
4. PaymentGateway.Integration
5. PaymentGateway.Worker
6. PaymentGateway.API

Phase 2: Analyzing Components
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ [1/6] PaymentGateway.Contracts: Shared DTOs and interfaces
✓ [2/6] PaymentGateway.Core: Business logic, 23 classes
✓ [3/6] PaymentGateway.Data: EF Core, SQL Server, 15 entities
✓ [4/6] PaymentGateway.Integration: 4 payment providers
✓ [5/6] PaymentGateway.Worker: Background processing
✓ [6/6] PaymentGateway.API: REST API, 12 controllers

Phase 3: Database Analysis (Detected SQL Server)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ Found 8 stored procedures
✓ Identified business logic: fraud scoring, reconciliation
✓ Mapped SP → application calls

Phase 4: Generating Documentation
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ Created README.md with quick start
✓ Created architecture.md with 4 diagrams
✓ Created 6 component docs
✓ Created getting-started.md
✓ Created dependencies.md with impact analysis
✓ Created tech-stack.md
✓ Created database/schema-overview.md
✓ Created database/stored-procedures.md

Phase 5: Verification
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ All required deliverables present
✓ Internal links validated
✓ Diagrams match actual dependencies
✓ No broken cross-references

✅ Documentation Generated Successfully!

📂 Output: docs/knowledgebase/
   - 8 markdown files
   - 4 Mermaid diagrams
   - 6 component documentation files

Next steps:
1. Review docs/knowledgebase/README.md
2. Share getting-started.md with new developers
3. Use architecture.md for stakeholder presentations
```

---

## 💡 Use Cases

### Use Case 1: Onboard New Developer

**Scenario**: New engineer joins team, needs to understand complex microservices system.

**Solution**:
```
@knowledgebase-orchestrator

Generate onboarding documentation for new developers.
Include architecture diagrams and step-by-step setup guide.
```

**Result**: Complete `getting-started.md` with prerequisites, setup steps, common tasks, and troubleshooting.

---

### Use Case 2: Architecture Review

**Scenario**: CTO wants architecture overview for audit/compliance review.

**Solution**:
```
@knowledgebase-orchestrator

Generate architecture documentation with system context diagrams.
Focus on external integrations and data flows.
```

**Result**: `architecture.md` with C4 diagrams showing system boundaries, external dependencies, and data flows.

---

### Use Case 3: Legacy Code Understanding

**Scenario**: Team inherited undocumented codebase with SQL Server stored procedures.

**Solution**:
```
@knowledgebase-orchestrator

Document this legacy system including database architecture.
Focus on stored procedure business logic and how it's called from code.
```

**Result**: Complete documentation including `database/stored-procedures.md` mapping business logic to application calls.

---

### Use Case 4: Dependency Impact Analysis

**Scenario**: Planning to refactor Core library, need to understand impact.

**Solution**:
```
@knowledgebase-orchestrator

Generate dependency analysis with impact assessment.
Show what breaks if Core library changes.
```

**Result**: `dependencies.md` with impact analysis showing all dependents and recommended refactoring order.

---

## 🔧 Advanced Options

### Customize Output Location

```
@knowledgebase-orchestrator

Generate documentation to docs/technical/ instead of docs/knowledgebase/
```

### Focus on Specific Components

```
@knowledgebase-orchestrator

Document only the PaymentGateway.Integration project and its dependencies.
```

### Include Database Analysis

```
@knowledgebase-orchestrator

Include detailed database documentation.
Focus on stored procedure business logic extraction opportunities.
```

### Specify Repository Type

```
@knowledgebase-orchestrator

Document this Python/Django repository.
```

The agent auto-detects: .NET, Python, Java, Node.js, Go, Rust, and more.

---

## ✅ Best Practices

### 1. Start with Clean Repository

- Commit or stash uncommitted changes
- Ensure solution/project files are up to date
- Run `dotnet restore` or equivalent first

### 2. Review Generated Documentation

- Check component descriptions for accuracy
- Verify diagram relationships match reality
- Update business context if agent missed nuances

### 3. Keep Documentation Current

Re-run after major changes:
- New services/projects added
- Architecture refactoring
- Major dependency updates
- Database schema changes

### 4. Integrate with CI/CD

**Option 1: Manual Updates**
```bash
# Run locally when needed
@knowledgebase-orchestrator Generate updated documentation
```

**Option 2: Mission Control Scheduled**
Use GitHub Mission Control to run quarterly documentation updates across all repos.

---

## 🐛 Troubleshooting

### Problem: "Could not detect repository type"

**Cause**: Missing standard project files (.sln, package.json, etc.)

**Solution**: Ensure project structure has recognizable files:
- .NET: `.sln` or `.csproj`
- Node.js: `package.json`
- Python: `requirements.txt` or `pyproject.toml`
- Java: `pom.xml` or `build.gradle`

---

### Problem: Diagrams don't render

**Cause**: Markdown viewer doesn't support Mermaid.

**Solution**: Use GitHub, VS Code with Markdown Preview, or render with Mermaid CLI:
```bash
mmdc -i architecture.md -o architecture.pdf
```

---

### Problem: Missing component documentation

**Cause**: Project not detected in dependency analysis.

**Solution**: Check project is referenced in solution file or has proper structure. Re-run:
```
@knowledgebase-orchestrator

Force full scan including orphaned projects.
```

---

### Problem: Database documentation not generated

**Cause**: No stored procedures detected.

**Solution**: If you have SQL files, ensure they're in standard locations:
- `database/`, `db/`, `sql/`, or `*.sql` files in project
- Or explicitly request: "Include database schema analysis"

---

## 🎯 Success Checklist

After generation, verify:

- [ ] `README.md` has accurate quick start steps
- [ ] Architecture diagrams render correctly
- [ ] All major components documented
- [ ] Dependency graph matches actual relationships
- [ ] Getting started guide includes all prerequisites
- [ ] Tech stack inventory is complete
- [ ] Cross-references work (click links in docs)
- [ ] Database docs included (if applicable)

---

## 📚 Related Resources

- **Migration Analysis**: Use `@migration-orchestrator` for modernization planning
- **Skills for Consistency**: Use `.NET backend skills` to ensure code follows documented patterns
- **Keep Updated**: Re-run quarterly or after major refactoring

---

## 🚀 Next Steps

1. **Review Documentation**: Read `docs/knowledgebase/README.md` first
2. **Share with Team**: Send `getting-started.md` to new developers
3. **Stakeholder Presentation**: Use `architecture.md` diagrams in meetings
4. **Continuous Updates**: Re-run after major changes

**Generate your first documentation now:**
```
@knowledgebase-orchestrator Generate complete repository documentation
```
