# How to Use @api-architect Chatmode

## 🎯 Overview

The `@api-architect` chatmode is a **dual-purpose .NET API expert** that:
1. **Reviews existing API code** with comprehensive feedback
2. **Generates complete working API client code** with resilience patterns

---

## 🚀 Quick Start

### Mode 1: Review Existing API Code

```
@api-architect

Review this API controller for best practices:

[paste your API controller code]
```

### Mode 2: Generate API Client Code

```
@api-architect

I need to generate API client code for connecting to an external payment service.
```

Then provide the required information and type **"generate"** to start.

---

## 📋 Mode 1: API Code Review

### What Gets Reviewed

The architect will analyze your code across **10 critical areas**:

| Area | What's Checked |
|------|----------------|
| **RESTful Design** | Resource naming, HTTP verbs, status codes, URI structure |
| **Security** | Auth, validation, sensitive data, CORS, rate limiting |
| **Error Handling** | Exception middleware, ProblemDetails, status codes |
| **Performance** | Async/await, caching, query optimization, DTOs |
| **Architecture** | Separation of concerns, DI, repositories, SOLID |
| **Request/Response** | Validation, DTOs, pagination, filtering |
| **Documentation** | Swagger, XML comments, README |
| **Testing** | Unit tests, integration tests, coverage |
| **Resilience** | Circuit breakers, retries, timeouts, health checks |
| **Code Quality** | Clean code, naming, error handling consistency |

### Example Review Session

```
You: @api-architect

Review this controller:

[UserController.cs code]

AI: 📊 API Architecture Review
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    
    ❌ CRITICAL ISSUES (Must Fix):
    
    1. Security Vulnerability: Missing [Authorize] attribute
       Location: CreateUser method (line 23)
       Impact: Allows unauthenticated user creation
       Fix: Add [Authorize(Roles = "Admin")]
       
    2. SQL Injection Risk: String concatenation in query
       Location: GetUsersByName method (line 45)
       Impact: Direct SQL injection vulnerability
       Fix: Use parameterized queries or EF Core
    
    ⚠️  HIGH PRIORITY (Should Fix):
    
    3. Performance: Blocking async call
       Location: GetUser method uses .Result (line 12)
       Impact: Thread pool starvation under load
       Fix: Use await instead
       
    4. Error Handling: No global exception middleware
       Impact: Inconsistent error responses
       Fix: Add app.UseExceptionHandler() in Program.cs
    
    💡 RECOMMENDATIONS:
    
    5. Use DTOs instead of returning entities directly
    6. Add pagination to GetAllUsers (could return 100k+ records)
    7. Add XML documentation comments
    8. Implement response caching for read operations
    
    📈 Overall API Maturity Score: 4/10
    
    Priority order:
    1️⃣  Fix security issues (URGENT)
    2️⃣  Fix async pattern
    3️⃣  Add error handling
    4️⃣  Implement DTOs
    5️⃣  Add documentation
```

### Common Review Patterns

#### Pattern 1: Full API Review

```
@api-architect

Review my entire API for production readiness.
Files: Controllers/*.cs, Services/*.cs
```

#### Pattern 2: Specific Concern

```
@api-architect

Focus on security issues in this authentication controller:

[paste code]
```

#### Pattern 3: Compare Approaches

```
@api-architect

Which approach is better for our API?

Option A: [code]
Option B: [code]

Context: We expect 10k requests/minute
```

#### Pattern 4: Migration Review

```
@api-architect

We're migrating from .NET Framework to .NET 8+.
Review this migrated controller for issues:

[paste code]
```

---

## 🏗️ Mode 2: API Client Code Generation

### The Generation Process

**Step 1:** Activate generation mode
```
@api-architect

Generate API client code for external service integration.
```

**Step 2:** AI requests information
```
🏗️ API Architect - Code Generation Mode

To generate a complete API solution, I need:

MANDATORY:
  1. Coding language: [e.g., C#, .NET 8+]
  2. API endpoint URL: [e.g., https://api.example.com]
  3. REST methods: [GET, POST, PUT, DELETE]

OPTIONAL:
  4. API name: [e.g., PaymentService]
  5. Request DTOs: [provide or I'll create mocks]
  6. Response DTOs: [provide or I'll create mocks]
  7. Circuit breaker: [yes/no]
  8. Bulkhead: [yes/no]
  9. Throttling: [yes/no]
  10. Retry with backoff: [yes/no]
  11. Test cases: [yes/no]

Type "generate" when ready.
```

**Step 3:** Provide information
```
1. C#, .NET 8+
2. https://api.stripe.com/v1
3. GET, POST
4. PaymentService
5-6. I'll provide DTOs below
7. Yes - circuit breaker
8. No
9. Yes - rate limit 100/minute
10. Yes - retry 3 times with exponential backoff
11. Yes - include tests

DTOs:
[paste your DTOs or let AI generate them]

generate
```

**Step 4:** AI generates complete code

```
✅ Generating complete API client solution...

Generated Files:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Configuration/PaymentServiceSettings.cs
2. Models/PaymentRequest.cs
3. Models/PaymentResponse.cs
4. Services/IPaymentService.cs
5. Services/PaymentService.cs
6. Managers/IPaymentManager.cs
7. Managers/PaymentManager.cs
8. Resilience/IPaymentResilientClient.cs
9. Resilience/PaymentResilientClient.cs
10. DependencyInjection/ServiceCollectionExtensions.cs
11. Tests/PaymentServiceTests.cs
12. Tests/PaymentManagerTests.cs
13. Tests/PaymentResilientClientTests.cs

[Complete working code for each file...]
```

### What Gets Generated

The AI creates a **production-ready, three-layer architecture**:

```
┌─────────────────────────────────────────────┐
│  YOUR APPLICATION CODE                      │
│  (Controllers, Business Logic)              │
└─────────────────────────────────────────────┘
                    ↓ calls
┌─────────────────────────────────────────────┐
│  RESILIENCE LAYER                           │
│  ✓ Circuit breaker (Polly)                 │
│  ✓ Retry with exponential backoff          │
│  ✓ Rate limiting/throttling                │
│  ✓ Timeout handling                         │
│  ✓ Bulkhead isolation (if requested)       │
└─────────────────────────────────────────────┘
                    ↓ calls
┌─────────────────────────────────────────────┐
│  MANAGER LAYER                              │
│  ✓ Configuration abstraction                │
│  ✓ DTO mapping                              │
│  ✓ Business logic isolation                 │
│  ✓ Testability                              │
└─────────────────────────────────────────────┘
                    ↓ calls
┌─────────────────────────────────────────────┐
│  SERVICE LAYER                              │
│  ✓ HTTP communication (HttpClient)         │
│  ✓ Serialization/deserialization           │
│  ✓ Request/response handling                │
│  ✓ All REST methods (GET, POST, etc.)      │
└─────────────────────────────────────────────┘
                    ↓ calls
┌─────────────────────────────────────────────┐
│  EXTERNAL API                               │
│  (Third-party service)                      │
└─────────────────────────────────────────────┘
```

### Generation Examples

#### Example 1: Simple REST Client

```
@api-architect

Generate client code

[Provides info:]
1. C#, .NET 8+
2. https://jsonplaceholder.typicode.com
3. GET, POST
4. TodoService
5-6. Generate mock DTOs
7-10. No resilience patterns
11. No tests

generate
```

**Result:** Basic client with Service and Manager layers (no resilience)

#### Example 2: Production-Grade Client

```
@api-architect

Generate production-ready client for payment processing

1. C#, .NET 8+
2. https://api.payment-gateway.com/v1
3. POST /payments, GET /payments/{id}
4. PaymentGatewayService
5. PaymentRequest: { Amount, Currency, CardToken, Description }
6. PaymentResponse: { Id, Status, TransactionId, Timestamp }
7. Yes - circuit breaker (3 failures, 30s break)
8. Yes - bulkhead (max 10 concurrent, 20 queued)
9. Yes - rate limit (100 requests/minute)
10. Yes - retry 3 times (exponential backoff)
11. Yes - full test suite

generate
```

**Result:** Complete production system with all layers and comprehensive tests

#### Example 3: Multiple Endpoints

```
@api-architect

Generate client for user management API

1. C#, .NET 8+
2. https://api.example.com/v1
3. GET /users, GET /users/{id}, POST /users, PUT /users/{id}, DELETE /users/{id}
4. UserManagementService
5-6. Generate standard CRUD DTOs
7-11. All resilience + tests

generate
```

**Result:** Full CRUD client with all operations

---

## 🎨 Code Generation Features

### 1. Complete Implementations

**❌ What You WON'T See:**
```csharp
// TODO: Implement retry logic
// Similarly implement for PUT and DELETE
// Add circuit breaker here
```

**✅ What You WILL See:**
```csharp
// Complete, working code for every method
private readonly AsyncCircuitBreakerPolicy _circuitBreakerPolicy;
private readonly AsyncRetryPolicy _retryPolicy;
private readonly AsyncBulkheadPolicy _bulkheadPolicy;

public async Task<PaymentResponse> ProcessPaymentAsync(PaymentRequest request)
{
    return await _retryPolicy.ExecuteAsync(async () =>
        await _circuitBreakerPolicy.ExecuteAsync(async () =>
            await _bulkheadPolicy.ExecuteAsync(async () =>
                await _manager.ProcessPaymentAsync(request)
            )
        )
    );
}

// Every method fully implemented, no placeholders!
```

### 2. Polly Resilience Patterns

Generated code uses **Polly** (industry standard for .NET):

```csharp
// Circuit Breaker - prevents cascading failures
var circuitBreaker = Policy
    .Handle<HttpRequestException>()
    .Or<TaskCanceledException>()
    .CircuitBreakerAsync(
        handledEventsAllowedBeforeBreaking: 3,
        durationOfBreak: TimeSpan.FromSeconds(30),
        onBreak: (exception, duration) => 
            _logger.LogWarning("Circuit breaker opened"),
        onReset: () => 
            _logger.LogInformation("Circuit breaker reset")
    );

// Retry with Exponential Backoff
var retry = Policy
    .Handle<HttpRequestException>()
    .WaitAndRetryAsync(
        retryCount: 3,
        sleepDurationProvider: retryAttempt => 
            TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
        onRetry: (exception, timeSpan, retryCount, context) =>
            _logger.LogWarning($"Retry {retryCount} after {timeSpan}")
    );

// Bulkhead - limits concurrent calls
var bulkhead = Policy
    .BulkheadAsync(
        maxParallelization: 10,
        maxQueuingActions: 20,
        onBulkheadRejectedAsync: context =>
        {
            _logger.LogWarning("Bulkhead rejected request");
            return Task.CompletedTask;
        }
    );
```

### 3. Dependency Injection Setup

Complete DI registration provided:

```csharp
// ServiceCollectionExtensions.cs
public static IServiceCollection AddPaymentService(
    this IServiceCollection services,
    IConfiguration configuration)
{
    // Configuration
    services.Configure<PaymentServiceSettings>(
        configuration.GetSection("PaymentService"));
    
    // HttpClient
    services.AddHttpClient<IPaymentService, PaymentService>()
        .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
        {
            AutomaticDecompression = DecompressionMethods.GZip
        })
        .SetHandlerLifetime(TimeSpan.FromMinutes(5));
    
    // Layers
    services.AddScoped<IPaymentService, PaymentService>();
    services.AddScoped<IPaymentManager, PaymentManager>();
    services.AddScoped<IPaymentResilientClient, PaymentResilientClient>();
    
    return services;
}

// Usage in Program.cs
builder.Services.AddPaymentService(builder.Configuration);
```

### 4. Complete Test Suite

If tests requested, you get:

```csharp
// Service Layer Tests
public class PaymentServiceTests
{
    [Fact]
    public async Task ProcessPayment_ValidRequest_ReturnsSuccess() { }
    
    [Fact]
    public async Task ProcessPayment_InvalidRequest_ThrowsException() { }
    
    [Fact]
    public async Task GetPayment_ExistingId_ReturnsPayment() { }
}

// Manager Layer Tests
public class PaymentManagerTests { }

// Resilience Tests
public class PaymentResilientClientTests
{
    [Fact]
    public async Task CircuitBreaker_OpensAfterThreeFailures() { }
    
    [Fact]
    public async Task Retry_RetriesThreeTimes_WithExponentialBackoff() { }
}
```

---

## 💡 Usage Tips

### Tip 1: Start with Review

Before generating new code, review existing patterns:

```
@api-architect

Review how we currently call external APIs in our codebase.
Search for HttpClient usage.
```

### Tip 2: Iterate on Generated Code

```
@api-architect

The generated PaymentService needs to also handle refunds.
Add a RefundPayment method with retry logic.
```

### Tip 3: Use for Learning

```
@api-architect

Generate a simple API client but explain each resilience pattern as you code it.
I want to understand how circuit breakers work.
```

### Tip 4: Request Specific Polly Configuration

```
@api-architect

Generate with circuit breaker but use these settings:
- Open after 5 failures (not 3)
- Break duration: 1 minute
- Also log metrics for monitoring
```

---

## 🎯 Common Scenarios

### Scenario 1: New External API Integration

```
@api-architect

We're integrating with Twilio SMS API.
Generate a production-ready client with full resilience.
Endpoint: https://api.twilio.com/2010-04-01
Methods: POST /Messages.json (send SMS), GET /Messages/{sid}.json
Include rate limiting (100 req/sec) and circuit breaker.
```

### Scenario 2: Existing Code Needs Resilience

```
@api-architect

Review this external API service:
[paste current code]

Then generate a resilient version with Polly patterns.
```

### Scenario 3: Microservice Communication

```
@api-architect

Generate client for calling our Order Service from Inventory Service.
Internal endpoint: http://order-service:8080/api
Methods: GET /orders/{id}, POST /orders, PUT /orders/{id}/status
No auth needed (internal), but add circuit breaker and retry.
```

### Scenario 4: Legacy Migration

```
@api-architect

We have old SOAP service calls. Generate REST client to replace it.
Endpoint: https://legacy-api.company.com/rest/v1
Methods: POST /customers, GET /customers/{id}
Add all resilience patterns - this service is unreliable.
```

---

## 📊 Review vs Generate Comparison

| Feature | Review Mode | Generate Mode |
|---------|-------------|---------------|
| **Input** | Your existing code | Requirements/specs |
| **Output** | Feedback & recommendations | Complete working code |
| **Use Case** | Quality check, improvements | New integrations |
| **Changes Made** | None (suggestions only) | Creates all files |
| **Depth** | Analyzes existing | Builds from scratch |
| **Time** | Quick (minutes) | Longer (detailed code) |

---

## 🚨 Important Notes

### For Reviews:

- ✅ Provides comprehensive checklist-based feedback
- ✅ Prioritizes issues (Critical > High > Medium > Low)
- ✅ References industry standards (OWASP, REST, Microsoft docs)
- ✅ Gives specific code examples for fixes
- ❌ Does NOT make changes (agent mode required for that)

### For Generation:

- ✅ **Waits for "generate" command** - won't start early
- ✅ **Complete code** - zero templates or TODOs
- ✅ **Three layers always** - Service, Manager, Resilience
- ✅ **Polly for resilience** - industry standard
- ✅ **Mock DTOs** - creates realistic examples if not provided
- ✅ **Full DI setup** - ready to plug into your app
- ✅ **Tests included** - if requested

---

## 🎓 Summary

| What You Want | What to Type |
|---------------|--------------|
| Review existing API code | `@api-architect Review this controller: [code]` |
| Quick API assessment | Use prompt: `@api-review-quick [code]` |
| Generate new API client | `@api-architect Generate client for external API` |
| Add resilience to existing code | `@api-architect Review + regenerate with resilience` |
| Learn API best practices | `@api-architect What are the top 10 API design mistakes?` |
| Compare approaches | `@api-architect Which is better: [A] or [B]?` |

---

**The API Architect is your expert consultant for building and reviewing production-grade .NET APIs!** 🏗️

- **Reviewing?** Get comprehensive feedback on 10 critical areas
- **Generating?** Get complete, working, resilient code with zero templates

Just describe what you need, and let the architect guide you! 🚀

