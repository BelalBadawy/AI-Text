# How to Use Git Commit Agent

Streamlined Git workflow with intelligent commit message generation, safety checks, and Conventional Commits compliance.

## 🎯 Overview

The `git-commit` agent is your **intelligent Git assistant** that automates the entire commit workflow from staging to push with built-in safety features. It generates high-quality Conventional Commit messages by analyzing your diffs and ensures you never accidentally break things.

**Key Features:**
- ✅ Automatic Conventional Commits message generation
- ✅ Protected branch warnings (main, master, develop, release/*)
- ✅ Sensitive data detection (API keys, tokens, passwords)
- ✅ Pre-commit hook failure handling
- ✅ Force-push safety (`--force-with-lease` only when explicitly requested)
- ✅ Merge conflict detection and recovery guidance
- ✅ Smart staging decisions

---

## 🚀 Quick Start

### Basic Commit Workflow

```
@git-commit /commit
```

This single command does everything:
1. Analyzes what changed
2. Stages relevant files
3. Generates Conventional Commit message from diff
4. Commits with the generated message
5. Pushes to current branch

### Custom Commit Message

```
@git-commit /commit "feat(auth): add OAuth2 support"
```

Uses your message but ensures it's Conventional Commits compliant.

---

## 🎮 Available Commands

| Command | What It Does | Example |
|---------|--------------|---------|
| `/commit` | Full workflow: status → stage → commit → push | `@git-commit /commit` |
| `/commit "msg"` | Use custom message (CC compliant) | `@git-commit /commit "fix(api): handle null response"` |
| `/status` | Detailed repository status analysis | `@git-commit /status` |
| `/diff` | Show and analyze diffs (staged + unstaged) | `@git-commit /diff` |
| `/stage` | Stage files (default: all relevant) | `@git-commit /stage` |
| `/unstage` | Unstage files | `@git-commit /unstage` |
| `/push` | Push current branch (set upstream if needed) | `@git-commit /push` |
| `/branch` | Show/create/switch branches | `@git-commit /branch` |
| `/log` | Enhanced commit history view | `@git-commit /log` |
| `/stash` | Stash changes temporarily | `@git-commit /stash` |
| `/revert` | Safe revert guidance | `@git-commit /revert` |

---

## 📝 Conventional Commits Format

The agent generates messages following [Conventional Commits](https://www.conventionalcommits.org/):

```
<type>(<scope>): <subject>

[optional body]

[optional footer]
```

### Types (Auto-Detected)

| Type | When Used | Example |
|------|-----------|---------|
| `feat` | New feature behavior | `feat(auth): add two-factor authentication` |
| `fix` | Bug fix | `fix(api): prevent null pointer in user lookup` |
| `perf` | Performance improvement | `perf(db): add index on user_id column` |
| `refactor` | Code restructuring (no behavior change) | `refactor(services): extract payment logic` |
| `test` | Tests only | `test(auth): add OAuth flow integration tests` |
| `docs` | Documentation only | `docs(readme): update deployment instructions` |
| `style` | Formatting, whitespace | `style(components): apply prettier formatting` |
| `ci` | CI/CD pipeline changes | `ci(github): add coverage reporting` |
| `chore` | Build/tooling/dependencies | `chore(deps): upgrade to .NET 8+` |

### Scope (Auto-Detected)

The agent detects scope from file paths:

| File Pattern | Detected Scope |
|--------------|----------------|
| `src/auth/*` | `auth` |
| `src/api/*` | `api` |
| `src/ui/*`, `*/components/*` | `ui` |
| `tests/*` | `test` |
| `.github/workflows/*` | `ci` |
| `packages/payment/*` | `payment` |

### Breaking Changes

Detected automatically when you:
- Remove/rename public APIs
- Change function signatures
- Rename environment variables
- Make database schema changes

**Format:**
```
feat(api)!: remove deprecated OAuth1 support

BREAKING CHANGE: OAuth1 authentication has been removed.
Migrate to OAuth2 using AuthService.loginOAuth2() method.
```

---

## 🛡️ Safety Features

### 1. Protected Branch Warnings

```
You: @git-commit /commit

Agent: ⚠️  WARNING: You are on protected branch 'main'

      Protected branches:
      - main, master (production)
      - develop (integration)
      - release/* (release candidates)
      
      Recommendations:
      1. Create feature branch: git checkout -b feature/my-change
      2. Or use: git checkout develop
      
      Continue committing to 'main'? (yes/no)
```

### 2. Sensitive Data Detection

```
You: @git-commit /commit

Agent: 🔴 SECURITY ALERT: Sensitive data detected!

      Files with potential secrets:
      - config/appsettings.json
        Line 12: "ApiKey": "sk-1234567890abcdef"
        
      - .env
        Line 5: "DATABASE_PASSWORD=mysecretpassword"
      
      RECOMMENDATIONS:
      1. Remove secrets from files
      2. Use environment variables or secret manager
      3. Add files to .gitignore
      4. Rotate compromised credentials
      
      Commit aborted for your safety.
```

**Detected Patterns:**
- API keys (OpenAI, AWS, Azure, Stripe, etc.)
- Database passwords
- JWT tokens
- Private keys (SSH, TLS)
- OAuth secrets

### 3. Pre-Commit Hook Failures

```
You: @git-commit /commit

Agent: ❌ Pre-commit hook failed!

      Hook: lint-staged
      Error: ESLint found 3 errors:
      
      src/components/UserProfile.tsx:45
        - Unexpected console.log statement
      
      RECOMMENDATIONS:
      1. Fix linting errors: npm run lint:fix
      2. Or skip hooks (not recommended): git commit --no-verify
      
      Commit aborted. Fix errors and try again.
```

### 4. Merge Conflict Detection

```
You: @git-commit /status

Agent: 🔴 MERGE CONFLICT DETECTED

      Conflicted files:
      - src/services/PaymentService.cs (UU)
      - src/models/User.cs (UU)
      
      RECOVERY OPTIONS:
      
      Option 1: Resolve conflicts
      1. Open conflicted files
      2. Search for <<<<<<< markers
      3. Choose correct version
      4. Remove conflict markers
      5. Stage resolved files: @git-commit /stage
      6. Complete merge: @git-commit /commit
      
      Option 2: Abort merge
      git merge --abort
      
      Cannot commit until conflicts resolved.
```

---

## 🎬 Complete Example Sessions

### Example 1: Simple Feature Commit

```
You: @git-commit /commit

Agent: 📊 Repository Status Analysis
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      
      Branch: feature/oauth2-support
      Upstream: origin/feature/oauth2-support (up to date)
      
      Changes detected:
      📝 Modified: 3 files
         - src/auth/OAuthService.cs (45 lines)
         - src/auth/IAuthProvider.cs (8 lines)
         - tests/auth/OAuthServiceTests.cs (67 lines)
      
      ➕ Added: 1 file
         - src/auth/OAuth2Provider.cs (120 lines)
      
      Analyzing diff for commit message...
      
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      
      ✅ Staged 4 files
      
      📝 Generated Commit Message:
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      feat(auth): add OAuth2 authentication support
      
      - Implement OAuth2Provider with authorization code flow
      - Add token refresh mechanism
      - Extend IAuthProvider with OAuth2 methods
      - Add comprehensive test coverage (15 test scenarios)
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      
      Commit? (yes/no/edit)

You: yes

Agent: ✅ Committed: 4dg72k1
      
      🚀 Pushing to origin/feature/oauth2-support...
      
      ✅ Push successful!
      
      Summary:
      - Branch: feature/oauth2-support
      - Files: 4 changed (208 insertions, 15 deletions)
      - Commit: feat(auth): add OAuth2 authentication support
      
      Next steps:
      - Create PR: gh pr create
      - Or continue developing: make more changes
```

---

### Example 2: Breaking Change Detection

```
You: @git-commit /commit

Agent: 📊 Repository Status Analysis
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      
      Branch: feature/api-v2
      
      Changes detected:
      📝 Modified: 2 files
         - src/api/UserController.cs
         - src/api/IUserService.cs
      
      🔴 BREAKING CHANGES DETECTED:
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      
      src/api/IUserService.cs:
      - REMOVED: GetUser(int id)
      - ADDED: GetUserAsync(Guid userId)
      
      This is a breaking change:
      - Method signature changed (int → Guid)
      - Synchronous → async
      
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      
      ✅ Staged 2 files
      
      📝 Generated Commit Message:
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      feat(api)!: migrate user service to async with GUIDs
      
      - Change user ID type from int to Guid
      - Convert GetUser to async GetUserAsync
      - Update all controller endpoints
      
      BREAKING CHANGE: GetUser(int id) removed.
      Migrate to GetUserAsync(Guid userId) for all user lookups.
      Update client code to use GUIDs and await calls.
      ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      
      ⚠️  This commit introduces BREAKING CHANGES.
      
      Commit? (yes/no/edit)
```

---

### Example 3: Force-Push Safety

```
You: @git-commit /push

Agent: ⚠️  ALERT: Your branch has diverged from origin!
      
      Your branch: 3 commits ahead, 2 commits behind
      
      Local commits not on origin:
      - a7f3c21 feat(auth): add OAuth2
      - b9d4e12 test(auth): add OAuth tests
      - c2e5f78 docs(auth): update auth guide
      
      Remote commits not in local:
      - x1y2z34 fix(api): handle timeout
      - m4n5o67 chore(deps): update packages
      
      ⚠️  FORCE-PUSH REQUIRED
      
      This is a potentially destructive operation!
      
      OPTIONS:
      
      1. Rebase (Recommended):
         git pull --rebase origin feature/oauth2
         Then push normally
      
      2. Force-push with lease (Safer):
         Only succeeds if no one else pushed
         @git-commit /push --force
      
      3. Abort:
         Review remote changes first
      
      What would you like to do? (rebase/force/abort)

You: rebase

Agent: Executing: git pull --rebase origin feature/oauth2
      
      ✅ Rebase successful!
      ✅ Pushed to origin/feature/oauth2
      
      Your commits are now on top of latest remote changes.
```

---

## 🔧 Advanced Usage

### Selective Staging

```
@git-commit /stage src/auth/*

Stages only authentication-related files.
```

### Split Commits

```
You: @git-commit /diff

Agent: Changes span multiple concerns:
      
      Authentication changes (src/auth/):
      - OAuthService.cs
      - OAuth2Provider.cs
      
      API changes (src/api/):
      - UserController.cs
      - PaymentController.cs
      
      RECOMMENDATION: Create separate commits
      
      1. @git-commit /stage src/auth/*
         @git-commit /commit
      
      2. @git-commit /stage src/api/*
         @git-commit /commit
      
      This creates cleaner history.
```

### Custom Message with Validation

```
You: @git-commit /commit "added new feature"

Agent: ⚠️  Message not Conventional Commits compliant
      
      Your message: "added new feature"
      
      Issues:
      - Missing type (feat, fix, etc.)
      - Not imperative mood ("add" not "added")
      - Missing scope
      
      Suggested correction:
      "feat(feature-scope): add new feature"
      
      Use suggested message? (yes/no/edit)
```

---

## 💡 Best Practices

### 1. Commit Early and Often

```
@git-commit /commit
```

Small, focused commits are better than large dumps.

### 2. Review Diff Before Committing

```
@git-commit /diff
```

Always review what you're committing.

### 3. Use Branches for Features

```
@git-commit /branch feature/my-feature
@git-commit /commit
```

Never commit directly to `main` or `develop`.

### 4. Let Agent Generate Messages

The agent analyzes your diff and creates accurate messages. Don't override unless necessary.

### 5. Respond to Safety Warnings

If the agent warns about sensitive data or protected branches, **take it seriously**.

---

## 🐛 Troubleshooting

### Problem: "Pre-commit hook failed"

**Cause**: Linter, formatter, or tests failed.

**Solution**:
```bash
# Fix automatically if possible
npm run lint:fix
dotnet format

# Or skip hooks (not recommended)
git commit --no-verify
```

---

### Problem: "Detached HEAD state"

**Cause**: You checked out a specific commit.

**Solution**:
```
@git-commit /branch

Agent will guide you to:
1. Create branch: git checkout -b my-branch
2. Or return to branch: git checkout main
```

---

### Problem: "Push rejected (non-fast-forward)"

**Cause**: Remote has commits you don't have.

**Solution**:
```
@git-commit /push

Agent will recommend:
1. Pull with rebase: git pull --rebase
2. Or force-push with lease (if you're sure)
```

---

### Problem: "Nothing to commit"

**Cause**: No staged or unstaged changes.

**Solution**:
```
@git-commit /status

Check if files are untracked or ignored by .gitignore
```

---

## ✅ Success Checklist

Before pushing:

- [ ] Reviewed diff with `/diff`
- [ ] Commit message is descriptive and follows Conventional Commits
- [ ] No sensitive data in commit (API keys, passwords)
- [ ] Pre-commit hooks passed
- [ ] Tests pass locally
- [ ] On correct branch (not main/master)
- [ ] Breaking changes documented in footer

---

## 🎯 Common Workflows

### Daily Development

```bash
# Morning: Start new feature
@git-commit /branch feature/user-profile
@git-commit /status

# During development: Regular commits
@git-commit /commit  # Multiple times

# End of day: Push to remote
@git-commit /push
```

### Bug Fix

```bash
# Create fix branch
@git-commit /branch hotfix/api-timeout

# Make changes
@git-commit /commit  # "fix(api): increase timeout to 30s"

# Push and create PR
@git-commit /push
```

### Release Preparation

```bash
# Check status
@git-commit /status

# Review history
@git-commit /log

# Ensure clean state
@git-commit /diff  # Should be empty
```

---

## 🚀 Integration with PR Workflow

After committing and pushing, create a PR:

```
@git-commit /push

Then use handoff:
"Create PR description" → Generates title and description from commits
```

The agent can draft PR descriptions based on your commits!

---

## 📚 Related Resources

- [Conventional Commits](https://www.conventionalcommits.org/)
- [Git Best Practices](https://git-scm.com/book/en/v2)
- [Semantic Versioning](https://semver.org/)

---

## 🎯 Quick Reference Card

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Git Commit Agent - Command Reference
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Full Workflow:     @git-commit /commit
Custom Message:    @git-commit /commit "type(scope): message"
Status:            @git-commit /status
Diff:              @git-commit /diff
Stage:             @git-commit /stage [files]
Unstage:           @git-commit /unstage [files]
Push:              @git-commit /push
Branch:            @git-commit /branch [name]
History:           @git-commit /log
Stash:             @git-commit /stash
Revert:            @git-commit /revert

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Safety Checks: ✅ Protected branches | ✅ Sensitive data
               ✅ Breaking changes  | ✅ Merge conflicts
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Start committing smartly:**
```
@git-commit /commit
```
