# How to Use Custom Prompts in VS Code

📋 **Quick Start**: Use custom prompt files as slash commands in GitHub Copilot Chat to standardize common development tasks.

---

## Table of Contents
- [What Are Custom Prompts?](#what-are-custom-prompts)
- [Repository-Level Prompts (Single Workspace)](#repository-level-prompts-single-workspace)
- [Global Prompts (All Workspaces)](#global-prompts-all-workspaces)
- [Using Prompts in Chat](#using-prompts-in-chat)
- [Available Prompts in This Repo](#available-prompts-in-this-repo)
- [Creating Your Own Prompts](#creating-your-own-prompts)
- [Troubleshooting](#troubleshooting)

---

## What Are Custom Prompts?

Custom prompts are reusable prompt files that appear as **slash commands** in GitHub Copilot Chat. They:
- Standardize complex development tasks
- Include project-specific context and patterns
- Support configuration variables for customization
- Work across all files in a repository or globally

**Example**: Instead of typing a long prompt for API design, type `/api-architect` and the full prompt loads automatically.

---

## Repository-Level Prompts (Single Workspace)

### Step 1: Create the Prompts Directory

```powershell
# In your repository root
New-Item -ItemType Directory -Path ".github/prompts" -Force
```

### Step 2: Copy Prompt Files

Copy prompt files from this repository to your project:

```powershell
# Copy specific prompts
Copy-Item "path/to/Zelis.AI.Studio/prompts/tech/api-design/*.prompt.md" ".github/prompts/"

# Or copy all prompts from a category
Copy-Item "path/to/Zelis.AI.Studio/prompts/tech/*/*.prompt.md" ".github/prompts/" -Recurse
```

**Example: Copy API Architecture Prompt**
```powershell
Copy-Item "C:/repos/Zelis.AI.Studio/prompts/tech/api-design/api-client-generator.prompt.md" ".github/prompts/"
```

### Step 3: Reload VS Code

After copying prompts, reload VS Code to register them:

1. **Option A**: Command Palette
   - Press `Ctrl+Shift+P` (Windows/Linux) or `Cmd+Shift+P` (Mac)
   - Type `Developer: Reload Window`
   - Press Enter

2. **Option B**: Close and reopen VS Code

### Step 4: Verify Prompts Are Available

1. Open GitHub Copilot Chat (`Ctrl+Alt+I` or click chat icon)
2. Type `/` to see available slash commands
3. Your custom prompts should appear in the list

**Expected Result**:
```
/ (slash commands)
├── /api-architect (if you copied api-client-generator.prompt.md)
├── /doc (if you copied documentation prompts)
└── ... (other custom prompts)
```

---

## Global Prompts (All Workspaces)

Make prompts available to **all repositories** on your machine.

### Step 1: Locate Global Prompts Directory

The global prompts directory varies by OS:

**Windows**:
```
%USERPROFILE%\.github\prompts\
```

**macOS/Linux**:
```
~/.github/prompts/
```

### Step 2: Create Global Prompts Directory

**Windows (PowerShell)**:
```powershell
New-Item -ItemType Directory -Path "$env:USERPROFILE\.github\prompts" -Force
```

**macOS/Linux (Bash)**:
```bash
mkdir -p ~/.github/prompts
```

### Step 3: Copy Prompts to Global Directory

**Windows (PowerShell)**:
```powershell
# Copy all prompts from this repository
Copy-Item "C:/repos/Zelis.AI.Studio/prompts/tech/*/*.prompt.md" "$env:USERPROFILE\.github\prompts\" -Recurse

# Or copy specific categories
Copy-Item "C:/repos/Zelis.AI.Studio/prompts/tech/api-design/*.prompt.md" "$env:USERPROFILE\.github\prompts\"
Copy-Item "C:/repos/Zelis.AI.Studio/prompts/tech/documentation/*.prompt.md" "$env:USERPROFILE\.github\prompts\"
```

**macOS/Linux (Bash)**:
```bash
# Copy all prompts from this repository
cp ~/repos/Zelis.AI.Studio/prompts/tech/*/*.prompt.md ~/.github/prompts/

# Or copy specific categories
cp ~/repos/Zelis.AI.Studio/prompts/tech/api-design/*.prompt.md ~/.github/prompts/
cp ~/repos/Zelis.AI.Studio/prompts/tech/documentation/*.prompt.md ~/.github/prompts/
```

### Step 4: Reload All VS Code Windows

Close and reopen all VS Code instances for global prompts to take effect.

### Step 5: Verify Global Availability

1. Open **any repository** in VS Code
2. Open GitHub Copilot Chat (`Ctrl+Alt+I`)
3. Type `/` - your global prompts should appear

---

## Using Prompts in Chat

### Basic Usage

1. Open GitHub Copilot Chat (`Ctrl+Alt+I`)
2. Type `/` to see available prompts
3. Select a prompt or type its name (e.g., `/api-architect`)
4. The prompt loads with default configuration
5. Follow the prompt's instructions (answer questions, provide context)

### Example: Using API Architect Prompt

**Step 1**: Invoke the prompt
```
/api-architect
```

**Step 2**: The prompt asks for context
```
To generate a complete API solution, I need:

MANDATORY:
  1. Coding language: [e.g., C#, .NET 8+]
  2. API endpoint URL: [e.g., https://api.example.com]
  3. REST methods: [GET, POST, PUT, DELETE]
...
```

**Step 3**: Provide your answers
```
1. C#, .NET 8+
2. https://api.paymentgateway.com/v1
3. POST /payments, GET /payments/{id}
4. PaymentGatewayClient
```

**Step 4**: Copilot generates the code based on the prompt template

### Configuring Prompt Variables

Some prompts support configuration variables (e.g., `${LANGUAGE}`, `${FRAMEWORK}`).

**Default behavior**: Variables use default values specified in the prompt file.

**Override variables** (if supported):
```
/api-architect LANGUAGE=TypeScript FRAMEWORK=Express
```

---

## Available Prompts in This Repo

### API Design & Architecture
- **api-client-generator.prompt.md**: Generate REST API clients with resilience patterns
- Location: `prompts/tech/api-design/`

### Documentation
- **copilot-instructions-generator.prompt.md**: Generate comprehensive copilot-instructions.md files
- Location: `prompts/tech/documentation/`

### Database
- **SQL database design and migration prompts** (if available in `prompts/tech/database/`)

### Testing
- **Unit test generation prompts** (if available in `prompts/tech/testing/`)

**To see all available prompts**:
```powershell
Get-ChildItem "prompts" -Recurse -Filter "*.prompt.md"
```

---

## Creating Your Own Prompts

### Prompt File Structure

Create a `.prompt.md` file in `.github/prompts/`:

```markdown
---
description: 'Brief description of what this prompt does'
mode: 'agent'
---

# Prompt Title

## Configuration Variables
${VARIABLE_NAME="default_value|option1|option2"} <!-- Description -->

## Generated Prompt

"Your prompt instructions go here.

Use ${VARIABLE_NAME} to reference configuration variables.

Provide clear, step-by-step instructions for Copilot to follow."

## Expected Output

Description of what the user should expect after running this prompt.
```

### Example: Custom Code Review Prompt

**File**: `.github/prompts/code-review-security.prompt.md`

```markdown
---
description: 'Perform security-focused code review with OWASP Top 10 checks'
mode: 'agent'
---

# Security Code Review

## Configuration Variables
${LANGUAGE="C#|Java|Python|JavaScript|TypeScript"} <!-- Programming language -->
${FRAMEWORK="Auto-detect|.NET|Spring|Django|Express|React"} <!-- Framework -->

## Generated Prompt

"Perform a comprehensive security code review on the selected code or current file.

Focus on:
1. **OWASP Top 10 vulnerabilities**:
   - Injection (SQL, NoSQL, LDAP, OS commands)
   - Broken authentication and session management
   - Sensitive data exposure
   - XML External Entities (XXE)
   - Broken access control
   - Security misconfiguration
   - Cross-Site Scripting (XSS)
   - Insecure deserialization
   - Using components with known vulnerabilities
   - Insufficient logging and monitoring

2. **${LANGUAGE}-specific security issues**:
   - Input validation and sanitization
   - Parameterized queries
   - Secure cryptographic practices
   - Authentication and authorization patterns

3. **${FRAMEWORK}-specific concerns** (if detected)

For each finding:
- Severity: Critical | High | Medium | Low
- Description: What is the vulnerability?
- Location: File and line number
- Recommendation: How to fix it
- Example: Secure code snippet

Prioritize issues by severity and exploitability."

## Expected Output

A detailed security report with:
- Summary of findings by severity
- Line-by-line security issues with recommendations
- Secure code examples for each issue
- Overall security score and risk assessment
```

### Registering Your Custom Prompt

1. Save the file in `.github/prompts/`
2. Reload VS Code (`Ctrl+Shift+P` → `Developer: Reload Window`)
3. Open Copilot Chat and type `/` to see your new prompt

**Prompt name**: Derived from the filename (e.g., `code-review-security.prompt.md` becomes `/code-review-security`)

---

## Troubleshooting

### Prompt Not Appearing in Slash Commands

**Issue**: Prompt file copied but doesn't appear in `/` list.

**Solutions**:
1. **Verify file location**:
   ```powershell
   # Repository-level
   Test-Path ".github/prompts/your-prompt.prompt.md"
   
   # Global
   Test-Path "$env:USERPROFILE\.github\prompts\your-prompt.prompt.md"
   ```

2. **Check file extension**: Must be `.prompt.md` (not `.md` or `.txt`)

3. **Verify frontmatter**: File must start with YAML frontmatter:
   ```markdown
   ---
   description: 'Prompt description'
   mode: 'agent'
   ---
   ```

4. **Reload VS Code**: 
   - `Ctrl+Shift+P` → `Developer: Reload Window`
   - Or close and reopen VS Code

5. **Check VS Code version**: Ensure GitHub Copilot extension is up to date
   - `Ctrl+Shift+X` → Search "GitHub Copilot" → Update if available

### Prompt Variables Not Working

**Issue**: Configuration variables (e.g., `${LANGUAGE}`) not being replaced.

**Solutions**:
1. **Use correct syntax**: `${VARIABLE_NAME}` (case-sensitive)
2. **Check variable declaration**: Must be declared in `## Configuration Variables` section
3. **Verify default value**: Provide a default in the variable declaration:
   ```markdown
   ${LANGUAGE="C#|Java|Python"} <!-- Picks first option as default -->
   ```

### Global Prompts Not Available

**Issue**: Prompts in `~/.github/prompts/` don't appear in all workspaces.

**Solutions**:
1. **Verify global directory path**:
   ```powershell
   # Windows
   echo $env:USERPROFILE\.github\prompts
   
   # macOS/Linux
   echo ~/.github/prompts
   ```

2. **Check permissions**: Ensure the directory is readable
   ```powershell
   # Windows (PowerShell as Admin)
   Get-Acl "$env:USERPROFILE\.github\prompts"
   ```

3. **Restart VS Code completely**: Close all VS Code windows and reopen

4. **Check for repository-level overrides**: Repository-level prompts (`.github/prompts/`) take precedence over global prompts with the same name

### Prompt Loads But Doesn't Work

**Issue**: Prompt appears in `/` list but doesn't execute correctly.

**Solutions**:
1. **Check prompt syntax**: Ensure the prompt template is valid markdown
2. **Review prompt content**: Open the `.prompt.md` file and verify the instructions are clear
3. **Test in isolation**: Try the prompt in a new, empty file
4. **Check Copilot status**: Ensure Copilot is active and authenticated
   - Bottom-right corner should show Copilot icon
   - Click icon to verify status

### Prompts Slow to Load

**Issue**: Prompt takes a long time to appear or execute.

**Solutions**:
1. **Reduce prompt size**: Large prompts (>5000 tokens) may be slow
2. **Simplify variables**: Too many configuration variables can slow processing
3. **Check network**: Copilot requires internet connection
4. **Clear Copilot cache**: 
   - `Ctrl+Shift+P` → `GitHub Copilot: Clear Cache`
   - Reload VS Code

---

## Best Practices

### Organizing Prompts

**Repository-Level** (`.github/prompts/`):
- Project-specific prompts
- Team-standardized templates
- Temporary or experimental prompts

**Global** (`~/.github/prompts/`):
- Frequently used prompts across all projects
- Personal productivity prompts
- Language/framework-agnostic prompts

### Naming Conventions

Use descriptive, action-based names:
- ✅ `api-client-generator.prompt.md` (clear purpose)
- ✅ `security-code-review.prompt.md` (descriptive)
- ❌ `prompt1.prompt.md` (not descriptive)
- ❌ `test.prompt.md` (too vague)

### Version Control

**Repository-level prompts**: Commit to Git
```bash
git add .github/prompts/
git commit -m "feat: add custom API client generator prompt"
git push
```

**Global prompts**: Keep in a separate Git repo for backup
```bash
cd ~/.github/prompts
git init
git add *.prompt.md
git commit -m "Initial commit of global prompts"
git remote add origin https://github.com/yourusername/global-copilot-prompts.git
git push -u origin main
```

### Sharing Prompts with Team

**Option A**: Repository-level (recommended for teams)
1. Add prompts to `.github/prompts/` in your repo
2. Commit and push
3. Team members pull changes
4. Everyone reloads VS Code

**Option B**: Shared global prompts
1. Create a shared repository for global prompts
2. Each team member clones to their `~/.github/prompts/` directory:
   ```powershell
   git clone https://github.com/yourorg/global-prompts.git "$env:USERPROFILE\.github\prompts"
   ```
3. Pull updates periodically:
   ```powershell
   cd "$env:USERPROFILE\.github\prompts"
   git pull
   ```

---

## Quick Reference

### Key Locations

| Type | Windows | macOS/Linux |
|------|---------|-------------|
| **Repository** | `.github/prompts/` | `.github/prompts/` |
| **Global** | `%USERPROFILE%\.github\prompts\` | `~/.github/prompts/` |

### Common Commands

| Action | Windows (PowerShell) | macOS/Linux (Bash) |
|--------|----------------------|--------------------|
| **Create repo prompts dir** | `New-Item -ItemType Directory -Path ".github/prompts" -Force` | `mkdir -p .github/prompts` |
| **Create global prompts dir** | `New-Item -ItemType Directory -Path "$env:USERPROFILE\.github\prompts" -Force` | `mkdir -p ~/.github/prompts` |
| **Copy prompt** | `Copy-Item "source.prompt.md" ".github/prompts/"` | `cp source.prompt.md .github/prompts/` |
| **List prompts** | `Get-ChildItem ".github/prompts" -Filter "*.prompt.md"` | `ls .github/prompts/*.prompt.md` |
| **Reload VS Code** | `Ctrl+Shift+P` → `Developer: Reload Window` | `Cmd+Shift+P` → `Developer: Reload Window` |

### VS Code Keyboard Shortcuts

| Action | Windows/Linux | macOS |
|--------|---------------|-------|
| **Open Copilot Chat** | `Ctrl+Alt+I` | `Cmd+Option+I` |
| **Command Palette** | `Ctrl+Shift+P` | `Cmd+Shift+P` |
| **Reload Window** | `Ctrl+Shift+P` → `Reload Window` | `Cmd+Shift+P` → `Reload Window` |

---

## Related Documentation

- [How to Create Custom GPTs](HOW-TO-CREATE-CUSTOM-GPT.md) - For ChatGPT custom GPTs instead of VS Code prompts
- [How to Use Agents](../agents/) - For GitHub Copilot agents that use these prompts
- [Prompt Templates](../../prompts/) - Browse all available prompt templates in this repository

---

**Last Updated**: January 30, 2026
**Feedback**: Found an issue or have suggestions? Open an issue in this repository.
