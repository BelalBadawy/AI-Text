# How to Create and Configure Custom GPTs

Create custom AI assistants in ChatGPT Enterprise with specialized instructions, connectors, and capabilities tailored to your team's workflows.

## What is a Custom GPT?

A Custom GPT is a configured ChatGPT instance with:
- **Custom Instructions** - Specialized behavior and domain knowledge
- **Connectors** - Integration with external tools (Jira, Confluence, SharePoint)
- **Capabilities** - Web browsing, code interpreter, image generation
- **Conversation Starters** - Pre-defined prompts for common use cases

## Quick Start

1. Go to ChatGPT Enterprise → **Explore GPTs** → **Create a GPT**
2. Select **Configure** tab
3. Add name, description, and instructions
4. Enable capabilities and connectors
5. Test and publish

---

## Step-by-Step Guide

### Step 1: Access GPT Builder

1. Open ChatGPT Enterprise
2. Click **"Explore GPTs"** in the sidebar
3. Click **"Create a GPT"** or **"Create"** button
4. You'll see two tabs: **Create** (conversational) and **Configure** (direct editing)
5. Select **Configure** for full control

### Step 2: Basic Configuration

| Field | Purpose | Tips |
|-------|---------|------|
| **Name** | Display name in GPT gallery | Include team/domain prefix: `[Team] Agent Name` |
| **Description** | Brief explanation shown in gallery | 1-2 sentences explaining what it does |
| **Instructions** | System prompt defining behavior | See "Writing Effective Instructions" below |
| **Profile Picture** | Icon shown in chat | Use team logo or relevant icon |

### Step 3: Write Instructions

Instructions are the core of your Custom GPT. They define:
- Who the GPT is (role, personality)
- What it does (capabilities, workflow)
- How it behaves (constraints, guidelines)
- What tools it uses (connectors, actions)

**Basic Structure**:

```markdown
# [GPT Name] Instructions

You are **[GPT Name]**, a [role description] that helps users [primary purpose].

## Your Role
- [Key responsibility 1]
- [Key responsibility 2]
- [Key responsibility 3]

## Workflow
### Step 1: [First Phase]
[What to do in this phase]

### Step 2: [Second Phase]
[What to do in this phase]

## Important Guidelines
### DO:
- [Best practice 1]
- [Best practice 2]

### DON'T:
- [Anti-pattern 1]
- [Anti-pattern 2]

## Tools Available
- [Tool 1]: [When/how to use]
- [Tool 2]: [When/how to use]
```

**Example** - A Code Review GPT:

```markdown
# Code Review GPT Instructions

You are **Code Review GPT**, a senior engineer assistant that helps developers improve code quality through constructive feedback.

## Your Role
- Review code for bugs, security issues, and best practices
- Suggest improvements with explanations
- Provide educational context for recommendations

## Workflow
### Step 1: Understand Context
- Ask what the code does if unclear
- Identify the programming language and framework

### Step 2: Review Code
- Check for bugs and logic errors
- Identify security vulnerabilities
- Assess code style and readability
- Evaluate performance implications

### Step 3: Provide Feedback
- Prioritize critical issues first
- Explain why each issue matters
- Provide corrected code examples
- Be constructive, not critical

## Important Guidelines
### DO:
- Be specific with line numbers and examples
- Explain the "why" behind recommendations
- Acknowledge good patterns you see

### DON'T:
- Be condescending or harsh
- Nitpick trivial style issues
- Rewrite entire functions unnecessarily
```

### Step 4: Enable Capabilities

| Capability | Purpose | When to Enable |
|------------|---------|----------------|
| **Web Browsing** | Search the internet | Research, current information, documentation lookup |
| **Code Interpreter** | Execute Python, analyze files | Data analysis, file processing, calculations |
| **DALL-E** | Generate images | Visual content creation |

### Step 5: Configure Connectors

Connectors integrate external services into your GPT.

#### Rovo Connector (Atlassian)

Enable for Jira and Confluence integration:

| Tool | Purpose |
|------|---------|
| `confluence.search` | Search Confluence spaces |
| `confluence.get_page` | Read specific pages |
| `confluence.create_page` | Create new pages |
| `jira.search_issues` | Search Jira issues |
| `jira.get_issue` | Read issue details |
| `jira.create_issue` | Create new issues |

#### Microsoft Connector (SharePoint/OneDrive)

Enable for Microsoft 365 integration:

| Tool | Purpose |
|------|---------|
| `sharepoint.search_documents` | Search documents |
| `sharepoint.get_document` | Read specific documents |
| `sharepoint.upload_document` | Upload new documents |

#### Adding Connectors

1. Go to **Actions** section
2. Click **"Add Action"**
3. Select **"Import from Connector"**
4. Choose the connector (Rovo, Microsoft, etc.)
5. Select specific tools to enable
6. Save

### Step 6: Add Conversation Starters

Pre-defined prompts help users understand what the GPT can do:

```
Good Examples:
- "Review this code for security issues"
- "Create a PRD for [feature description]"
- "Find all Jira tickets related to authentication"

Bad Examples:
- "Help me" (too vague)
- "Do something" (not actionable)
```

### Step 7: Test Your GPT

Before publishing:

1. Click **Preview** to test in the builder
2. Try each conversation starter
3. Test connector integrations
4. Verify edge cases and error handling
5. Check that instructions are followed

### Step 8: Publish and Share

| Visibility | Who Can Access | Use Case |
|------------|----------------|----------|
| **Only me** | Just you | Development and testing |
| **My workspace** | Your organization | Team-wide tools |
| **Anyone with link** | People with URL | Controlled sharing |
| **Public** | Everyone | Open tools (not recommended for internal) |

---

## Advanced Configuration

### Adding Team Configuration

For GPTs that need team-specific settings, include a configuration section:

```markdown
## Team Configuration

Load team-specific settings from the configuration provided below.

---

**PASTE YOUR TEAM CONFIGURATION BELOW THIS LINE**

```yaml
# Team settings go here
team:
  name: "Your Team"
  jira:
    project_key: "PROJ"
```
```

Users paste their team config when setting up the GPT.

### Human-in-the-Loop Checkpoints

For GPTs that perform actions (create issues, documents), add checkpoints:

```markdown
## Checkpoints

**IMPORTANT**: Always pause and ask for approval before:
1. Creating any Jira issues
2. Creating or modifying Confluence pages
3. Uploading documents to SharePoint

**Format**: Present a summary and ask: "Ready to create this? (yes/no)"
```

### Error Handling

Include guidance for common errors:

```markdown
## Error Handling

If a connector action fails:
1. Show the error message to the user
2. Suggest possible causes:
   - Permission issues
   - Invalid IDs or URLs
   - Network connectivity
3. Offer to retry or provide alternative approaches
```

### Multi-Stage Workflows

For complex workflows, define clear stages:

```markdown
## Workflow Stages

### Stage 1: Gather Information
[Steps]

**CHECKPOINT 1**: "I've gathered [X]. Proceed to analysis?"

### Stage 2: Analysis
[Steps]

**CHECKPOINT 2**: "Here's my analysis: [summary]. Proceed to create?"

### Stage 3: Create Artifacts
[Steps]

**CHECKPOINT 3**: "Created [X]. Anything else?"
```

---

## Best Practices

### Writing Effective Instructions

| Do | Don't |
|----|-------|
| Be specific and actionable | Be vague or ambiguous |
| Use clear formatting (headers, lists) | Write walls of text |
| Include examples | Assume user knows the format |
| Define boundaries clearly | Leave behavior undefined |
| Specify tool usage | Let GPT guess which tools to use |

### Instruction Length

- **Short** (< 500 words): Simple, focused tasks
- **Medium** (500-2000 words): Multi-step workflows
- **Long** (2000+ words): Complex domain-specific assistants

Keep instructions as concise as possible while being complete.

### Testing Checklist

- [ ] All conversation starters work
- [ ] Connectors authenticate successfully
- [ ] Actions create correct outputs
- [ ] Error messages are helpful
- [ ] Edge cases are handled
- [ ] Instructions are followed consistently

---

## Troubleshooting

### Connector Issues

| Problem | Solution |
|---------|----------|
| Connector not available | Contact ChatGPT Enterprise admin to enable |
| Authentication fails | Re-authenticate in connector settings |
| Permission denied | Check account permissions in the service |
| Actions fail silently | Check connector logs in admin console |

### Instruction Issues

| Problem | Solution |
|---------|----------|
| GPT ignores instructions | Make instructions more explicit with "MUST" |
| GPT hallucinates tools | List available tools explicitly |
| Inconsistent behavior | Add examples of expected responses |
| Wrong format | Provide templates in instructions |

### Publishing Issues

| Problem | Solution |
|---------|----------|
| Can't set visibility | Check organization admin settings |
| Users can't access | Verify workspace membership |
| GPT not in gallery | Allow time for indexing (few minutes) |

---

## Examples in This Repository

This repository includes several Custom GPT instruction files:

| GPT | File | Purpose |
|-----|------|---------|
| Ideation GPT | `chatgpt/ideation-gpt/instructions.md` | PRD creation with research |
| Epic GPT | `chatgpt/epic-gpt/instructions.md` | PRD to Jira Epic conversion |
| Story GPT | `chatgpt/story-gpt/instructions.md` | Epic to Stories breakdown |

See `docs/setup/chatgpt-custom-gpts.md` for setup instructions.

---

## Related Resources

- [OpenAI GPT Builder Documentation](https://help.openai.com/en/articles/8554397-creating-a-gpt)
- [ChatGPT Enterprise Admin Guide](https://help.openai.com/en/collections/5688095-chatgpt-enterprise)
- [Atlassian Rovo Connector](https://www.atlassian.com/software/rovo)
- [Microsoft 365 Copilot Connectors](https://learn.microsoft.com/en-us/microsoft-365-copilot/extensibility/)
