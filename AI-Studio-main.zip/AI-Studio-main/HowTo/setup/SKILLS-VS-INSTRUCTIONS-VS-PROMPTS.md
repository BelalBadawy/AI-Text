# Understanding Skills vs Instructions vs Prompts

📘 **Quick Answer**: **Skills** are auto-loaded based on file context, **Instructions** would be always-loaded global rules (not currently used in this repo), and **Prompts** are on-demand reusable commands you explicitly invoke.

---

## Table of Contents
- [The Key Difference](#the-key-difference)
- [Skills (SKILL.md) - Contextual, Auto-Loaded](#skills-skillmd---contextual-auto-loaded)
- [Instructions (.instructions.md) - Global, Always-Loaded](#instructions-instructionsmd---global-always-loaded)
- [Prompts (.prompt.md) - On-Demand, Explicit Invocation](#prompts-promptmd---on-demand-explicit-invocation)
- [Context Window Loading Behavior](#context-window-loading-behavior)
- [When to Use What](#when-to-use-what)
- [Real-World Example](#real-world-example)
- [Architecture Diagram](#architecture-diagram)

---

## The Key Difference

### Skills = Contextual Rules (Auto-Loaded When Relevant)
**Location**: `.github/.ai/skills/*.md` or `.cursor/skills/*.md`

**Loading**: 
- ✅ AI **automatically decides** when to load based on file context
- ✅ Only loaded when **file patterns match** (e.g., `*.cs`, `*.py`, `*.sql`)
- ✅ Only loaded when **description matches** current task
- ❌ Not loaded by default - **on-demand based on context**

**Use Case**: File-specific coding standards (e.g., "Use PascalCase for C# classes")

---

### Instructions = Global Rules (Always-Loaded)
**Location**: Would be in `.github/.ai/*.instructions.md` or `.cursor/*.instructions.md` (NOT actively used in this repo)

**Loading**:
- ✅ **Always loaded** into context for every AI interaction
- ✅ Loaded **regardless of file type** or task
- ✅ First thing in context window
- ⚠️ **Takes up context space even when not relevant**

**Use Case**: Universal rules that apply everywhere (e.g., "Never commit secrets")

**Status in This Repo**: 
- The README.md mentions `instructions/` directory with files like:
  - `csharp.instructions.md`
  - `dotnet-upgrade.instructions.md`
  - `sql-sp-generation.instructions.md`
- ⚠️ **These files don't currently exist** - they're legacy references
- Current architecture uses **SKILL.md** files instead for better context efficiency

---

### Prompts = On-Demand Commands (Explicit Invocation Only)
**Location**: `.github/prompts/*.prompt.md`

**Loading**:
- ❌ **Never auto-loaded** into context
- ✅ Only loaded when you **explicitly invoke** with `/command-name`
- ✅ Appears as slash command in Copilot Chat
- ✅ Zero context usage until invoked

**Use Case**: Complex, multi-step tasks you run occasionally (e.g., "Generate API client")

---

## Skills (SKILL.md) - Contextual, Auto-Loaded

### How Skills Work

**File Structure**:
```markdown
---
name: dotnet-backend
description: |
  .NET backend development standards. Use when writing C# services, 
  ASP.NET Core APIs, Entity Framework code, or .NET applications.
disposition: contextual
filePatterns:
  - "**/*.cs"
  - "**/*.csproj"
---

# .NET Backend Development Standards

- **MUST** target .NET 8+ for new projects
- **MUST** enable nullable reference types
- Classes **MUST** use PascalCase
...
```

### Loading Behavior

**When AI Loads This Skill**:
1. You open a `.cs` file (matches `filePatterns`)
2. OR you ask "how should I structure my C# service?" (matches `description`)
3. OR you're editing C# code and AI detects it's relevant

**When AI Doesn't Load This Skill**:
1. You're editing a Python file (`.py` doesn't match `filePatterns`)
2. You're editing JavaScript (description doesn't mention JS)
3. You're in a Terraform file (different context entirely)

**Context Window Impact**:
- ✅ Only loaded **when relevant** to current file/task
- ✅ Saves context space for other information
- ✅ Multiple skills can load if multiple contexts match (e.g., C# + security + testing)

### Example Skills in This Repo

| Skill | File Patterns | When Loaded |
|-------|---------------|-------------|
| **dotnet-backend** | `**/*.cs`, `**/*.csproj` | Editing C# files, asking about .NET |
| **python-backend** | `**/*.py`, `**/requirements.txt` | Editing Python files, asking about FastAPI |
| **terraform-infrastructure** | `**/*.tf`, `**/*.tfvars` | Editing Terraform files |
| **security-standards** | All files | When description mentions security, auth, encryption |
| **testing-standards** | `**/*Test.cs`, `**/*test.py` | Editing test files, asking about testing |

---

## Instructions (.instructions.md) - Global, Always-Loaded

### How Instructions Would Work (If Used)

**File Structure**:
```markdown
---
applies: global
priority: high
---

# Organization-Wide Security Standards

## Universal Rules

- **MUST NEVER** commit API keys, passwords, or secrets to Git
- **MUST** scan dependencies for known vulnerabilities
- **MUST** use HTTPS for all external communication
...
```

### Loading Behavior

**Always Loaded**:
- ✅ Every single AI interaction
- ✅ Every file you open
- ✅ Every question you ask
- ✅ First instructions in context window

**Context Window Impact**:
- ⚠️ **Always consumes context space** even when not relevant
- ⚠️ Can crowd out other relevant context
- ⚠️ Best for **truly universal rules** only

### Why This Repo Uses Skills Instead

**Problem with Instructions**:
```
Context Window (limited space):
├── [INSTRUCTIONS: 2000 tokens] (always loaded, even if editing Python)
├── [SKILL: C# Standards: 1500 tokens] (only when editing .cs)
├── [Your code: 3000 tokens]
└── [AI generation space: 2500 tokens]
```

**Better with Skills**:
```
Context Window (editing Python):
├── [SKILL: Python Standards: 1500 tokens] (contextual - only loaded for .py)
├── [SKILL: Security: 800 tokens] (contextual - loaded because code handles auth)
├── [Your code: 4000 tokens] (more space!)
└── [AI generation space: 3700 tokens] (more space!)
```

**Result**: More relevant context, better AI responses.

### Current Status in This Repo

The README mentions instruction files but they **don't exist**:
- ❌ `instructions/csharp.instructions.md` - Not found
- ❌ `instructions/dotnet-upgrade.instructions.md` - Not found
- ❌ `instructions/sql-sp-generation.instructions.md` - Not found

**Instead, this repo uses**:
- ✅ `skills/dotnet-backend/SKILL.md` (contextual C# standards)
- ✅ `skills/dotnet-upgrade/SKILL.md` (contextual upgrade guidance)
- ✅ `skills/sql-development/SKILL.md` (contextual SQL standards)

---

## Prompts (.prompt.md) - On-Demand, Explicit Invocation

### How Prompts Work

**File Structure**:
```markdown
---
description: 'Generate comprehensive copilot-instructions.md files'
mode: 'agent'
---

# Copilot Instructions Generator

## Configuration Variables
${PROJECT_TYPE="Auto-detect|.NET|Java|Python"} <!-- Primary technology -->

## Generated Prompt

"Generate a comprehensive copilot-instructions.md file...
...detailed instructions here...
"

## Expected Output

A comprehensive copilot-instructions.md file...
```

### Loading Behavior

**Never Auto-Loaded**:
- ❌ **Not loaded** when opening files
- ❌ **Not loaded** when asking general questions
- ✅ **Only loaded** when you type `/copilot-instructions-generator`

**Context Window Impact**:
- ✅ **Zero impact** until you invoke it
- ✅ Full context available when you need it
- ✅ Clean context for normal coding

### Example: Using a Prompt

**Before Invocation** (editing C# code):
```
Context Window:
├── [SKILL: dotnet-backend: 1500 tokens] (auto-loaded)
├── [SKILL: testing-standards: 800 tokens] (auto-loaded)
├── [Your code: 5000 tokens]
└── [AI generation space: remaining tokens]
```

**After Invocation** (`/api-architect`):
```
Context Window:
├── [PROMPT: api-architect: 3000 tokens] (you invoked it)
├── [SKILL: dotnet-backend: 1500 tokens] (still relevant)
├── [Your code: 3000 tokens] (less space, but you need the prompt)
└── [AI generation space: remaining tokens]
```

### Prompts in This Repo

| Prompt | Command | Use Case |
|--------|---------|----------|
| **copilot-instructions-generator** | `/copilot-instructions-generator` | Generate .github/copilot/instructions.md |
| **api-client-generator** | `/api-architect` | Generate REST API clients |
| **architecture-blueprint-generator** | `/architecture-blueprint` | Generate architecture docs |

---

## Context Window Loading Behavior

### Scenario 1: Editing a C# API Controller

**What Gets Loaded**:

1. **Skills** (Auto-Loaded):
   - ✅ `dotnet-backend/SKILL.md` (matches `*.cs` pattern)
   - ✅ `rest-api-standards/SKILL.md` (matches API-related code)
   - ✅ `security/secure-coding-enforcement/SKILL.md` (always relevant for production code)
   - ✅ `testing/unit-test-isolation/SKILL.md` (if test files present nearby)

2. **Instructions** (Would Be Always-Loaded, but not used in this repo):
   - N/A (this repo doesn't use instructions)

3. **Prompts** (Only If You Invoke):
   - ❌ Not loaded unless you type `/command-name`

**Total Context Usage**: ~3000-5000 tokens for skills (varies by file context)

---

### Scenario 2: Editing a Python FastAPI Service

**What Gets Loaded**:

1. **Skills** (Auto-Loaded):
   - ✅ `python-backend/SKILL.md` (matches `*.py` pattern)
   - ✅ `rest-api-standards/SKILL.md` (FastAPI is an API framework)
   - ✅ `security/secure-coding-enforcement/SKILL.md` (always relevant)
   - ❌ `dotnet-backend/SKILL.md` (not loaded - wrong language)
   - ❌ `terraform-infrastructure/SKILL.md` (not loaded - wrong context)

2. **Instructions** (Would Be Always-Loaded, but not used in this repo):
   - N/A

3. **Prompts** (Only If You Invoke):
   - ❌ Not loaded unless you type `/command-name`

**Total Context Usage**: ~2500-4000 tokens for skills (varies by file context)

---

### Scenario 3: Invoking a Prompt to Generate API Client

**What Gets Loaded**:

1. **Skills** (Auto-Loaded based on current file):
   - ✅ `dotnet-backend/SKILL.md` (if in .cs file)
   - ✅ `python-backend/SKILL.md` (if in .py file)

2. **Instructions** (Would Be Always-Loaded, but not used in this repo):
   - N/A

3. **Prompts** (You Explicitly Invoked):
   - ✅ `api-client-generator.prompt.md` (you typed `/api-architect`)

**Total Context Usage**: 
- Skills: ~1500-3000 tokens
- Prompt: ~2000-4000 tokens
- **Total**: ~3500-7000 tokens

---

## When to Use What

### Use **Skills** (SKILL.md) When:
- ✅ Rules apply to **specific file types** (e.g., C#, Python, Terraform)
- ✅ Rules are **contextual** (only relevant sometimes)
- ✅ You want **efficient context usage** (AI loads only when needed)
- ✅ Multiple developers work in **different languages/frameworks**

**Examples**:
- C# coding standards → `skills/dotnet-backend/SKILL.md`
- Python async patterns → `skills/python-backend/SKILL.md`
- SQL optimization rules → `skills/sql-development/SKILL.md`
- Terraform module patterns → `skills/terraform-infrastructure/SKILL.md`

---

### Use **Instructions** (.instructions.md) When:
- ✅ Rules apply to **EVERYTHING** regardless of file type
- ✅ Rules are **non-negotiable** organization-wide policies
- ✅ Context usage doesn't matter (rules must always be present)

**Examples**:
- "Never commit secrets" (applies to all files)
- "All code must pass security scan" (universal requirement)
- "PRs require 2 approvals" (process rule)

**⚠️ Caution**: 
- Instructions files **don't currently exist** in this repo
- Overuse can waste context space
- Consider if a skill with `disposition: always` would work instead

---

### Use **Prompts** (.prompt.md) When:
- ✅ Task is **complex** and multi-step
- ✅ Task is **occasional**, not constant
- ✅ Task requires **specific configuration** each time
- ✅ Task generates **large artifacts** (documentation, clients, schemas)

**Examples**:
- Generate comprehensive API client → `/api-architect`
- Generate copilot-instructions.md → `/copilot-instructions-generator`
- Analyze architecture → `/architecture-blueprint`
- Generate database schema docs → `/schema-generator`

---

## Real-World Example

### Developer Workflow: Building a C# Payment API

#### Step 1: Create API Controller (Skills Auto-Load)

**You open**: `src/PaymentService/Controllers/PaymentController.cs`

**AI Loads**:
```
Context Window:
├── [SKILL: dotnet-backend] (auto-loaded: *.cs file)
│   - Use .NET 8+, nullable types, PascalCase
│   - Dependency injection patterns
│   - Async/await best practices
│
├── [SKILL: rest-api-standards] (auto-loaded: "Controller" in name)
│   - RESTful endpoint naming
│   - HTTP status codes
│   - Error response format
│
├── [SKILL: secure-coding-enforcement] (auto-loaded: production code)
│   - Input validation
│   - Parameterized queries
│   - OWASP Top 10 prevention
│
└── [Your code + AI generation space]
```

**You type**: `// Create endpoint to process payment`

**AI Generates** (using all loaded skills):
```csharp
/// <summary>
/// Processes a payment transaction.
/// </summary>
/// <param name="request">Payment details.</param>
/// <param name="cancellationToken">Cancellation token.</param>
/// <returns>Payment confirmation.</returns>
[HttpPost("process")]
[ProducesResponseType(typeof(PaymentResponse), StatusCodes.Status200OK)]
[ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
public async Task<IActionResult> ProcessPayment(
    [FromBody] PaymentRequest request,
    CancellationToken cancellationToken)
{
    // Follows dotnet-backend skill: async/await, nullable types
    // Follows rest-api-standards skill: proper HTTP verbs, status codes
    // Follows secure-coding-enforcement skill: input validation
    
    if (!ModelState.IsValid)
        return BadRequest(new ErrorResponse { Message = "Invalid request" });
    
    var result = await _paymentService.ProcessAsync(request, cancellationToken);
    return Ok(result);
}
```

**Context Usage**: ~3000 tokens for skills

---

#### Step 2: Generate Unit Tests (Skills Auto-Load Different Ones)

**You open**: `tests/PaymentService.Tests/Controllers/PaymentControllerTests.cs`

**AI Loads** (different skills for test context):
```
Context Window:
├── [SKILL: dotnet-backend] (auto-loaded: *.cs file)
│   - C# coding standards still apply
│
├── [SKILL: unit-test-isolation] (auto-loaded: "*Tests.cs" file)
│   - Use xUnit with [Fact]
│   - Mock dependencies with Moq
│   - Arrange-Act-Assert pattern
│   - One assertion per test
│
├── [SKILL: fast-test-feedback] (auto-loaded: test file)
│   - Tests must run in < 100ms
│   - No external dependencies
│   - Use in-memory alternatives
│
└── [Your code + AI generation space]
```

**You type**: `// Test successful payment processing`

**AI Generates** (using test-specific skills):
```csharp
[Fact]
public async Task ProcessPayment_ValidRequest_ReturnsOkResult()
{
    // Arrange (follows unit-test-isolation skill)
    var request = new PaymentRequest { Amount = 100.00m };
    var mockService = new Mock<IPaymentService>();
    mockService
        .Setup(s => s.ProcessAsync(request, It.IsAny<CancellationToken>()))
        .ReturnsAsync(new PaymentResponse { TransactionId = "123" });
    
    var controller = new PaymentController(mockService.Object);
    
    // Act
    var result = await controller.ProcessPayment(request, CancellationToken.None);
    
    // Assert (follows fast-test-feedback skill: single assertion)
    var okResult = Assert.IsType<OkObjectResult>(result);
    var response = Assert.IsType<PaymentResponse>(okResult.Value);
    Assert.Equal("123", response.TransactionId);
}
```

**Context Usage**: ~4000 tokens for skills (different ones than production code)

---

#### Step 3: Generate API Documentation (Explicit Prompt Invocation)

**You type in chat**: `/architecture-blueprint`

**AI Loads** (prompt + relevant skills):
```
Context Window:
├── [PROMPT: architecture-blueprint-generator] (you invoked it: 3500 tokens)
│   - How to analyze codebase
│   - Mermaid diagram syntax
│   - Documentation structure
│
├── [SKILL: dotnet-backend] (still relevant: understanding C# code)
│   - 1500 tokens
│
└── [Your code + AI generation space]
```

**AI Generates**:
- Architecture overview
- Component diagrams
- API endpoint documentation
- Dependency graphs
- Security patterns documentation

**Context Usage**: ~5000 tokens (prompt + relevant skills)

---

#### Step 4: Normal Coding Resumes (Prompt Unloaded)

**You return to**: `PaymentController.cs` to add logging

**AI Loads** (back to normal):
```
Context Window:
├── [SKILL: dotnet-backend] (auto-loaded)
├── [SKILL: rest-api-standards] (auto-loaded)
├── [SKILL: secure-coding-enforcement] (auto-loaded)
└── [Your code + AI generation space]

(Prompt no longer loaded - context freed up)
```

**Context Usage**: Back to ~3000 tokens for skills

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│  Developer Workflow                                          │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
        ┌──────────────────────────────────────┐
        │   Opens File or Asks Question        │
        └──────────────────────────────────────┘
                            │
                            ▼
        ┌──────────────────────────────────────┐
        │   AI Analyzes Context                │
        │   - File extension (.cs, .py, .tf)   │
        │   - File path (test, controller)     │
        │   - Question content                 │
        └──────────────────────────────────────┘
                            │
              ┌─────────────┴─────────────┐
              ▼                           ▼
┌───────────────────────────┐   ┌──────────────────────────┐
│   SKILLS (Contextual)     │   │   PROMPTS (Explicit)     │
│   Auto-Load When Relevant │   │   Only Load When Invoked │
└───────────────────────────┘   └──────────────────────────┘
              │                           │
              │ Matches file pattern?     │ User typed /command?
              │ Matches description?      │
              ▼                           ▼
     ┌─────────────────┐         ┌─────────────────┐
     │  Load into       │         │  Load into      │
     │  Context Window  │         │  Context Window │
     └─────────────────┘         └─────────────────┘
              │                           │
              └──────────┬────────────────┘
                         ▼
            ┌────────────────────────┐
            │   AI Generates Code    │
            │   Using Loaded Rules   │
            └────────────────────────┘
```

### Context Window Lifecycle

```
┌─────────────────────────────────────────────────────────┐
│  Context Window (8K-128K tokens depending on model)      │
├─────────────────────────────────────────────────────────┤
│                                                           │
│  INSTRUCTIONS (if used): Always loaded                   │
│  ┌─────────────────────────────────────────────────┐   │
│  │ ⚠️ Takes space even when not relevant            │   │
│  │ Not used in this repo                            │   │
│  └─────────────────────────────────────────────────┘   │
│                                                           │
│  SKILLS: Loaded based on file context                   │
│  ┌─────────────────────────────────────────────────┐   │
│  │ ✅ dotnet-backend (editing .cs file)             │   │
│  │ ✅ rest-api-standards (API context)              │   │
│  │ ✅ security (always relevant)                    │   │
│  │ ❌ python-backend (not relevant now)             │   │
│  │ ❌ terraform (not relevant now)                  │   │
│  └─────────────────────────────────────────────────┘   │
│                                                           │
│  PROMPTS: Only if explicitly invoked                     │
│  ┌─────────────────────────────────────────────────┐   │
│  │ ❌ Not loaded (zero context usage)                │   │
│  │ ✅ Only loads when you type /command-name         │   │
│  └─────────────────────────────────────────────────┘   │
│                                                           │
│  YOUR CODE: Current file being edited                   │
│  ┌─────────────────────────────────────────────────┐   │
│  │ PaymentController.cs (3000 tokens)                │   │
│  └─────────────────────────────────────────────────┘   │
│                                                           │
│  AI GENERATION SPACE: Remaining tokens                  │
│  ┌─────────────────────────────────────────────────┐   │
│  │ Available for AI's response                       │   │
│  └─────────────────────────────────────────────────┘   │
│                                                           │
└─────────────────────────────────────────────────────────┘
```

---

## Summary Table

| Aspect | **Skills** (SKILL.md) | **Instructions** (.instructions.md) | **Prompts** (.prompt.md) |
|--------|----------------------|-------------------------------------|-------------------------|
| **Loading** | Auto-loaded based on context | Always loaded (if used) | Only when explicitly invoked |
| **Location** | `.github/.ai/skills/` | `.github/.ai/*.instructions.md` (not used here) | `.github/prompts/` |
| **Context Usage** | Contextual (only when relevant) | Always consumes space | Zero until invoked |
| **Trigger** | File patterns + description match | Always (global rules) | User types `/command` |
| **Use Case** | File-specific standards | Universal rules | Complex, occasional tasks |
| **Examples** | C# standards, Python patterns | "Never commit secrets" (unused) | Generate API client, docs |
| **This Repo Status** | ✅ Actively used (58 skills) | ❌ Not used (legacy references) | ✅ Actively used (7+ prompts) |

---

## Key Takeaways

1. **Skills are smart and efficient** - Only loaded when AI detects they're relevant to current file or task
2. **Instructions would be wasteful** - Always loaded means always consuming context, even when irrelevant
3. **Prompts are on-demand power tools** - Zero cost until you need them, then full power available
4. **This repo prioritizes Skills** - Better context efficiency, better AI responses
5. **Instructions are legacy** - Referenced in README but not actually implemented
6. **Context window is precious** - Skills and Prompts maximize its effectiveness

---

## Related Documentation

- [How to Use Custom Prompts](HOW-TO-USE-CUSTOM-PROMPTS.md) - Setup and use prompt files
- [.NET Backend Skills](../skills/HOW-TO-USE-SKILLS-DOTNET-BACKEND.md) - Example of SKILL.md usage
- [AWS Migration Skills](../skills/HOW-TO-USE-SKILLS-AWS-MIGRATION.md) - Another skill example
- [Main README](../../README.md) - Repository overview and skill catalog

---

**Last Updated**: January 30, 2026
**Feedback**: Found an issue or have suggestions? Open an issue in this repository.
