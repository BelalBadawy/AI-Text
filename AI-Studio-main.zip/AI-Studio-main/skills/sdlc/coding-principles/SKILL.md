---
name: coding-principles
description: |
  Core coding standards and best practices. Use when writing any code,
  refactoring, reviewing code quality, or discussing development patterns.
  Covers simplicity, DRY principles, testing workflow, and code organization.
disposition: always
version: 1.0.0
---

# Coding Standards and Best Practices

## Coding Pattern Preferences

- Simple solutions **MUST** always be preferred.
- Duplication of code **SHOULD** be avoided whenever possible.
- Developers **MUST** check for other areas of the codebase that might already
  have similar code and functionality.
- Existing code **SHOULD** be fixed rather than adding new, redundant code.
- Environment separation **MUST** be respected. Separate Dev, Test, and Prod
  environments **MUST** be maintained.
- Changes **MUST NOT** affect unrelated environments.
- Changes **MUST** only be made that are explicitly requested or are
  well-understood and related to the requested change.
- When fixing an issue or bug, a new pattern or technology **MUST NOT** be
  introduced without first exhausting all options for the existing
  implementation.
- If a new pattern is introduced, the old implementation **MUST** be removed
  afterward to avoid duplicate logic.
- The codebase **MUST** be kept clean and organized. Disorganization **MUST** be
  avoided.
- Files exceeding 200–300 lines of code **SHOULD** be refactored.
- Writing scripts and files **SHOULD** be avoided if possible, especially if the
  script is likely to be run only once. One-time scripts **SHOULD** be written
  inline or deleted after use.
- Mock or stub data **MUST NOT** be used in Dev or Prod environments; it
  **MUST** only be used in Test environments.
- Stubbing or fake data patterns **MUST NOT** be added to code that affects the
  Dev and Prod environments.

## Coding Workflow Preferences

- Developers **MUST** focus on areas of code relevant to the task at hand and
  **MUST** avoid modifying unrelated sections.
- Thorough tests **MUST** be written for all major functionality.
- A failing test **MUST** be written before implementing any functionality.
- Unit tests **MUST** be small and targeted, assessing only one aspect of the
  code.
- Test names **MUST** be descriptive and clearly explain the expected behavior.
- Major changes to the patterns and architecture of a feature that works well
  **MUST NOT** be made unless explicitly instructed.
- Developers **MUST** always consider what other methods and areas of code might
  be affected by code changes.

## Code Structure and Style

- The AAA (Arrange, Act, Assert) pattern **MUST** be implemented in all unit
  tests.
- Variable and function names **MUST** be meaningful and reflect their purpose.
- Functions **MUST** be kept small and focused on a single responsibility.

## Refactoring

- Refactoring to improve code quality **SHOULD** be performed after a test
  passes.
- Existing test coverage **MUST** be maintained during all refactoring efforts.

## Testing Best Practices

- Mocking for external dependencies in unit tests **MUST** be used.
- Tests **MUST** include edge cases and boundary conditions.
- Test fixtures and setup methods **SHOULD** be used for common test scenarios.

## Continuous Integration

- The entire test suite **MUST** be run before committing changes.
- New tests for new features **MUST** be added to the CI pipeline.

## Documentation

- Comments **SHOULD** be added to tests to explain the rationale behind specific
  test cases.
- Relevant documentation **MUST** be updated when making significant changes to
  the codebase.

## General Rules

- Tests **MUST** always be written before implementing functionality.
- A high standard of code quality **MUST** be maintained throughout the
  development process.
