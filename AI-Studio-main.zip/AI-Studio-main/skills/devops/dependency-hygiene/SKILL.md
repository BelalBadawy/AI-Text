---
name: dependency-hygiene
description: |
  Dependency management and vulnerability standards. Use when adding dependencies,
  updating packages, configuring dependency scanning, or reviewing security of
  third-party libraries. Covers version pinning, CVE thresholds, and SBOM generation.
disposition: contextual
filePatterns:
  - "**/pom.xml"
  - "**/build.gradle*"
  - "**/package.json"
  - "**/requirements.txt"
  - "**/*.csproj"
  - "**/Directory.Packages.props"
compliance:
  - soc2: CC7.1
  - iso27001: A.12.6.1
  - gdpr: Art.32
version: 1.0.0
---

# Enforce Dependency Hygiene and Vulnerability Thresholds

## Description

This rule mandates that all third-party dependencies must use version-locked
declarations and must not contain known vulnerabilities rated CVSS 7.0 or
higher. Builds that include such dependencies are blocked from proceeding to
production.

## Purpose

To minimize software supply chain risks, prevent known vulnerable packages from
being deployed, and ensure reproducibility of builds through strict version
locking. This supports secure SDLC practices and regulatory compliance.

## Scope

- Java (Maven/Gradle), JavaScript (npm/yarn), Python (pip/requirements), .NET (NuGet)
- Applies to all application repositories
- CI pipelines that build and deploy production artifacts
- DevSecOps, backend engineers, and maintainers

## SDLC Integration

- **Planning**: Dependencies reviewed during backlog grooming
- **Analysis**: CVE risks identified through vulnerability databases
- **Design**: Encourages modular upgrades and pinning
- **Development**: Fails builds with high-severity CVEs
- **Testing**: Validates locked versions and risk thresholds
- **Deployment**: Only compliant builds are released
- **Maintenance**: Alerts for outdated or risky packages via bots

## Standards

### Third-Party Dependency Management

- All external dependencies **MUST** have locked (pinned) version numbers
- No package with a known vulnerability **MAY** be promoted to production if
  CVSS ≥ 7.0
- Automated scanning tools **MUST** evaluate dependency CVEs during every build
- Pull requests with dependency changes **SHOULD** include changelog/release
  notes review

## Actionable Metrics

| Metric                            | Target Value                            | Measurement Method                                                        | Enforcement Level |
| --------------------------------- | --------------------------------------- | ------------------------------------------------------------------------- | ----------------- |
| Pinned versions coverage          | 100 %                                   | CI lint checks lockfiles and forbids wildcards (`*`, `^`, `~`, `latest`)  | **MUST**          |
| High/Critical CVE gate            | 0 dependencies with CVSS ≥ 7.0 allowed  | Software composition analysis (SCA) scan fails build on ≥ 7.0 CVEs        | **MUST**          |
| Automated CVE scanning coverage   | 100 %                                   | Workflow asserts SCA step present and successful on every PR/main build   | **MUST**          |
| Changelog/release notes reviewed  | Link present for each dependency change | PR template checkbox + bot verifies manifest diffs include changelog link | **MUST**          |
