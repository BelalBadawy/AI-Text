---
name: ci-build-integrity
description: |
  CI build integrity and SBOM requirements. Use when configuring CI pipelines,
  setting up artifact signing, or implementing supply chain security. Covers
  immutable builds, SBOM generation, and build provenance.
disposition: contextual
filePatterns:
  - .github/workflows/**
  - "**/Dockerfile"
  - "**/build.gradle*"
  - "**/pom.xml"
compliance:
  - soc2: CC7.2
  - iso27001: A.14.2.1
  - gdpr: Art.5(1)(d)
version: 1.0.0
---

# Enforce Immutable CI Builds and Signed SBOM Generation

## Description

This rule enforces that all merges into protected branches must trigger a CI
build that is successful, reproducible, and generates a signed Software Bill of
Materials (SBOM). This ensures build artifact integrity and supply chain
transparency.

## Purpose

To protect the software supply chain by ensuring all deployed artifacts
originate from trusted CI pipelines. This helps trace back build inputs and
maintain compliance with software provenance standards.

## Scope

- Protected branches in all repositories
- CI configurations (GitHub Actions, GitLab CI, etc.)
- Docker builds and package publishing pipelines
- Applies to DevOps, backend engineers, and build infrastructure

## SDLC Integration

- **Planning**: Teams must define build integrity and provenance requirements
- **Analysis**: Incorporates risk assessment of build processes
- **Design**: Enforces CI pipeline templates for consistency
- **Development**: All code merges trigger signed builds
- **Testing**: Ensures SBOM and CI checks validate change impact
- **Deployment**: Only immutable, SBOM-backed artifacts are deployed
- **Maintenance**: Tracks historic build records for auditability

## Standards

### CI and Supply Chain Enforcement

- Every merge to a protected branch **MUST** trigger a CI build
- CI build **MUST** complete successfully and produce versioned artifacts
- An SBOM **MUST** be generated, signed, and attached to each artifact
- CI builds **SHOULD NOT** be rerunnable without a commit change (immutable
  builds)

## Actionable Metrics

| Metric                  | Target Value | Measurement Method         | Enforcement Level |
| ----------------------- | ------------ | -------------------------- | ----------------- |
| CI build success rate   | ≥ 99 %       | Pipeline analytics logs    | **MUST**          |
| SBOM presence in builds | 100 %        | Artifact metadata audit    | **MUST**          |
| Mutable builds detected | 0            | Build hash diff inspection | **MUST**          |

## Implementation

### Configuration Requirements

- Add SBOM generation to CI (CycloneDX, Syft, Trivy)
- Configure artifact signing and CI status enforcement
- Fail builds if SBOM is missing or CI check fails

#### Example: Correct Implementation

```yaml
# .github/workflows/ci.yml
name: CI Build with SBOM

on:
  push:
    branches: [main, develop]
  pull_request:

jobs:
  build:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      id-token: write

    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Set up build environment
        uses: actions/setup-node@v4
        with:
          node-version: '20'

      - name: Install dependencies
        run: npm ci

      - name: Run tests
        run: npm test

      - name: Build application
        run: npm run build

      - name: Generate SBOM
        uses: anchore/sbom-action@v0
        with:
          format: cyclonedx-json
          output-file: sbom.json

      - name: Install Cosign
        uses: sigstore/cosign-installer@v3

      - name: Sign SBOM with keyless signing
        run: |
          # Uses keyless signing with OIDC identity (requires id-token permission)
          cosign sign-blob --yes --output-signature sbom.json.sig \
            --bundle sbom.json.bundle sbom.json

      - name: Upload SBOM
        uses: actions/upload-artifact@v4
        with:
          name: sbom
          path: |
            sbom.json
            sbom.json.sig
            sbom.json.bundle
          retention-days: 90
```
