---
name: secure-coding-enforcement
description: |
  Security scanning and secure coding enforcement. Use when setting up SAST tools,
  fixing security vulnerabilities, or configuring security gates in CI. Covers
  OWASP Top 10, CWE violations, and automated security scanning.
disposition: contextual
filePatterns:
  - "**/*.cs"
  - "**/*.kt"
  - "**/*.ts"
  - "**/*.js"
  - "**/*.py"
  - "**/*.cs"
compliance:
  - soc2: CC7.1
  - iso27001: A.14.2.5
  - gdpr: Art.32
version: 1.0.0
---

# Enforce Secure Coding via Automated Scanning

## Description

This rule requires all pull requests to be scanned using automated security
tools, ensuring that no high-severity vulnerabilities from the OWASP Top 10 or
CWE are introduced. The rule blocks merging if any such violations are detected.

## Purpose

To protect enterprise systems and customer data by preventing known critical
vulnerabilities—such as injection flaws, broken authentication, and insecure
deserialization—from reaching production. It operationalizes “secure-by-default”
principles in the SDLC.

## Scope

- Application and backend source code
- Pull requests for all critical services
- Applies to all development teams
- Enforced via CI-integrated security scanners

## SDLC Integration

- **Planning**: Security requirements baked into stories and acceptance criteria
- **Analysis**: Identifies sensitive data flows or risky components
- **Design**: Encourages secure design patterns
- **Development**: Detects violations early using scanners
- **Testing**: Validates zero high-severity issues before merge
- **Deployment**: Prevents risky code from reaching production
- **Maintenance**: Audits regressions and scanner coverage

## Standards

### Secure Development Requirements

- Code **MUST** contain zero high-severity OWASP Top 10 or CWE violations before
  merge
- Security scanning tools **MUST** be run on every pull request
- Common injection risks (e.g., SQLi, XSS) **MUST NOT** appear in committed code
- Known vulnerable patterns (e.g., string-concatenated SQL) **SHOULD** be
  flagged by AI/code reviewers

## Actionable Metrics

| Metric                        | Target Value | Measurement Method          | Enforcement Level |
| ----------------------------- | ------------ | --------------------------- | ----------------- |
| High-severity findings per PR | 0            | Security scanner reports    | **MUST**          |
| PRs scanned before merge      | 100 %        | CI logs, PR status checks   | **MUST**          |
| False positive rate           | ≤ 5 %        | Manual review feedback loop | **SHOULD**        |

## Implementation

### Configuration Requirements

- Integrate scanners such as SonarQube, Semgrep, Snyk, or GitHub CodeQL
- Block PRs if high-severity issues are reported

#### Example: Correct Implementation (Java)

```java
// Parameterized SQL with safe binding
PreparedStatement stmt = conn.prepareStatement("SELECT * FROM users WHERE id = ?");
stmt.setInt(1, userId);
```

#### Example: Correct Implementation (C#/.NET)

```csharp
// Entity Framework Core - parameterized by default
var user = await context.Users
    .Where(u => u.Id == userId)
    .FirstOrDefaultAsync();

// Dapper - parameterized query
var user = await connection.QuerySingleOrDefaultAsync<User>(
    "SELECT * FROM Users WHERE Id = @Id",
    new { Id = userId });

// Raw SQL with EF Core - parameterized
var users = await context.Users
    .FromSqlInterpolated($"SELECT * FROM Users WHERE Email = {email}")
    .ToListAsync();
```
