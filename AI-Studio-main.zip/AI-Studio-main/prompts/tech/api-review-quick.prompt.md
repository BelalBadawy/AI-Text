# Quick API Review Checklist

Perform a rapid assessment of the provided API code against .NET API best practices.

## What to Review

Analyze the code and provide a structured review covering:

### 1. RESTful Design (Critical)
- Resource naming (plural nouns: /users, /orders)
- HTTP verbs correct (GET for read, POST for create, PUT for update, DELETE for delete)
- Status codes appropriate (200, 201, 204, 400, 404, 409, 500)
- URI structure clean and logical

### 2. Security (Critical)
- Authentication present ([Authorize] attributes)
- Input validation (model validation, range checks)
- No sensitive data in responses
- CORS configured if needed
- SQL injection protection (parameterized queries)

### 3. Error Handling (High Priority)
- Global exception middleware
- ProblemDetails for errors (RFC 7807)
- Consistent error format
- Appropriate status codes
- No stack traces in production responses

### 4. Performance (High Priority)
- Async/await used correctly
- No blocking calls (.Result, .Wait())
- DTOs used (not exposing entities)
- Pagination for large collections
- No obvious N+1 query issues

### 5. Code Quality (Medium Priority)
- Controllers thin (delegating to services)
- Dependency injection used
- Proper separation of concerns
- Clear naming conventions
- XML documentation on public methods

### 6. API Documentation (Medium Priority)
- Swagger/OpenAPI configured
- Route templates clear
- Response types documented ([ProducesResponseType])

## Output Format

Provide results as:

```
🎯 Quick API Review Results

✅ PASSING:
- [list what's done well]

⚠️ WARNINGS:
- [list issues that should be fixed]

❌ CRITICAL ISSUES:
- [list security/major problems]

💡 RECOMMENDATIONS:
- [list improvements]

📊 Overall Score: [X/10]
```

## Keep It Concise

- Focus on actionable feedback
- Prioritize security and critical issues
- Provide specific code examples for issues
- Limit to most important 5-7 points
- This is a QUICK review, not exhaustive














