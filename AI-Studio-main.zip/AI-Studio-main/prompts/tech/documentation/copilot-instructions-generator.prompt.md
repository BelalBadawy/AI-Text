---
description: 'Technology-agnostic blueprint generator for creating comprehensive copilot-instructions.md files that guide GitHub Copilot to produce code consistent with project standards, architecture patterns, and exact technology versions by analyzing existing codebase patterns and avoiding assumptions.'
mode: 'agent'
---

# Copilot Instructions Blueprint Generator

## Configuration Variables
${PROJECT_TYPE="Auto-detect|.NET|Java|JavaScript|TypeScript|React|Angular|Python|SQL|Multiple|Other"} <!-- Primary technology -->
${ARCHITECTURE_STYLE="Layered|Microservices|Monolithic|Domain-Driven|Event-Driven|Serverless|Mixed"} <!-- Architectural approach -->
${CODE_QUALITY_FOCUS="Maintainability|Performance|Security|Accessibility|Testability|All"} <!-- Quality priorities -->
${DOCUMENTATION_LEVEL="Minimal|Standard|Comprehensive"} <!-- Documentation requirements -->
${TESTING_REQUIREMENTS="Unit|Integration|E2E|TDD|BDD|All"} <!-- Testing approach -->
${VERSIONING="Semantic|CalVer|Custom"} <!-- Versioning approach -->

## Generated Prompt

"Generate a comprehensive copilot-instructions.md file that will guide GitHub Copilot to produce code consistent with our project's standards, architecture, and technology versions. The instructions must be strictly based on actual code patterns in our codebase and avoid making any assumptions. Follow this approach:

### 1. Core Instruction Structure

```markdown
# GitHub Copilot Instructions

## Priority Guidelines

When generating code for this repository:

1. **Version Compatibility**: Always detect and respect the exact versions of languages, frameworks, and libraries used in this project
2. **Context Files**: Prioritize patterns and standards defined in the .github/copilot directory
3. **Codebase Patterns**: When context files don't provide specific guidance, scan the codebase for established patterns
4. **Architectural Consistency**: Maintain our ${ARCHITECTURE_STYLE} architectural style and established boundaries
5. **Code Quality**: Prioritize ${CODE_QUALITY_FOCUS == "All" ? "maintainability, performance, security, accessibility, and testability" : CODE_QUALITY_FOCUS} in all generated code

## Technology Version Detection

Before generating code, scan the codebase to identify:

1. **Language Versions**: Detect the exact versions of programming languages in use
   - Examine project files, configuration files, and package managers
   - Look for language-specific version indicators (e.g., <LangVersion> in .NET projects)
   - Never use language features beyond the detected version

2. **Framework Versions**: Identify the exact versions of all frameworks
   - Check package.json, .csproj, pom.xml, requirements.txt, etc.
   - Respect version constraints when generating code
   - Never suggest features not available in the detected framework versions

3. **Database Versions**: For SQL projects, identify the exact SQL Server version and compatibility level
   - Examine .sqlproj files for TargetDatabaseSet and compatibility level
   - Check for SQL Server version-specific features in use (e.g., temporal tables, graph tables)
   - Never use T-SQL features not available in the detected SQL Server version

4. **Library Versions**: Note the exact versions of key libraries and dependencies
   - Generate code compatible with these specific versions
   - Never use APIs or features not available in the detected versions

## Context Files

Prioritize the following files in .github/copilot directory (if they exist):

- **architecture.md**: System architecture guidelines
- **tech-stack.md**: Technology versions and framework details
- **coding-standards.md**: Code style and formatting standards
- **folder-structure.md**: Project organization guidelines
- **exemplars.md**: Exemplary code patterns to follow
- **database-schema.md**: Database schema diagrams and relationship guidelines (for SQL projects)
- **sql-naming-conventions.md**: Database object naming standards (for SQL projects)

## Codebase Scanning Instructions

When context files don't provide specific guidance:

1. Identify similar files to the one being modified or created
2. Analyze patterns for:
   - Naming conventions
   - Code organization
   - Error handling
   - Logging approaches
   - Documentation style
   - Testing patterns
   
3. Follow the most consistent patterns found in the codebase
4. When conflicting patterns exist, prioritize patterns in newer files or files with higher test coverage
5. Never introduce patterns not found in the existing codebase

## Code Quality Standards

${CODE_QUALITY_FOCUS.includes("Maintainability") || CODE_QUALITY_FOCUS == "All" ? `### Maintainability
- Write self-documenting code with clear naming
- Follow the naming and organization conventions evident in the codebase
- Follow established patterns for consistency
- Keep functions focused on single responsibilities
- Limit function complexity and length to match existing patterns` : ""}

${CODE_QUALITY_FOCUS.includes("Performance") || CODE_QUALITY_FOCUS == "All" ? `### Performance
- Follow existing patterns for memory and resource management
- Match existing patterns for handling computationally expensive operations
- Follow established patterns for asynchronous operations
- Apply caching consistently with existing patterns
- Optimize according to patterns evident in the codebase` : ""}

${CODE_QUALITY_FOCUS.includes("Security") || CODE_QUALITY_FOCUS == "All" ? `### Security
- Follow existing patterns for input validation
- Apply the same sanitization techniques used in the codebase
- Use parameterized queries matching existing patterns
- Follow established authentication and authorization patterns
- Handle sensitive data according to existing patterns` : ""}

${CODE_QUALITY_FOCUS.includes("Accessibility") || CODE_QUALITY_FOCUS == "All" ? `### Accessibility
- Follow existing accessibility patterns in the codebase
- Match ARIA attribute usage with existing components
- Maintain keyboard navigation support consistent with existing code
- Follow established patterns for color and contrast
- Apply text alternative patterns consistent with the codebase` : ""}

${CODE_QUALITY_FOCUS.includes("Testability") || CODE_QUALITY_FOCUS == "All" ? `### Testability
- Follow established patterns for testable code
- Match dependency injection approaches used in the codebase
- Apply the same patterns for managing dependencies
- Follow established mocking and test double patterns
- Match the testing style used in existing tests` : ""}

## Documentation Requirements

${DOCUMENTATION_LEVEL == "Minimal" ? 
`- Match the level and style of comments found in existing code
- Document according to patterns observed in the codebase
- Follow existing patterns for documenting non-obvious behavior
- Use the same format for parameter descriptions as existing code` : ""}

${DOCUMENTATION_LEVEL == "Standard" ? 
`- Follow the exact documentation format found in the codebase
- Match the XML/JSDoc style and completeness of existing comments
- Document parameters, returns, and exceptions in the same style
- Follow existing patterns for usage examples
- Match class-level documentation style and content` : ""}

${DOCUMENTATION_LEVEL == "Comprehensive" ? 
`- Follow the most detailed documentation patterns found in the codebase
- Match the style and completeness of the best-documented code
- Document exactly as the most thoroughly documented files do
- Follow existing patterns for linking documentation
- Match the level of detail in explanations of design decisions` : ""}

## Testing Approach

${TESTING_REQUIREMENTS.includes("Unit") || TESTING_REQUIREMENTS == "All" ? 
`### Unit Testing
- Match the exact structure and style of existing unit tests
- Follow the same naming conventions for test classes and methods
- Use the same assertion patterns found in existing tests
- Apply the same mocking approach used in the codebase
- Follow existing patterns for test isolation` : ""}

${TESTING_REQUIREMENTS.includes("Integration") || TESTING_REQUIREMENTS == "All" ? 
`### Integration Testing
- Follow the same integration test patterns found in the codebase
- Match existing patterns for test data setup and teardown
- Use the same approach for testing component interactions
- Follow existing patterns for verifying system behavior` : ""}

${TESTING_REQUIREMENTS.includes("E2E") || TESTING_REQUIREMENTS == "All" ? 
`### End-to-End Testing
- Match the existing E2E test structure and patterns
- Follow established patterns for UI testing
- Apply the same approach for verifying user journeys` : ""}

${TESTING_REQUIREMENTS.includes("TDD") || TESTING_REQUIREMENTS == "All" ? 
`### Test-Driven Development
- Follow TDD patterns evident in the codebase
- Match the progression of test cases seen in existing code
- Apply the same refactoring patterns after tests pass` : ""}

${TESTING_REQUIREMENTS.includes("BDD") || TESTING_REQUIREMENTS == "All" ? 
`### Behavior-Driven Development
- Match the existing Given-When-Then structure in tests
- Follow the same patterns for behavior descriptions
- Apply the same level of business focus in test cases` : ""}

## Technology-Specific Guidelines

${PROJECT_TYPE == ".NET" || PROJECT_TYPE == "Auto-detect" || PROJECT_TYPE == "Multiple" ? `### .NET Guidelines
- Detect and strictly adhere to the specific .NET version in use
- Use only C# language features compatible with the detected version
- Follow LINQ usage patterns exactly as they appear in the codebase
- Match async/await usage patterns from existing code
- Apply the same dependency injection approach used in the codebase
- Use the same collection types and patterns found in existing code` : ""}

${PROJECT_TYPE == "Java" || PROJECT_TYPE == "Auto-detect" || PROJECT_TYPE == "Multiple" ? `### Java Guidelines
- Detect and adhere to the specific Java version in use
- Follow the exact same design patterns found in the codebase
- Match exception handling patterns from existing code
- Use the same collection types and approaches found in the codebase
- Apply the dependency injection patterns evident in existing code` : ""}

${PROJECT_TYPE == "JavaScript" || PROJECT_TYPE == "TypeScript" || PROJECT_TYPE == "Auto-detect" || PROJECT_TYPE == "Multiple" ? `### JavaScript/TypeScript Guidelines
- Detect and adhere to the specific ECMAScript/TypeScript version in use
- Follow the same module import/export patterns found in the codebase
- Match TypeScript type definitions with existing patterns
- Use the same async patterns (promises, async/await) as existing code
- Follow error handling patterns from similar files` : ""}

${PROJECT_TYPE == "React" || PROJECT_TYPE == "Auto-detect" || PROJECT_TYPE == "Multiple" ? `### React Guidelines
- Detect and adhere to the specific React version in use
- Match component structure patterns from existing components
- Follow the same hooks and lifecycle patterns found in the codebase
- Apply the same state management approach used in existing components
- Match prop typing and validation patterns from existing code` : ""}

${PROJECT_TYPE == "Angular" || PROJECT_TYPE == "Auto-detect" || PROJECT_TYPE == "Multiple" ? `### Angular Guidelines
- Detect and adhere to the specific Angular version in use
- Follow the same component and module patterns found in the codebase
- Match decorator usage exactly as seen in existing code
- Apply the same RxJS patterns found in the codebase
- Follow existing patterns for component communication` : ""}

${PROJECT_TYPE == "Python" || PROJECT_TYPE == "Auto-detect" || PROJECT_TYPE == "Multiple" ? `### Python Guidelines
- Detect and adhere to the specific Python version in use
- Follow the same import organization found in existing modules
- Match type hinting approaches if used in the codebase
- Apply the same error handling patterns found in existing code
- Follow the same module organization patterns` : ""}

${PROJECT_TYPE == "SQL" || PROJECT_TYPE == "Auto-detect" || PROJECT_TYPE == "Multiple" ? `### SQL Server Database (.sqlproj) Guidelines

#### Version Detection and Compatibility
- Detect SQL Server version from .sqlproj files (TargetDatabaseSet, DacVersion)
- Identify database compatibility level (110=SQL 2012, 120=SQL 2014, 130=SQL 2016, 140=SQL 2017, 150=SQL 2019, 160=SQL 2022)
- Never use T-SQL features not available in the detected version
- Respect SQL Server edition limitations (Standard vs Enterprise features)

#### Naming Conventions
Analyze existing database objects to identify patterns for:

**Tables**:
- Singular vs plural naming (e.g., Customer vs Customers)
- PascalCase vs snake_case (e.g., CustomerOrder vs customer_order)
- Prefix patterns (e.g., tbl_, t_) if used
- Schema naming patterns (dbo, app, audit, etc.)

**Columns**:
- PascalCase vs camelCase vs snake_case
- Boolean column prefixes (Is, Has, Can, Should)
- Date/time column suffixes (Date, DateTime, UTC, At)
- ID column patterns (ID, Id, _ID, _Id)

**Primary Keys**:
- Naming pattern (PK_TableName, TableName_PK, etc.)
- Single vs composite key patterns
- Identity vs GUID vs custom sequences

**Foreign Keys**:
- Naming pattern (FK_ChildTable_ParentTable, FK_Child_Parent_ColumnName, etc.)
- ON DELETE and ON UPDATE cascade patterns
- Indexing patterns for foreign keys

**Indexes**:
- Clustered index patterns (IX_TableName_PK, PK_TableName)
- Non-clustered index patterns (IX_TableName_ColumnNames, IDX_Table_Columns)
- Unique index patterns (UX_TableName_ColumnNames)
- Filtered index patterns and usage
- Columnstore index patterns (if used)

**Stored Procedures**:
- Prefix patterns (usp_, sp_, proc_, p_)
- Action-based naming (Get, Create, Update, Delete, Upsert, Search)
- Schema qualification patterns
- Parameter naming conventions (@paramName, @p_paramName)

**Functions**:
- Scalar function prefixes (fn_, ufn_, f_)
- Table-valued function prefixes (tvf_, ftv_, tf_)
- Inline vs multi-statement patterns
- Return value naming conventions

**Views**:
- Prefix patterns (vw_, v_, view_)
- Materialized view patterns (indexed views)
- Naming based on purpose (reporting, denormalization)

**Triggers**:
- Prefix patterns (tr_, trg_, trigger_)
- Event naming (Insert, Update, Delete, InsteadOf)
- Audit trigger patterns

**Constraints**:
- Default constraint naming (DF_TableName_ColumnName)
- Check constraint naming (CK_TableName_ColumnName or CK_TableName_LogicDescription)
- Unique constraint naming (UQ_TableName_ColumnName)

#### Schema Organization
- Identify schema separation patterns (transactional, reporting, audit, security)
- Follow established schema-based access control patterns
- Match schema ownership and permission patterns
- Document cross-schema dependency patterns

#### Data Types and Standards
- Follow existing patterns for data type choices (VARCHAR vs NVARCHAR, INT vs BIGINT)
- Match precision and scale patterns for DECIMAL/NUMERIC columns
- Follow date/time type standards (DATE, DATETIME, DATETIME2, DATETIMEOFFSET)
- Apply MAX vs specific length patterns for VARCHAR/NVARCHAR
- Follow GUID storage patterns (UNIQUEIDENTIFIER vs VARCHAR(36))

#### NULL and Default Patterns
- Follow NULL vs NOT NULL patterns by column type
- Match default value patterns (GETDATE(), GETUTCDATE(), NEWID(), etc.)
- Apply computed column patterns
- Follow patterns for handling optional foreign keys

#### T-SQL Coding Standards
- Follow keyword capitalization patterns (UPPERCASE, lowercase, or PascalCase)
- Match indentation and formatting style from existing procedures
- Apply consistent comma placement (leading vs trailing)
- Follow JOIN syntax patterns (INNER JOIN vs FROM x, y WHERE)
- Match subquery vs CTE preferences
- Follow variable declaration patterns (declare at top vs inline)

#### Error Handling
- Match TRY/CATCH usage patterns from existing code
- Follow THROW vs RAISERROR patterns based on SQL version
- Apply transaction rollback patterns consistently
- Match error logging approaches (error tables, extended events)
- Follow error message formatting standards

#### Transaction Management
- Follow explicit transaction patterns (BEGIN/COMMIT/ROLLBACK)
- Match isolation level patterns (READ COMMITTED, SNAPSHOT, etc.)
- Apply savepoint patterns if used
- Follow distributed transaction patterns (if applicable)

#### Performance Patterns
- Match indexing strategies from existing tables
- Follow query hint usage patterns (NOLOCK, RECOMPILE, OPTIMIZE FOR)
- Apply table hint patterns (WITH (UPDLOCK), WITH (ROWLOCK))
- Follow partition patterns if partitioning is used
- Match columnstore usage patterns if present
- Apply query plan forcing patterns if Query Store is used

#### Security Patterns
- Follow GRANT/REVOKE/DENY patterns for permissions
- Match row-level security patterns if RLS is implemented
- Apply dynamic data masking patterns if used
- Follow Always Encrypted patterns if present
- Match service account and application role patterns

#### Advanced Features (if detected)
- **Temporal Tables**: Match system-versioned table patterns
- **Graph Tables**: Follow NODE and EDGE table patterns
- **In-Memory OLTP**: Apply memory-optimized table patterns
- **JSON Support**: Match JSON parsing and generation patterns
- **Full-Text Search**: Follow FTS catalog and index patterns
- **Change Data Capture**: Apply CDC patterns if enabled
- **Service Broker**: Match queue and message patterns if used

#### Migration and Versioning
- Follow migration script patterns (idempotent vs sequential)
- Match schema version tracking approaches
- Apply rollback script patterns
- Follow pre/post-deployment script organization
- Match script naming conventions for ordering

#### Dependencies and References
- Identify and document dependencies on:
  - SQL Server Data Tools (SSDT) version
  - DacFx version
  - CLR assemblies (if used)
  - Linked server dependencies
  - External data sources
  - Extended stored procedures
  - SQL Server Agent jobs
  - Integration Services packages
  - Reporting Services reports
  - Analysis Services models

#### Documentation Patterns
- Match SQL comment styles (-- single line, /* */ multi-line)
- Follow header block patterns for stored procedures and functions
- Apply inline documentation standards
- Match parameter documentation approaches
- Follow change history documentation patterns

#### Testing Patterns

**Unit Testing Frameworks**:
- Identify testing framework in use (tSQLt, utPLSQL, DBUnit, SQLTest)
- Match framework-specific patterns and conventions
- Follow existing test installation and configuration patterns

**tSQLt Unit Testing** (if detected):

*Test Class Organization*:
- Follow test class naming conventions (e.g., [TestClassName], TestClassName)
- Match schema-based test organization patterns
- Apply test class grouping strategies (by feature, by stored procedure, by table)
- Follow test suite organization patterns

*Test Procedure Naming*:
- Match test naming conventions:
  - Pattern examples: test_ProcedureName_Scenario, test Should_ExpectedBehavior_When_Condition
  - Prefix patterns: test, test_, ut_, usp_test
- Follow action-condition-result naming patterns
- Apply descriptive scenario-based naming

*Test Setup and Teardown*:
- Match setup procedure patterns (SetUp, Before, Initialize)
- Follow teardown patterns (TearDown, After, Cleanup)
- Apply test fixture patterns for reusable setup
- Follow database state reset patterns

*Test Isolation*:
- Follow transaction isolation patterns (automatic rollback after each test)
- Match FakeTable and FakeFunction usage patterns
- Apply SpyProcedure patterns for testing dependencies
- Follow table mocking and stubbing approaches
- Match test data cleanup strategies

*Assertion Patterns*:
- Follow existing assertion procedures:
  - tSQLt.AssertEquals for value comparison
  - tSQLt.AssertEqualsTable for result set comparison
  - tSQLt.AssertEmptyTable for empty result validation
  - tSQLt.AssertObjectExists / AssertObjectDoesNotExist
  - tSQLt.Fail for explicit failures
  - tSQLt.ExpectException for error testing
  - tSQLt.ExpectNoException for success validation
- Match custom assertion pattern implementations
- Follow assertion message formatting standards

*Test Data Generation*:
- Follow test data creation patterns (inline INSERT, setup procedures, data files)
- Match synthetic data generation approaches
- Apply boundary value testing patterns (min/max/null values)
- Follow equivalence partitioning patterns
- Match test data volume patterns (single row, small set, large dataset)

*Dependency Mocking*:
- Follow FakeTable patterns for table mocking:
  - Preserve structure vs simplified structure
  - Identity columns vs standard columns
  - Constraint preservation patterns
- Match FakeFunction patterns for function stubbing
- Apply SpyProcedure patterns for tracking calls
- Follow external dependency mocking (linked servers, external APIs)

*Testing Stored Procedures*:
- Match patterns for testing procedure logic
- Follow parameter validation testing patterns
- Apply expected result set comparison patterns
- Match error handling testing approaches
- Follow transaction behavior testing patterns

*Testing Functions*:
- Follow scalar function testing patterns (input/output validation)
- Match table-valued function testing patterns (result set comparison)
- Apply edge case testing patterns (NULL, empty string, extreme values)

*Testing Views*:
- Match view result validation patterns
- Follow view performance testing patterns
- Apply view security testing patterns

*Testing Triggers*:
- Follow trigger behavior validation patterns
- Match INSERTED/DELETED table testing approaches
- Apply cascading trigger testing patterns
- Follow trigger error handling testing patterns

*Integration Testing*:
- Match end-to-end workflow testing patterns
- Follow multi-table transaction testing approaches
- Apply cross-schema operation testing patterns
- Match stored procedure chain testing patterns

*Performance Testing*:
- Follow execution time assertion patterns
- Match resource usage testing approaches (I/O, memory)
- Apply query plan validation patterns
- Follow index usage verification patterns

*Security Testing*:
- Match permission testing patterns (EXECUTE AS patterns)
- Follow row-level security testing approaches
- Apply dynamic data masking validation patterns
- Match encryption/decryption testing patterns

*Test Organization*:
- Follow test schema organization (e.g., tSQLt schema, test schema, dedicated test database)
- Match test categorization patterns (unit, integration, smoke, regression)
- Apply test tagging or naming for selective execution
- Follow test dependency ordering patterns

*Test Execution*:
- Match test runner invocation patterns (EXEC tSQLt.RunAll, EXEC tSQLt.Run)
- Follow selective test execution patterns (by class, by tag)
- Apply CI/CD integration patterns for automated testing
- Match test result reporting formats (XML, JSON, console output)

*Test Documentation*:
- Follow test documentation patterns in comments
- Match Given-When-Then or Arrange-Act-Assert structure in comments
- Apply test purpose and scenario documentation standards
- Follow test maintenance notes patterns

*Code Coverage*:
- Match code coverage measurement patterns if implemented
- Follow coverage threshold standards
- Apply coverage gap identification patterns
- Match coverage reporting approaches

*Continuous Integration*:
- Follow CI pipeline test execution patterns
- Match test database provisioning patterns (containers, LocalDB, dedicated servers)
- Apply test data seeding approaches for CI
- Follow test result publishing patterns
- Match test failure notification patterns

*Test Maintenance*:
- Follow test refactoring patterns
- Match obsolete test handling approaches
- Apply test data maintenance patterns
- Follow test versioning with database schema changes

**Testing SQL with .NET** (xUnit/NUnit/MSTest):

*Test Framework Selection*:
- Identify .NET testing framework in use (xUnit, NUnit, MSTest)
- Match framework-specific attributes and conventions ([Fact], [Test], [TestMethod])
- Follow test class and method organization patterns
- Apply framework-specific setup/teardown patterns (IClassFixture, [SetUp]/[TearDown], [TestInitialize]/[TestCleanup])

*Database Connection Management*:
- Follow connection string patterns (appsettings.json, environment variables, secrets)
- Match connection factory patterns (IDbConnection, SqlConnection)
- Apply connection pooling patterns
- Follow connection disposal patterns (using statements, IDisposable)
- Match async connection patterns (OpenAsync, ExecuteAsync)

*Database Test Infrastructure*:

**Test Database Strategies**:
- Identify test database approach:
  - Shared test database (all tests use same instance)
  - Database per test class (isolation by test class)
  - Database per test (complete isolation)
  - In-memory database (SQL Server LocalDB, SQLite in-memory)
  - Containerized database (Testcontainers, Docker)
- Match database naming conventions for tests
- Follow database creation/deletion patterns
- Apply database migration patterns for tests

**Testcontainers for SQL Server** (if detected):
- Match container image patterns (mcr.microsoft.com/mssql/server)
- Follow container lifecycle management (startup, cleanup)
- Apply port mapping and configuration patterns
- Match wait strategies for container readiness
- Follow resource cleanup patterns (IAsyncLifetime)

**LocalDB Patterns** (if detected):
- Match LocalDB instance creation patterns
- Follow instance naming conventions
- Apply connection string patterns for LocalDB
- Match LocalDB cleanup patterns

*Database Setup and Teardown*:

**Schema Management**:
- Follow schema deployment patterns:
  - DACPAC deployment (SqlPackage, DacFx API)
  - Entity Framework migrations (DbContext.Database.Migrate())
  - Script execution (CREATE TABLE, CREATE PROCEDURE scripts)
  - SQL project build output deployment
- Match schema versioning approaches
- Apply idempotent script patterns
- Follow schema teardown patterns

**Test Data Management**:
- Match test data seeding patterns:
  - SQL INSERT scripts
  - Dapper for data insertion
  - Entity Framework for entity creation
  - SQL MERGE for upsert patterns
  - Test data builders (Fluent API patterns)
- Follow test data isolation patterns
- Apply test data cleanup strategies
- Match synthetic data generation patterns (Bogus, AutoFixture)

**Database Reset Strategies**:
- Identify database reset approach:
  - **Respawn**: Match Respawn checkpoint patterns for fast resets
  - **Transaction Rollback**: Follow transaction-based isolation
  - **Truncate All Tables**: Apply table truncation patterns
  - **Drop and Recreate**: Match full database recreation patterns
  - **Snapshot Restore**: Follow SQL Server snapshot patterns
- Match reset timing (per test, per test class, per test run)
- Follow foreign key constraint handling patterns
- Apply identity column reset patterns

*Testing Stored Procedures*:

**Procedure Execution**:
- Follow stored procedure invocation patterns:
  - ADO.NET SqlCommand with parameters
  - Dapper Execute/Query methods
  - Entity Framework FromSqlRaw/FromSqlInterpolated
- Match parameter binding patterns (@paramName, SqlParameter)
- Apply output parameter handling patterns
- Follow return value assertion patterns

**Result Validation**:
- Match result set assertion patterns:
  - Result count validation
  - Column value assertions
  - Row-by-row comparison
  - Collection assertions (Should().BeEquivalentTo(), CollectionAssert)
- Follow result object mapping patterns (Dapper, ADO.NET DataReader)
- Apply expected result set comparison approaches
- Match NULL handling in assertions

**Error Handling**:
- Follow SQL exception handling patterns (SqlException)
- Match error number assertion patterns
- Apply RAISERROR/THROW validation patterns
- Follow transaction rollback verification patterns

*Testing Functions*:

**Scalar Functions**:
- Match scalar function invocation patterns (SELECT dbo.FunctionName(@param))
- Follow return value assertion patterns
- Apply edge case testing (NULL inputs, boundary values)

**Table-Valued Functions**:
- Follow TVF query patterns (SELECT * FROM dbo.FunctionName(@param))
- Match result set validation approaches
- Apply joining TVF with other tables patterns

*Testing Views*:

**View Query Patterns**:
- Match view query execution patterns (SELECT * FROM ViewName)
- Follow result set validation approaches
- Apply view parameter patterns (if parameterized views via functions)
- Match view performance assertion patterns

*Testing Triggers*:

**Trigger Validation**:
- Follow trigger invocation patterns (INSERT/UPDATE/DELETE operations)
- Match trigger effect validation (audit table checks, computed column verification)
- Apply cascading effect testing patterns
- Follow trigger error handling validation patterns

*Data Access Layer Testing*:

**Repository Pattern Testing**:
- Match repository interface testing patterns
- Follow dependency injection patterns for repositories
- Apply mocking patterns for IDbConnection (Moq, NSubstitute)
- Match repository method assertion patterns (GetById, GetAll, Add, Update, Delete)

**Entity Framework Testing**:
- Follow DbContext testing patterns
- Match in-memory provider patterns (if used)
- Apply migration testing patterns
- Follow LINQ query testing approaches
- Match change tracking validation patterns

**Dapper Testing**:
- Follow Dapper query execution patterns
- Match multi-mapping patterns testing
- Apply dynamic parameter testing
- Follow transaction patterns with Dapper

*Integration Testing Patterns*:

**End-to-End Workflow Testing**:
- Match multi-step transaction testing patterns
- Follow cross-procedure workflow validation
- Apply data consistency verification patterns
- Match rollback scenario testing approaches

**Performance Testing**:
- Follow execution time assertion patterns (stopwatch, benchmark)
- Match query performance validation approaches
- Apply index usage verification patterns (SET STATISTICS IO ON)
- Follow execution plan analysis patterns

*Test Organization*:

**Test Class Structure**:
- Match test class naming conventions (StoredProcedureNameTests, FunctionNameTests)
- Follow test class organization (one class per procedure/function vs grouped by feature)
- Apply test categorization (unit, integration) via attributes ([Trait], [Category])
- Match test class lifecycle patterns (IClassFixture, ICollectionFixture)

**Test Method Naming**:
- Follow test method naming conventions:
  - MethodName_Scenario_ExpectedResult
  - Should_ExpectedBehavior_When_Condition
  - Given_Precondition_When_Action_Then_Outcome
- Apply descriptive naming patterns
- Match async test naming patterns (ends with Async)

*Assertion Libraries*:
- Identify assertion library in use (FluentAssertions, Shouldly, Assert/CollectionAssert)
- Match assertion style and fluency
- Follow assertion message patterns
- Apply collection assertion patterns

*Test Fixtures and Shared Context*:

**Database Fixtures**:
- Follow fixture patterns for database lifecycle (IClassFixture<DatabaseFixture>)
- Match fixture initialization patterns (constructor, InitializeAsync)
- Apply fixture disposal patterns (Dispose, DisposeAsync)
- Follow shared database context patterns across tests

**Test Data Fixtures**:
- Match test data setup fixtures
- Follow seed data patterns in fixtures
- Apply fixture composition patterns
- Match fixture parameter patterns

*Mocking and Test Doubles*:

**Connection Mocking**:
- Follow IDbConnection mocking patterns (Moq, NSubstitute)
- Match command mocking patterns
- Apply reader mocking patterns for data reader tests
- Follow transaction mocking patterns

**Repository Mocking**:
- Match repository interface mocking patterns
- Follow mock setup patterns (Setup, Returns, ReturnsAsync)
- Apply verification patterns (Verify, Received)
- Match mock behavior patterns (strict vs loose mocking)

*CI/CD Integration*:

**Pipeline Database Provisioning**:
- Follow CI pipeline database setup patterns:
  - Docker container startup
  - LocalDB installation
  - Azure SQL temporary database
  - SQL Server service configuration
- Match connection string override patterns for CI
- Apply pipeline environment variable patterns
- Follow secrets management patterns (Azure Key Vault, GitHub Secrets)

**Test Execution in CI**:
- Match test execution command patterns (dotnet test)
- Follow parallel test execution patterns (--parallel, CollectionBehavior.CollectionPerClass)
- Apply test filtering patterns (--filter, category filtering)
- Match test retry patterns for flaky tests

**Test Reporting**:
- Follow test result output patterns (TRX, JUnit XML)
- Match code coverage patterns (coverlet, dotCover)
- Apply test summary publishing patterns
- Follow test failure notification patterns

*Configuration Management*:

**Connection Strings**:
- Match connection string configuration patterns (appsettings.Test.json)
- Follow connection string override patterns (environment variables)
- Apply integrated security vs SQL authentication patterns
- Match connection string encryption patterns

**Test Settings**:
- Follow test configuration patterns (xunit.runner.json, runsettings)
- Match test parallelization settings
- Apply test timeout configuration patterns
- Follow test output verbosity patterns

*Best Practices*:
- Follow transaction-based test isolation when possible
- Match test database naming conventions (TestDb, DbName_Test, DbName_IntegrationTests)
- Apply deterministic test data patterns (avoid random data that causes flaky tests)
- Follow test independence patterns (tests don't depend on execution order)
- Match test performance optimization patterns (parallel execution, shared fixtures)
- Apply cleanup patterns to prevent resource leaks
- Follow async/await patterns consistently in tests

#### Schema Diagram Generation
When generating database documentation, create:

**Entity Relationship Diagrams (ERD)**:
- Identify all tables and their relationships via foreign keys
- Document cardinality (one-to-one, one-to-many, many-to-many)
- Show primary keys, foreign keys, and unique constraints
- Group tables by schema or functional domain
- Use Mermaid ERD syntax for inline documentation:

\`\`\`mermaid
erDiagram
    Customer ||--o{ Order : places
    Order ||--|{ OrderItem : contains
    Product ||--o{ OrderItem : "ordered in"
    
    Customer {
        int CustomerID PK
        nvarchar(100) CustomerName
        nvarchar(255) Email UK
    }
    
    Order {
        int OrderID PK
        int CustomerID FK
        datetime2 OrderDate
    }
\`\`\`

**Dependency Diagrams**:
- Map stored procedure dependencies on tables and views
- Document view dependencies on base tables
- Show function usage in computed columns and constraints
- Identify circular dependencies to avoid

**Schema Organization Diagrams**:
- Visualize schema boundaries and purposes
- Document cross-schema dependencies
- Show security boundaries and access patterns` : ""}

## Version Control Guidelines

${VERSIONING == "Semantic" ? 
`- Follow Semantic Versioning patterns as applied in the codebase
- Match existing patterns for documenting breaking changes
- Follow the same approach for deprecation notices` : ""}

${VERSIONING == "CalVer" ? 
`- Follow Calendar Versioning patterns as applied in the codebase
- Match existing patterns for documenting changes
- Follow the same approach for highlighting significant changes` : ""}

${VERSIONING == "Custom" ? 
`- Match the exact versioning pattern observed in the codebase
- Follow the same changelog format used in existing documentation
- Apply the same tagging conventions used in the project` : ""}

## General Best Practices

- Follow naming conventions exactly as they appear in existing code
- Match code organization patterns from similar files
- Apply error handling consistent with existing patterns
- Follow the same approach to testing as seen in the codebase
- Match logging patterns from existing code
- Use the same approach to configuration as seen in the codebase

## Project-Specific Guidance

- Scan the codebase thoroughly before generating any code
- Respect existing architectural boundaries without exception
- Match the style and patterns of surrounding code
- When in doubt, prioritize consistency with existing code over external best practices
```

### 2. Codebase Analysis Instructions

To create the copilot-instructions.md file, first analyze the codebase to:

1. **Identify Exact Technology Versions**:
   - ${PROJECT_TYPE == "Auto-detect" ? "Detect all programming languages, frameworks, and libraries by scanning file extensions and configuration files" : `Focus on ${PROJECT_TYPE} technologies`}
   - Extract precise version information from project files, package.json, .csproj, etc.
   - Document version constraints and compatibility requirements
   - ${PROJECT_TYPE == "SQL" || PROJECT_TYPE == "Auto-detect" || PROJECT_TYPE == "Multiple" ? "For SQL projects: Extract SQL Server version and compatibility level from .sqlproj files" : ""}

2. **Understand Architecture**:
   - Analyze folder structure and module organization
   - Identify clear layer boundaries and component relationships
   - Document communication patterns between components
   - ${PROJECT_TYPE == "SQL" || PROJECT_TYPE == "Auto-detect" || PROJECT_TYPE == "Multiple" ? "For SQL projects: Map schema organization, table relationships, and stored procedure dependencies" : ""}

3. **Document Code Patterns**:
   - Catalog naming conventions for different code elements
   - Note documentation styles and completeness
   - Document error handling patterns
   - Map testing approaches and coverage
   - ${PROJECT_TYPE == "SQL" || PROJECT_TYPE == "Auto-detect" || PROJECT_TYPE == "Multiple" ? "For SQL projects: Document naming patterns for all database objects (tables, columns, keys, indexes, procedures, functions, views, triggers, constraints)" : ""}

4. **Note Quality Standards**:
   - Identify performance optimization techniques actually used
   - Document security practices implemented in the code
   - Note accessibility features present (if applicable)
   - Document code quality patterns evident in the codebase
   - ${PROJECT_TYPE == "SQL" || PROJECT_TYPE == "Auto-detect" || PROJECT_TYPE == "Multiple" ? "For SQL projects: Document indexing strategies, transaction patterns, error handling (TRY/CATCH), and security patterns (permissions, RLS)" : ""}

5. **Generate Schema Diagrams** (for SQL projects):
   - ${PROJECT_TYPE == "SQL" || PROJECT_TYPE == "Auto-detect" || PROJECT_TYPE == "Multiple" ? "Create Entity Relationship Diagrams showing all tables, relationships, and key constraints" : ""}
   - ${PROJECT_TYPE == "SQL" || PROJECT_TYPE == "Auto-detect" || PROJECT_TYPE == "Multiple" ? "Document cardinality and referential integrity patterns" : ""}
   - ${PROJECT_TYPE == "SQL" || PROJECT_TYPE == "Auto-detect" || PROJECT_TYPE == "Multiple" ? "Map stored procedure and view dependencies on tables" : ""}
   - ${PROJECT_TYPE == "SQL" || PROJECT_TYPE == "Auto-detect" || PROJECT_TYPE == "Multiple" ? "Identify schema boundaries and cross-schema dependencies" : ""}
   - ${PROJECT_TYPE == "SQL" || PROJECT_TYPE == "Auto-detect" || PROJECT_TYPE == "Multiple" ? "Use Mermaid ERD syntax for visual documentation" : ""}

### 3. Implementation Notes

The final copilot-instructions.md should:
- Be placed in the .github/copilot directory
- Reference only patterns and standards that exist in the codebase
- Include explicit version compatibility requirements
- Avoid prescribing any practices not evident in the code
- Provide concrete examples from the codebase
- Be comprehensive yet concise enough for Copilot to effectively use

Important: Only include guidance based on patterns actually observed in the codebase. Explicitly instruct Copilot to prioritize consistency with existing code over external best practices or newer language features.
"

## Expected Output

A comprehensive copilot-instructions.md file that will guide GitHub Copilot to produce code that is perfectly compatible with your existing technology versions and follows your established patterns and architecture.