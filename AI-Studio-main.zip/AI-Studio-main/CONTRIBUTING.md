# Contributing to Zelis AI Studio

This document explains how to add, edit, and maintain Agent Skills.

## Repository Structure

```
Zelis.AI.Studio/
├── skills/                      # Agent Skills (one folder per skill)
│   ├── {skill-name}/
│   │   └── SKILL.md
│   └── ...
├── config/
│   ├── topics.yaml              # Topic-to-skills mapping
│   └── skill-schema.json        # JSON Schema for frontmatter validation
├── scripts/
│   └── lint-skills.js           # Validates SKILL.md format
└── .pre-commit-config.yaml      # Pre-commit hooks configuration
```

## SKILL.md Format

Each skill is defined in a `SKILL.md` file:

```markdown
---
name: my-skill
description: |
  When to use this skill. Be specific so the AI knows when to load it.
  Example: "Use when writing Python services, FastAPI apps, or pytest tests."
disposition: contextual
filePatterns:
  - "**/*.py"
compliance:
  - soc2: "CC5.2"
version: "1.0.0"
---

# Skill Title

## Section 1
- Rule **MUST** be followed
- Recommendation **SHOULD** be followed

## Section 2
...
```

### Required Fields

| Field | Description |
|-------|-------------|
| `name` | Unique skill identifier (should match folder name) |
| `description` | Tells AI when to load this skill - be specific! |

### Optional Fields

| Field | Description |
|-------|-------------|
| `disposition` | `always` (always loaded) or `contextual` (loaded by context) |
| `filePatterns` | Glob patterns for relevant files |
| `compliance` | Compliance mappings (SOC2, ISO27001, HIPAA) |
| `version` | Semantic version |

### Writing Good Descriptions

The `description` field is critical—it tells the AI when to use the skill.

**Good:**
```yaml
description: |
  Python backend development standards. Use when writing Python services,
  FastAPI apps, async code, Pydantic models, pytest tests, or implementing
  hexagonal architecture.
```

**Bad:**
```yaml
description: "Python standards"  # Too vague
```

## Adding a New Skill

### 1. Create the Skill

```bash
mkdir skills/my-new-skill
```

Create `skills/{category}/my-new-skill/SKILL.md` (where {category} is one of: angular, aws-migration, blazor, database, design-system, devops, dotnet-architecture, dotnet-backend, dotnet-infrastructure, frontend, python, sdlc, security, terraform, testing, typescript):

```markdown
---
name: my-new-skill
description: |
  Detailed description of when to use this skill...
disposition: contextual
version: "1.0.0"
---

# My New Skill

Content here...
```

### 2. Add to Topics (if topic-specific)

Edit `config/topics.yaml`:

```yaml
topics:
  ai-rules-my-topic:
    - my-new-skill
```

If the skill should go to ALL subscribers, add it to `generic_skills`.

### 3. Validate

```bash
npm run lint
```

### 4. Submit PR

Open a PR with your changes. The linter runs automatically.

## Editing Existing Skills

1. Edit the `SKILL.md` file directly
2. Update `version` in frontmatter
3. Run `npm run lint`
4. Submit PR

## Topic Mapping

`config/topics.yaml` defines which skills go to which subscribers:

```yaml
# Everyone gets these, organized by semantic categories
generic_skills:
  architecture_and_sdlc:
    - sdlc/coding-principles
    - sdlc/sdlc-principles
    - ...
  
  security:
    - security/security-standards
    - security/secure-coding-enforcement
    - ...
  
  quality_assurance:
    - testing/testing-standards
    - testing/integration-test-contracts
    - ...
  
  standards:
    - linting-standards

# Topic-specific skills - only for repos with matching GitHub topics
topics:
  ai-rules-backend-python:
    - python-backend
  ai-rules-frontend:
    - frontend-standards
```

The categories under `generic_skills` are semantic groupings that:
- Organize skills by their purpose for better maintainability
- Are validated by the linter and used by the distributor
- Help developers understand the scope of each skill at a glance

## CI/CD

### On Pull Request

The linter validates all skills:

```bash
npm run lint
```

Checks:
- Required fields (`name`, `description`)
- Valid YAML frontmatter
- Schema validation (`disposition`, `version`, `filePatterns`, `compliance`)
- Minimum body content (50 chars)
- Name matches folder name
- Cross-validation between `topics.yaml` and existing skills
- Detection of orphan skills (not referenced in topics.yaml)

### Pre-commit Hooks

Pre-commit hooks are automatically set up when you run `npm install`:

```bash
npm install  # Automatically installs git hooks
```

The setup script will:
1. Use `pre-commit` if installed (recommended for full features)
2. Fall back to a simple git hook that runs `npm run lint`

For full pre-commit support (markdown linting, trailing whitespace fixes, etc.):

```bash
pip install pre-commit
pre-commit install
```

To manually run all hooks:

```bash
pre-commit run --all-files
# Or just the linter:
npm run lint
```

Hooks include:
- Trailing whitespace removal
- End-of-file fixes
- YAML/JSON validation
- Markdown linting
- Skill linting with cross-validation

### On Merge

Skills are ready for distribution. The distributor (separate workflow) copies
skills to subscriber repos.

## Best Practices

### Content Guidelines

- Keep skills focused (one topic per skill)
- Under 500 lines per skill
- Use **MUST** for requirements, **SHOULD** for recommendations
- Include concrete examples
- Reference compliance controls where applicable

### Naming Conventions

- Use lowercase with hyphens: `python-backend`, `security-standards`
- Be descriptive but concise
- Match folder name to `name` field

### Testing

Before submitting:

```bash
npm run lint
```

Test in your IDE:
1. Copy skill to `.cursor/skills/` or `.github/skills/`
2. Ask the AI about relevant topics
3. Verify the skill is loaded

To test GitHub workflows locally (requires [act](https://github.com/nektos/act) and Docker):

```bash
act push -W .github/workflows/lint-skills.yml
```

## Governance

### Dispositions

| Disposition | Meaning | Examples |
|-------------|---------|----------|
| `always` | Loaded in every conversation | Security, architecture |
| `contextual` | Loaded based on context | Language-specific |

### Compliance Tracking

Skills can include compliance mappings:

```yaml
compliance:
  - soc2: "CC5.2"
  - iso27001: "A.14.2.5"
  - hipaa: "164.312"
```

These are for governance tracking—AI tools ignore them.

## Questions?

- Open an issue for questions
- See [README.md](./README.md) for overview
- See [SUBSCRIPTION.md](./SUBSCRIPTION.md) for subscriber info
