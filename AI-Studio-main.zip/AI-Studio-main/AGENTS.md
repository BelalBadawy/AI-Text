# AGENTS.md (AI Agent Instructions)

This repository contains **organization-level custom agents** used by GitHub Copilot **Mission Control / Agent HQ**.

## Where agent profiles live

- `agents/` — top-level custom agents intended for org-wide usage
- `agents/subagents/` — internal-only subagents used by orchestrators

## Agent usage patterns

- **Primary agents** (`infer: true`) — discoverable by users in Mission Control
- **Subagents** (`infer: false`) — internal-only, called by orchestrators
- **Dual-purpose agents** — some primary agents are designed for both direct user invocation and orchestrator delegation

## Generic subagent pattern

Several subagents are designed as **generic workers** that can be reused across multiple orchestrators:

- `doc-navigator` — builds dependency graph and determines processing order for any repository type
- `doc-reader` — crawls repository structure based on orchestrator-provided domain context
- `doc-searcher` — finds evidence using orchestrator-provided taxonomy and search patterns
- `doc-writer` — generates documentation using orchestrator-provided templates
- `doc-verifier` — validates deliverables against orchestrator-provided rules

### Using generic subagents

When invoking generic subagents via `custom-agent`, orchestrators must provide:

1. **Domain context**: What to look for, valid categories, output structure
2. **Scoped analysis**: Specific component or path to analyze (progressive refinement across iterations)
3. **Taxonomy**: Domain-specific categories, severity definitions, patterns

Example invocation:

```markdown
Run `doc-reader` with:
- Scope: "src/UserManagement/*"
- Focus: "WCF dependencies and service boundaries"
- PreviousFindings: "UserManagement identified as high-risk in Iteration 1..."
- RepositoryType: ".NET Legacy"
- ArtifactsToFind: [".sln", ".csproj", "packages.config", "web.config"]
- StructuralElements: ["Solutions", "Projects", "TargetFrameworks"]
- OutputPath: "docs/migration-readiness"
```

This pattern enables multiple orchestrators to share subagent infrastructure while maintaining domain expertise at the orchestrator level.

### Dependency-aware processing with doc-navigator

For comprehensive repository analysis, orchestrators should use `doc-navigator` to establish processing order:

```markdown
Run `doc-navigator` with:
- RepositoryType: ".NET"
- DependencyPatterns: ["<ProjectReference", "<PackageReference"]
- StructuralFiles: [".sln", ".csproj"]
- OutputFormat: "full"
```

Navigator returns:
- **ProcessingOrder**: Topological order (leaf projects first, dependents last)
- **DependencyGraph**: Map of project → dependencies
- **ImpactAnalysis**: Map of project → dependents (reverse dependencies)

Benefits:
- **Migration**: Generate dependency-aware roadmaps, compute blocker impact
- **Knowledgebase**: Document components in order so dependencies are documented first
- **Architecture**: Produce accurate dependency diagrams

### DependencyContext for coherent documentation

When processing in dependency order, pass `DependencyContext` to doc-reader:

```markdown
Run `doc-reader` with:
- Scope: "src/Services/Payment/*"
- DependencyContext:
  - Auth.csproj: "WCF-based authentication. 8 contracts. High-severity blocker."
  - Common.csproj: "Shared utilities. No blockers."
```

This enables:
- Coherent cross-project references
- Impact analysis ("Payment blocked by Auth's WCF")
- Documentation that builds on already-documented dependencies

### Orchestrator Anti-Patterns (What NOT to Do)

Orchestrators are **coordination layers**, not workers. They MUST NOT:

1. **Create scripts** to perform analysis or generate documentation
   - Bad: `shell("python generate_docs.py")`
   - Good: `custom-agent: doc-writer` with parameters

2. **Use edit directly** for deliverables
   - Bad: `edit("docs/architecture.md", content)`
   - Good: `custom-agent: doc-writer` with AccumulatedFindings

3. **Use search/read directly** for analysis
   - Bad: `search("WCF") → analyze → write findings`
   - Good: `custom-agent: doc-searcher` with SearchRequests

4. **Bypass subagents** for "efficiency"
   - The subagent architecture exists for context compression and specialization
   - Direct work by orchestrator defeats this purpose

### Enforcement

If an orchestrator is observed bypassing subagents:
1. Check delegation rules are present and use "MUST" language
2. Verify tool restrictions are documented
3. Ensure no fallback clauses allow self-execution
4. Consider restricting tools list if needed

### State management for large repositories

Orchestrators analyzing large codebases should use **in-memory state** during execution:

- Maintain cumulative findings in orchestrator context
- Track: analyzed components, priority queue, coverage percentage
- No file persistence during normal iteration flow

**Checkpoint fallback** (only for very large repos that timeout):

- Create `docs/{output-path}/.checkpoint.json` if execution exceeds time limit
- On re-invocation, check for checkpoint and resume from last iteration
- Delete checkpoint when analysis completes

This keeps normal execution clean while supporting resume-ability for massive repositories.

## Editing guidelines

- Keep all agent profiles as `*.agent.md` with valid YAML frontmatter.
- Prefer **documented tool names** in agent profiles: `read`, `search`, `edit`, `shell`, `custom-agent`.
- Keep subagents **internal-only** by setting `infer: false`.

## Available Agents

### Orchestrators

Orchestrators coordinate complex, multi-step workflows by delegating to subagents. They maintain state and provide domain expertise.

#### migration-orchestrator

Analyzes repositories for .NET modernization readiness, containerization feasibility, and cloud migration blockers.

- **Type**: Primary agent (`infer: true`)
- **Output**: `docs/migration-readiness/`
- **Deliverables**: 
  - Migration readiness score and summary
  - Dependency-aware blocker analysis with impact assessment
  - Dependency-ordered migration roadmap
  - Container readiness evaluation
  - Database migration analysis (if SQL Server detected)
- **Subagents**: doc-navigator, doc-reader, doc-searcher, migration-db-analyzer, doc-writer, doc-verifier
- **Target**: Any .NET repository via Mission Control

#### knowledgebase-orchestrator

Generates comprehensive repository documentation including architecture diagrams, component documentation, and developer onboarding guides.

- **Type**: Primary agent (`infer: true`)
- **Output**: `docs/knowledgebase/`
- **Deliverables**:
  - README with quick start guide
  - Architecture documentation with Mermaid diagrams
  - Component catalog with dependency graphs
  - Database architecture (if stored procedures detected)
  - Developer onboarding guide
  - Dependency rationale and tech stack inventory
- **Subagents**: doc-navigator, doc-reader, doc-searcher, doc-writer, doc-verifier
- **Target**: Any repository via Mission Control

### Utility Agents

Standalone agents that perform direct work rather than orchestrating subagents. Designed for interactive IDE workflows.

#### git-commit

Streamlined Git workflow automation with intelligent commit message generation and safety checks.

- **Type**: Primary agent (`infer: true`, IDE-focused)
- **Target**: VS Code, Cursor (local development)
- **Commands**: `/commit`, `/status`, `/diff`, `/stage`, `/unstage`, `/push`, `/branch`, `/log`, `/stash`, `/revert`
- **Features**:
  - Automatic Conventional Commits message generation from diff analysis
  - Protected branch warnings (main, master, develop, release/*)
  - Sensitive data detection (API keys, tokens, secrets, passwords)
  - Pre-commit hook failure handling with suggestions
  - Force-push safety (uses `--force-with-lease` only when explicitly requested)
  - Branch management and commit history analysis

### Subagents

Internal-only workers (`infer: false`) designed as reusable components for orchestrators. Not directly selectable in Mission Control.

#### doc-navigator

Analyzes repository structure and builds dependency graphs to determine optimal processing order.

- **Type**: Subagent (`infer: false`)
- **Responsibilities**:
  - Parse project files (.sln, .csproj, package.json, etc.)
  - Build topological dependency graph
  - Generate processing order (leaf → root)
  - Compute impact analysis (reverse dependencies)
- **Used by**: migration-orchestrator, knowledgebase-orchestrator
- **Output**: ProcessingOrder, DependencyGraph, ImpactAnalysis

#### doc-reader

Performs scoped repository analysis with awareness of previously analyzed components.

- **Type**: Subagent (`infer: false`)
- **Responsibilities**:
  - Analyze specified paths/components
  - Identify key structures, patterns, and integrations
  - Maintain coherence via DependencyContext (previously documented components)
  - Detect database interactions (stored procedures, ORM usage)
- **Used by**: All orchestrators
- **Input**: Scope, Focus, DependencyContext, DatabaseContext, RepositoryType
- **Output**: Component analysis, findings summary

#### doc-searcher

Evidence gathering using orchestrator-provided taxonomy and search patterns.

- **Type**: Subagent (`infer: false`)
- **Responsibilities**:
  - Execute targeted searches based on taxonomy
  - Categorize findings by severity/type
  - Collect file references and code snippets as evidence
  - Support regex patterns and multi-file searches
- **Used by**: migration-orchestrator, knowledgebase-orchestrator
- **Input**: CategoryTaxonomy, SearchRequests, FilePatterns
- **Output**: Categorized evidence with file references

#### doc-writer

Generates documentation files based on accumulated findings and templates.

- **Type**: Subagent (`infer: false`)
- **Responsibilities**:
  - Generate markdown documentation from findings
  - Create Mermaid diagrams (system context, containers, dependencies, sequences)
  - Maintain consistent formatting and cross-references
  - Apply documentation templates
- **Used by**: All orchestrators
- **Input**: OutputPath, DeliverableTemplates, AccumulatedFindings, DependencyGraph, DiagramStyle
- **Output**: Complete documentation file set

#### doc-verifier

Validates documentation quality and completeness against orchestrator-defined rules.

- **Type**: Subagent (`infer: false`)
- **Responsibilities**:
  - Verify all required deliverables exist
  - Check cross-references and internal links
  - Validate diagrams match actual dependencies
  - Ensure evidence citations are present
  - Confirm consistency across documents
- **Used by**: All orchestrators
- **Input**: OutputPath, VerificationRules, RequiredEvidence, ConsistencyChecks
- **Output**: PASS/FAIL with specific issues

#### migration-db-analyzer

Specialized analyzer for SQL Server → AWS Aurora PostgreSQL migration assessment.

- **Type**: Subagent (`infer: false`)
- **Responsibilities**:
  - Identify SQL Server-specific features and syntax
  - Detect incompatible T-SQL constructs
  - Analyze stored procedures for business logic extraction
  - Assess effort and compatibility for PostgreSQL migration
- **Used by**: migration-orchestrator
- **Input**: Database files, connection strings, stored procedure paths
- **Output**: Compatibility report, blocker inventory, effort estimate

## Migration analysis output conventions (target repos)

When running the migration orchestrator against a target repository, the agent should:

- Add only documentation artifacts under `docs/migration-readiness/`
- Avoid refactoring or code changes unless explicitly requested
- Cite evidence for every blocker (file paths + line numbers when possible)
- Generate dependency-aware roadmap using Navigator output

## Model selection

For GitHub.com Mission Control runs, the `model:` field in agent profiles may be ignored.
If your organization requires GPT-5.2, enforce it via Copilot **model allowlist** policy at the Org/Enterprise level.

