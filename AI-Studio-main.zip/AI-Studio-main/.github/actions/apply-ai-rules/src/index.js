import * as fs from "node:fs";
import * as path from "node:path";
import * as core from "@actions/core";
import * as github from "@actions/github";

import {
	getRepoTopics,
	getDefaultBranch,
	loadTopicsConfig,
	getApplicableSkills,
	checkVersionConfig,
	getCurrentVersionInfo,
	needsUpdate,
	createTempDir,
	sparseCheckoutAIRulesDir,
	copySkillsToTarget,
	createVersionFile,
	commitAndPush,
	openPR,
	getGithubReleaseBody,
	computeSkillsHash,
} from "./utils.js";

async function run() {
	try {
		// Get inputs
		const repository = process.env.INPUT_REPOSITORY || core.getInput("repository", { required: true });
		const githubToken = process.env.INPUT_GITHUB_TOKEN || core.getInput("github_token", { required: true });
		const releaseTag = process.env.INPUT_RELEASE_TAG || core.getInput("release_tag") || "";
		const dryRun = (process.env.INPUT_DRY_RUN || core.getInput("dry_run")) === "true";

		core.info(`Applying AI rules to ${repository}`);
		core.info(`Release tag: ${releaseTag || "latest"}`);
		core.info(`Dry run: ${dryRun}`);

		// Initialize octokit
		const octokit = github.getOctokit(githubToken);

		// Determine paths (action runs from the repo root)
		const actionDir = process.cwd();
		const topicsConfigPath = path.join(actionDir, "config", "topics.yaml");
		const skillsDir = path.join(actionDir, "skills");

		// Verify required files exist
		if (!fs.existsSync(topicsConfigPath)) {
			throw new Error(`Topics config not found at ${topicsConfigPath}`);
		}
		if (!fs.existsSync(skillsDir)) {
			throw new Error(`Skills directory not found at ${skillsDir}`);
		}

		// Load configuration
		const topicsConfig = loadTopicsConfig(topicsConfigPath);

		// Get current version from VERSION file or git tag
		const versionFile = path.join(actionDir, "VERSION");
		const version = fs.existsSync(versionFile)
			? fs.readFileSync(versionFile, "utf-8").trim()
			: releaseTag || "dev";

		core.info(`Rules version: ${version}`);

		// Get repository topics
		const repoTopics = await getRepoTopics(octokit, repository);
		core.info(`Repository topics: ${repoTopics.join(", ") || "none"}`);

		// Find applicable topics (intersection of repo topics and rule topics)
		const applicableTopics = repoTopics.filter(t =>
			Object.keys(topicsConfig.topics || {}).includes(t)
		);

		if (applicableTopics.length === 0) {
			core.info("No applicable AI rule topics found for this repository. Will apply generic skills only.");
		} else {
			core.info(`Applicable topics: ${applicableTopics.join(", ")}`);
		}

		// Get applicable skills based on topics
		const applicableSkills = getApplicableSkills(applicableTopics, topicsConfig, skillsDir);
		core.info(`Skills to apply: ${applicableSkills.length}`);

		// Check version config (pinning, enabled/disabled)
		const versionConfig = await checkVersionConfig(octokit, repository);
		if (!versionConfig.enabled) {
			core.info("AI rules are disabled for this repository via .ai-rules-config");
			core.setOutput("status", "skipped");
			return;
		}

		if (versionConfig.pinnedVersion && versionConfig.pinnedVersion !== version) {
			core.info(`Repository is pinned to version ${versionConfig.pinnedVersion}, current is ${version}. Skipping.`);
			core.setOutput("status", "skipped");
			return;
		}

		// Compute content hash
		const contentHash = computeSkillsHash(applicableSkills, skillsDir);

		// Check if update is needed
		const currentVersionInfo = await getCurrentVersionInfo(octokit, repository);
		const updateCheck = needsUpdate(currentVersionInfo, contentHash, version);

		if (!updateCheck.needed) {
			core.info(`No update needed: ${updateCheck.reason}`);
			core.setOutput("status", "skipped");
			return;
		}

		core.info(`Update needed: ${updateCheck.reason}`);

		if (dryRun) {
			core.info("Dry run mode - no changes will be made");
			core.setOutput("status", "dry_run");
			return;
		}

		// Get default branch
		const defaultBranch = await getDefaultBranch(octokit, repository);
		core.info(`Default branch: ${defaultBranch}`);

		// Create temp directory and clone target repo
		const tempDir = createTempDir();
		core.info(`Working directory: ${tempDir}`);

		try {
			// Sparse checkout the target repo
			await sparseCheckoutAIRulesDir(repository, githubToken, tempDir, defaultBranch);

			// Copy skills to both .cursor/skills/ and .github/skills/
			copySkillsToTarget(applicableSkills, skillsDir, tempDir);

			// Create version tracking file
			createVersionFile(tempDir, version, contentHash, applicableTopics, applicableSkills);

			// Commit and push
			const branchName = `ai-rules-update-${version}`;
			const hasChanges = await commitAndPush(tempDir, version, branchName);

			if (hasChanges) {
				// Get release notes if available
				let releaseBody = "";
				if (releaseTag) {
					try {
						releaseBody = await getGithubReleaseBody(octokit, releaseTag);
					} catch (e) {
						core.warning(`Could not get release notes: ${e.message}`);
					}
				}

				// Open PR
				const prUrl = await openPR(defaultBranch, branchName, repository, version, octokit, releaseBody, applicableSkills);
				if (prUrl) {
					core.setOutput("pr_url", prUrl);
				}
				core.setOutput("status", "created");
				core.info(`Successfully created PR for ${repository}`);
			} else {
				core.setOutput("status", "no_changes");
				core.info("No changes detected, skipping PR creation");
			}
		} finally {
			// Cleanup temp directory
			try {
				fs.rmSync(tempDir, { recursive: true, force: true });
			} catch (e) {
				core.warning(`Could not clean up temp directory: ${e.message}`);
			}
		}
	} catch (error) {
		core.setFailed(`Action failed: ${error.message}`);
		core.setOutput("status", "error");
	}
}

run();
