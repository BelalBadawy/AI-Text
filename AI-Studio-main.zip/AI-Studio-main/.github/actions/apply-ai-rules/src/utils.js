import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import * as crypto from "node:crypto";
import * as core from "@actions/core";
import * as exec from "@actions/exec";
import * as github from "@actions/github";
import * as yaml from "js-yaml";

/**
 * Validates that a git reference (branch name, tag name) is safe to use in commands.
 * Git refs can contain alphanumeric characters, hyphens, underscores, forward slashes, and periods.
 * @param {string} ref - The git reference to validate
 * @param {string} name - The name of the parameter (for error messages)
 * @throws {Error} If the reference contains invalid characters
 */
function validateGitRef(ref, name) {
	if (!ref || typeof ref !== "string") {
		throw new Error(`${name} must be a non-empty string`);
	}
	// Git refs should not contain shell metacharacters or start with special characters
	// Allow alphanumeric, hyphens, underscores, forward slashes, and periods
	const validRefPattern = /^[a-zA-Z0-9/_.-]+$/;
	if (!validRefPattern.test(ref)) {
		throw new Error(
			`${name} contains invalid characters. Only alphanumeric, hyphens, underscores, forward slashes, and periods are allowed.`,
		);
	}
	// Additional safety checks:
	// - Prevent refs that could be interpreted as command flags
	if (ref.startsWith("-")) {
		throw new Error(`${name} cannot start with a hyphen`);
	}
	// - Prevent refs starting with a period (could have special meaning in git)
	if (ref.startsWith(".")) {
		throw new Error(`${name} cannot start with a period`);
	}
	// - Prevent refs containing consecutive periods (could be path traversal)
	if (ref.includes("..")) {
		throw new Error(`${name} cannot contain consecutive periods`);
	}
}

/**
 * Validates that a version string is safe to use in commands.
 * Versions should follow semantic versioning or similar patterns.
 * @param {string} version - The version string to validate
 * @throws {Error} If the version contains invalid characters
 */
function validateVersion(version) {
	if (!version || typeof version !== "string") {
		throw new Error("Version must be a non-empty string");
	}
	// Allow semantic version patterns: digits, dots, hyphens, and plus signs
	// Examples: 1.0.0, 1.0.0-alpha.1, 1.0.0+build.123
	const validVersionPattern = /^[a-zA-Z0-9._+-]+$/;
	if (!validVersionPattern.test(version)) {
		throw new Error(
			"Version contains invalid characters. Only alphanumeric, dots, hyphens, underscores, and plus signs are allowed.",
		);
	}
	// Version must start with alphanumeric to prevent flag-like inputs
	if (!/^[a-zA-Z0-9]/.test(version)) {
		throw new Error("Version must start with an alphanumeric character");
	}
}

/**
 * Validates that a repository name is in the correct format (owner/repo).
 * @param {string} repoFullName - The full repository name
 * @throws {Error} If the repository name is invalid
 */
function validateRepoFullName(repoFullName) {
	if (!repoFullName || typeof repoFullName !== "string") {
		throw new Error("Repository name must be a non-empty string");
	}
	// Repository names should be in the format: owner/repo
	// Both owner and repo can contain alphanumeric, hyphens, underscores, and periods
	// But cannot start with special characters
	const validRepoPattern = /^[a-zA-Z0-9][a-zA-Z0-9._-]*\/[a-zA-Z0-9][a-zA-Z0-9._-]*$/;
	if (!validRepoPattern.test(repoFullName)) {
		throw new Error(
			"Repository name must be in the format 'owner/repo' where both owner and repo start with alphanumeric characters",
		);
	}
}

// Maximum number of skills to display in PR body before truncating
const MAX_SKILLS_IN_PR_BODY = 10;

async function getRepoTopics(octokit, repoFullName) {
	const [owner, repo] = repoFullName.split("/");
	const { data } = await octokit.rest.repos.getAllTopics({
		owner,
		repo,
	});
	return data.names;
}

async function getDefaultBranch(octokit, repoFullName) {
	const [owner, repo] = repoFullName.split("/");

	core.info(`Fetching repository details for ${owner}/${repo}...`);
	const { data: repoData } = await octokit.rest.repos.get({
		owner,
		repo,
	});

	return repoData.default_branch;
}

function loadTopicsConfig(topicsConfigPath) {
	const fileContent = fs.readFileSync(topicsConfigPath, "utf8");
	return yaml.load(fileContent);
}

/**
 * Get list of skills to apply based on repo topics
 * Returns array of skill names (folder names)
 */
function getApplicableSkills(repoTopics, topicsConfig, skillsDir) {
	const skills = new Set();

	// Always include generic skills
	const genericSkills = topicsConfig.generic_skills || [];

	// Check if it's the new nested structure (object with categories)
	if (typeof genericSkills === 'object' && !Array.isArray(genericSkills)) {
		// New structure: categories containing arrays of skills
		for (const category of Object.keys(genericSkills)) {
			const categorySkills = genericSkills[category];
			if (Array.isArray(categorySkills) && categorySkills !== null && categorySkills !== undefined) {
				for (const skill of categorySkills) {
					const skillPath = path.join(skillsDir, skill);
					if (fs.existsSync(skillPath)) {
						skills.add(skill);
					}
				}
			}
		}
	} else if (Array.isArray(genericSkills)) {
		// Old structure: flat array of skills (backward compatibility)
		for (const skill of genericSkills) {
			const skillPath = path.join(skillsDir, skill);
			if (fs.existsSync(skillPath)) {
				skills.add(skill);
			}
		}
	}

	// Add topic-specific skills
	const topics = topicsConfig.topics || {};
	for (const topic of repoTopics) {
		const topicSkills = topics[topic] || [];
		for (const skill of topicSkills) {
			const skillPath = path.join(skillsDir, skill);
			if (fs.existsSync(skillPath)) {
				skills.add(skill);
			}
		}
	}

	return Array.from(skills).sort();
}

// Check if repo has version pinning or is disabled
async function checkVersionConfig(octokit, repoFullName) {
	const [owner, repo] = repoFullName.split("/");
	try {
		const { data } = await octokit.rest.repos.getContent({
			owner,
			repo,
			path: ".ai-rules-config",
		});
		const content = Buffer.from(data.content, "base64").toString("utf8");
		const config = yaml.load(content);
		return {
			enabled: config.enabled !== false,
			pinnedVersion: config.pinned_version || null,
		};
	} catch (_e) {
		// No config file, use defaults
		return { enabled: true, pinnedVersion: null };
	}
}

// Get current version info from target repo
async function getCurrentVersionInfo(octokit, repoFullName) {
	const [owner, repo] = repoFullName.split("/");
	try {
		const { data } = await octokit.rest.repos.getContent({
			owner,
			repo,
			path: ".ai-rules-version",
		});
		const content = Buffer.from(data.content, "base64").toString("utf8");
		return JSON.parse(content);
	} catch (_e) {
		// No version file, first install
		return null;
	}
}

/**
 * Compute hash of skill contents
 */
function computeSkillsHash(skillNames, skillsDir) {
	const hash = crypto.createHash("sha256");

	for (const skillName of skillNames.sort()) {
		const skillFile = path.join(skillsDir, skillName, "SKILL.md");
		if (fs.existsSync(skillFile)) {
			const content = fs.readFileSync(skillFile, "utf8");
			hash.update(content);
		}
	}

	return hash.digest("hex").substring(0, 16);
}

// Check if update is needed based on content hash
function needsUpdate(currentVersionInfo, newContentHash, version) {
	if (!currentVersionInfo) {
		return { needed: true, reason: "First install" };
	}

	if (currentVersionInfo.content_hash !== newContentHash) {
		return { needed: true, reason: "Skills content changed" };
	}

	if (currentVersionInfo.version !== version) {
		return { needed: true, reason: "Version changed" };
	}

	return { needed: false, reason: "Already up to date" };
}

async function getGithubReleaseBody(octokit, releaseTag) {
	const repository = github.context.payload.repository.full_name;
	const [owner, repo] = repository.split("/");
	core.info(`Getting release body for ${owner}/${repo} ${releaseTag}`);

	const { data: release } = await octokit.rest.repos.getReleaseByTag({
		owner,
		repo,
		tag: releaseTag,
	});

	return release.body;
}

// Utility to create a temp directory
function createTempDir() {
	const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "ai-rules-action-"));
	return tempDir;
}

/**
 * Execute a shell command with proper input validation and safe parameterization.
 * @param {string} command - The command to execute (e.g., 'git', 'npm')
 * @param {string[]|null} args - Array of arguments (safer) or null for string-based execution
 * @param {string} execDir - The directory to execute the command in
 * @returns {Promise<string>} The stdout from the command
 * @throws {Error} If the command fails
 */
async function executeCommand(command, args, execDir) {
	let stdout = "";
	let stderr = "";

	const options = {
		cwd: execDir,
		listeners: {
			stdout: (data) => {
				stdout += data.toString();
			},
			stderr: (data) => {
				stderr += data.toString();
			},
		},
	};

	let exitCode;
	if (args === null) {
		// Legacy string-based execution (less safe, but needed for complex commands)
		// Command should already be validated by caller
		exitCode = await exec.exec(command, [], options);
		core.debug(`Executed command: ${command}, exitCode: ${exitCode}`);
	} else {
		// Parameterized execution (safer) - arguments are passed separately
		exitCode = await exec.exec(command, args, options);
		core.debug(
			`Executed command: ${command} ${args.join(" ")}, exitCode: ${exitCode}`,
		);
	}

	if (exitCode !== 0) {
		throw new Error(`Command failed with exit code ${exitCode}: ${stderr}`);
	}

	return stdout;
}

// Sparse checkout .cursor and .github directories from target repo into temp dir
async function sparseCheckoutAIRulesDir(
	repoFullName,
	githubToken,
	tempDir,
	defaultBranch,
) {
	// Validate inputs to prevent command injection
	validateRepoFullName(repoFullName);
	validateGitRef(defaultBranch, "defaultBranch");

	const repoUrl = `https://x-access-token:${githubToken}@github.com/${repoFullName}.git`;

	// Clone the repository metadata only - use parameterized execution
	await executeCommand(
		"git",
		[
			"clone",
			"--branch",
			defaultBranch,
			"--depth",
			"1",
			"--filter=blob:none",
			"--no-checkout",
			repoUrl,
			".",
		],
		tempDir,
	);

	// Set the sparse paths to include both .cursor and .github directories
	await executeCommand(
		"git",
		[
			"sparse-checkout",
			"set",
			"--no-cone",
			"/.cursor/",
			"/.github/",
			"/.ai-rules-version",
			"/.ai-rules-config",
		],
		tempDir,
	);

	// Checkout the default branch - use parameterized execution
	await executeCommand("git", ["checkout", `origin/${defaultBranch}`], tempDir);
}

/**
 * Copy skills to target repository
 * Creates .cursor/skills/{skill-name}/SKILL.md and .github/skills/{skill-name}/SKILL.md
 */
function copySkillsToTarget(skillNames, skillsDir, tempDir) {
	// Clean up existing skills directories
	const cursorSkillsDir = path.join(tempDir, ".cursor", "skills");
	const githubSkillsDir = path.join(tempDir, ".github", "skills");

	if (fs.existsSync(cursorSkillsDir)) {
		fs.rmSync(cursorSkillsDir, { recursive: true });
	}
	if (fs.existsSync(githubSkillsDir)) {
		fs.rmSync(githubSkillsDir, { recursive: true });
	}

	// Create directories
	fs.mkdirSync(cursorSkillsDir, { recursive: true });
	fs.mkdirSync(githubSkillsDir, { recursive: true });

	// Copy each skill
	for (const skillName of skillNames) {
		const srcSkillDir = path.join(skillsDir, skillName);
		const srcSkillFile = path.join(srcSkillDir, "SKILL.md");

		if (!fs.existsSync(srcSkillFile)) {
			core.warning(`Skill not found: ${skillName}`);
			continue;
		}

		// Copy to .cursor/skills/{skill-name}/SKILL.md
		const cursorDest = path.join(cursorSkillsDir, skillName);
		fs.mkdirSync(cursorDest, { recursive: true });
		fs.copyFileSync(srcSkillFile, path.join(cursorDest, "SKILL.md"));

		// Copy to .github/skills/{skill-name}/SKILL.md
		const githubDest = path.join(githubSkillsDir, skillName);
		fs.mkdirSync(githubDest, { recursive: true });
		fs.copyFileSync(srcSkillFile, path.join(githubDest, "SKILL.md"));
	}

	core.info(`Copied ${skillNames.length} skills to .cursor/skills/ and .github/skills/`);
}

// Create .ai-rules-version file
function createVersionFile(tempDir, version, contentHash, topics, skills) {
	const versionInfo = {
		version: version,
		content_hash: contentHash,
		topics: topics,
		skills: skills,
		updated_at: new Date().toISOString(),
	};

	const versionPath = path.join(tempDir, ".ai-rules-version");
	fs.writeFileSync(versionPath, JSON.stringify(versionInfo, null, 2));
	core.info(`Created .ai-rules-version file`);
}

async function commitAndPush(tempDir, rulesVersion, branchName) {
	// Validate inputs to prevent command injection
	validateVersion(rulesVersion);
	validateGitRef(branchName, "branchName");

	try {
		await executeCommand("git", ["checkout", "-b", branchName], tempDir);
	} catch (_e) {
		// branch may already exist locally, ignore
	}
	// Set git user for commit
	await executeCommand(
		"git",
		["config", "user.email", "ai-rules-distributor[bot]@users.noreply.github.com"],
		tempDir,
	);
	await executeCommand(
		"git",
		["config", "user.name", "ai-rules-distributor[bot]"],
		tempDir,
	);
	await executeCommand("git", ["add", "--sparse", "."], tempDir);
	// Only commit if there are changes
	let hasChanges = false;
	try {
		await executeCommand("git", ["diff", "--cached", "--quiet"], tempDir);
		// No changes if exit code is 0
	} catch (_e) {
		hasChanges = true;
	}

	if (hasChanges) {
		// Note: String interpolation in commit message is safe because the entire message
		// is passed as a single atomic argument to 'git commit -m', and rulesVersion has
		// been validated to only contain safe characters.
		await executeCommand(
			"git",
			["commit", "-m", `Update AI coding rules to version ${rulesVersion}`],
			tempDir,
		);
		await executeCommand("git", ["push", "origin", branchName, "--force"], tempDir);
		core.info(`Pushed branch ${branchName}`);
	} else {
		core.info("No changes to commit. Skipping push and PR.");
	}

	return hasChanges;
}

async function openPR(
	defaultBranch,
	branchName,
	repository,
	rulesVersion,
	octokit,
	releaseBody,
	skills,
) {
	// Open PR
	const [owner, repo] = repository.split("/");
	const prTitle = `🤖 Update AI coding rules to version ${rulesVersion}`;
	const { data: prs } = await octokit.rest.pulls.list({
		owner,
		repo,
		head: `${owner}:${branchName}`,
	});
	if (prs.length === 0) {
		const skillList = skills.slice(0, MAX_SKILLS_IN_PR_BODY).map(s => `  - \`${s}\``).join("\n");
		const moreSkills = skills.length > MAX_SKILLS_IN_PR_BODY ? `\n  - ... and ${skills.length - MAX_SKILLS_IN_PR_BODY} more` : "";

		const prBody = `## AI Coding Rules Update

This PR updates the AI coding assistant rules to version **${rulesVersion}**.

### What's Included
- ✅ \`.cursor/skills/\` - Agent Skills for Cursor IDE (${skills.length} skills)
- ✅ \`.github/skills/\` - Agent Skills for GitHub Copilot (${skills.length} skills)
- ✅ \`.ai-rules-version\` - Version tracking file

### Skills
${skillList}${moreSkills}

### How Skills Work
Agent Skills use **description-based activation** - the AI reads each skill's description and automatically loads relevant skills based on your context and questions.

### How to Review
1. Review the skill files in \`.cursor/skills/\` or \`.github/skills/\`
2. Verify the skills align with your project's needs
3. Merge when ready - changes will apply to all developers using AI assistants

### Need to Customize?
If you need project-specific rules:
- Create a \`.ai-rules-config\` file to pin to a specific version
- Set \`enabled: false\` to disable automatic updates

---
*This PR was automatically created by the AI Rules Distribution System*

${releaseBody || ""}`;

		const { data: newPr } = await octokit.rest.pulls.create({
			owner,
			repo,
			head: branchName,
			base: defaultBranch,
			title: prTitle,
			body: prBody,
		});
		core.info(`Opened PR for branch ${branchName}`);
		return newPr.html_url;
	} else {
		core.info(`PR already exists for branch ${branchName}`);
		return prs[0].html_url;
	}
}

export {
	getRepoTopics,
	getDefaultBranch,
	loadTopicsConfig,
	getApplicableSkills,
	checkVersionConfig,
	getCurrentVersionInfo,
	needsUpdate,
	computeSkillsHash,
	createTempDir,
	sparseCheckoutAIRulesDir,
	copySkillsToTarget,
	createVersionFile,
	commitAndPush,
	openPR,
	getGithubReleaseBody,
};
