# Developer Guide: Custom GitHub Actions

This directory contains custom GitHub Actions used in the Price AI Skills
project.

## Actions Overview

| Action | Type | Description |
|--------|------|-------------|
| **apply-ai-rules** | Node.js | Applies Agent Skills to a repository based on its topics |
| **get-changed-files** | Composite | Identifies files changed since the previous release tag |
| **identify-github-topics** | Composite | Determines which GitHub topics are affected based on changed files |
| **identify-repositories** | Composite | Searches for repositories in an organization with specific GitHub topics |

## Action Types

### Composite Actions

Composite actions (`get-changed-files`, `identify-github-topics`, `identify-repositories`) use shell scripts and require no build step. They are defined entirely in their `action.yml` files.

### Node.js Actions

The `apply-ai-rules` action is a Node.js action that requires the `@actions/core`, `@actions/github`, and `@actions/exec` packages.

---

## apply-ai-rules

Applies Agent Skills to a target repository by:
1. Checking the repository's GitHub topics
2. Determining applicable skills from `topics.yaml`
3. Copying skills to `.cursor/skills/` and `.github/skills/`
4. Creating a PR with the changes

**Inputs:**
- `repository` (required): Target repository in format `owner/repo`
- `github_token` (required): GitHub token with PR creation permissions
- `release_tag` (optional): Release tag being distributed
- `dry_run` (optional): If true, no PR is created

**Outputs:**
- `pr_url`: URL of created PR (if any)
- `status`: Operation status (created, updated, skipped, error)

---

## get-changed-files

Gets list of files changed since the previous release tag.

**Inputs:**
- `github_token` (required): GitHub token for API access

**Outputs:**
- `changed_files`: JSON array of changed file paths

---

## identify-github-topics

Determines which AI rule topics are affected by changed files.

**Inputs:**
- `changed-files` (required): JSON array of changed file paths

**Outputs:**
- `affected-topics`: JSON array of affected GitHub topics
- `generic-rules-affected`: Whether generic skills were affected

---

## identify-repositories

Searches for repositories with specific GitHub topics.

**Inputs:**
- `topics` (required): JSON array of topics to search for
- `organization` (optional): GitHub organization to search in (default: `example-org`)
- `github_token` (required): GitHub token for API access

**Outputs:**
- `repositories`: JSON array of repository full names
- `repository-count`: Number of repositories found

---

## Usage in Workflows

These actions are used by the following workflows:

- **distribute-ai-rules.yml**: Uses all actions to distribute skills to affected repos
- **apply-ai-rules-manual.yml**: Uses `apply-ai-rules` for manual distribution

---

## Contributing

- Composite actions: Edit the `action.yml` file directly
- Node.js actions: Edit files in `src/`, ensure dependencies are available
- Test changes locally before committing
- Update this README when adding new actions
