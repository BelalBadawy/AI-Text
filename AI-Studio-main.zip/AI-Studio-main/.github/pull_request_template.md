## Change Description

<!-- Add a description here - which should include:
- Which skills are being modified and why
- Impact on development teams using these skills
- Rationale behind changes or additions
- Any compliance or governance implications

Delete this instruction block once the description is complete. -->

## PR Focus

<!--
Select one (or more) of the categories below and delete the others.
Make sure to label your Pull Request with appropriate labels.
Delete this comment block as well.
-->

- [ ] Skill Addition
- [ ] Skill Modification
- [ ] Skill Deprecation
- [ ] Documentation Update
- [ ] Topic Mapping Change
- [ ] Governance Update
- [ ] Compliance Integration

## Impact Assessment

<!--
Assess the impact of changes on development teams.
Select the appropriate impact level and provide reasoning.
Delete this comment block as well.
-->

- [ ] :green_circle: Low Impact (Documentation only, no skill changes)
- [ ] :yellow_circle: Medium Impact (Skill updates affecting specific topics)
- [ ] :red_circle: High Impact (Generic skill changes affecting all subscribers)

_Explanation:_

## Compliance and Governance

<!--
Indicate if this PR affects compliance mappings.
Delete this comment block as well.
-->

- [ ] No compliance impact
- [ ] Updates compliance mappings (SOC 2, ISO 27001, HIPAA)
- [ ] Modifies governance standards

_Explanation:_

## Backward Compatibility

- [x] Backward Compatible (Existing skills remain functional)
- [ ] Breaking Change (May require teams to update their implementations)

_Explanation:_

## Checklist

As the PR author, I have...

### Skill Development

- [ ] Created/updated `SKILL.md` with proper YAML frontmatter
- [ ] Included required fields (`name`, `description`)
- [ ] Written clear, actionable description for AI activation
- [ ] Used RFC2119 language (MUST, SHOULD, MAY) appropriately
- [ ] Kept skill content focused and under 500 lines

### Topic Mapping

- [ ] Updated `config/topics.yaml` if adding topic-specific skill
- [ ] Added to `generic_skills` if skill applies to all subscribers

### Validation

- [ ] Ran `npm run lint` successfully
- [ ] Tested skill activation in IDE (Cursor or Copilot)
- [ ] Verified no secrets or sensitive information in skills

### Documentation

- [ ] Updated README.md if needed
- [ ] Updated CONTRIBUTING.md if process changed
- [ ] Documented breaking changes or migration requirements

## Related Issues

<!--
Link any related tickets or issues.
Delete this section if not applicable.
-->

## Additional Context

<!--
Any additional information helpful for reviewers.
Delete this section if not needed.
-->
