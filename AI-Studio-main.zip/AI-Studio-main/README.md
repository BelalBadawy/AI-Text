# Zelis AI Studio - Agent Skills

Enterprise-wide, centrally managed AI coding assistant rules using the
**Agent Skills** standard. Works with both **Cursor IDE** and **GitHub Copilot**.

## Overview

This repository contains reusable Agent Skills that teach AI assistants how to
follow your organization's coding standards, security requirements, and best
practices. Skills are automatically loaded based on context—the AI decides
when each skill is relevant.

> **Agent Skills** is an open standard for extending AI agents with specialized
> capabilities. See [agentskills.io](https://agentskills.io) and
> [Cursor docs](https://cursor.com/docs/context/skills).

## Prerequisites

| Tool | Requirement |
|------|-------------|
| **Cursor IDE** | Beta/Nightly release required for Agent Skills support |
| **GitHub Copilot** | VS Code with Copilot extension |

> ⚠️ **Cursor Users**: Agent Skills require the [Cursor Beta](https://cursor.com/changelog) 
> (nightly) release. The stable release does not yet support the `SKILL.md` format.

## Repository Structure

```
Zelis.AI.Studio/
├── .vscode/                    # 🔧 VS Code workspace configuration
├── agents/                     # 🤖 Specialized Copilot agents
│   └── unit-test-generator.agent.md     # Generate C# unit tests with xUnit
├── config/
│   ├── skill-schema.json        # JSON schema for SKILL.md validation
│   └── topics.yaml              # Topic-to-skills mapping
├── instructions/               # 📋 Development guidelines and coding standards
│   ├── csharp.instructions.md           # Guidelines for C# development
│   ├── dotnet-upgrade.instructions.md   # .NET framework upgrade guidance
│   └── sql-sp-generation.instructions.md # SQL stored procedure guidelines
├── prompts/                    # 🎯 Reusable AI prompts for development
│   ├── specs/                          # Specification and analysis prompts
│   └── tech/                           # Technical development prompts
│       ├── documentation/              # Documentation generation prompts
│       │   ├── add-educational-comments.prompt.md
│       │   ├── architecture-blueprint-generator.prompt.md
│       │   ├── code-exemplars-blueprint-generator.prompt.md
│       │   ├── copilot-instructions-generator.prompt.md
│       │   ├── folder-structure-blueprint-generator.prompt.md
│       │   ├── project-workflow-analysis-blueprint-generator.prompt.md
│       │   └── technology-stack-blueprint-generator.prompt.md
│       ├── csharp-async.prompt.md       # C# async/await patterns
│       ├── dotnet-upgrade.prompts.md    # .NET upgrade assistance
│       └── sql-optimization.prompt.md   # SQL query optimization
├── skills/                      # Agent Skills (source of truth)
│   ├── coding-principles/SKILL.md
│   ├── python-backend/SKILL.md
│   ├── angular/
│   ├── dotnet-backend/
│   ├── security/
│   ├── testing/
│   └── ... (14 categories, 58 skills)
├── HowTo/                       # 📚 Usage guides
├── README.md                   # 📖 Repository overview and guidelines
└── .gitignore                  # Git ignore configuration
```

## Skills

| Category | Skills |
|----------|--------|
| **Architecture** | `sdlc/coding-principles`, `sdlc/sdlc-principles`, `sdlc/branch-protection`, `sdlc/pr-review-requirements`, `sdlc/commit-traceability` |
| **Security** | `security/security-standards`, `security/secure-coding-enforcement`, `security/permission-authorization`, `devops/dependency-hygiene`, `devops/ci-build-integrity` |
| **Quality** | `testing/testing-standards`, `testing/fast-test-feedback`, `testing/integration-test-contracts`, `testing/integration-testing`, `testing/bdd-acceptance-tests`, `testing/resilience-testing` |
| **Backend** | `python-backend`, `typescript-backend`, `dotnet-backend`, `rest-api-standards` |
| **Frontend** | `frontend-standards` |
| **DevOps** | `devops-ci-cd`, `terraform-infrastructure` |
| **Terraform** | `terraform-style-guide`, `terraform-test`, `terraform-stacks`, `azure-verified-modules`, `refactor-module` |
| **Standards** | `linting-standards`, `api-documentation` |

### Terraform Skills (from HashiCorp)

The Terraform category includes official skills from the [HashiCorp agent-skills repository](https://github.com/hashicorp/agent-skills):

**Code Generation:**
- `terraform-style-guide` - Write HCL following HashiCorp's official style conventions
- `terraform-test` - Write and run Terraform tests with `.tftest.hcl` files
- `azure-verified-modules` - Generate Azure Verified Modules compliant configurations

**Module Generation:**
- `terraform-stacks` - Work with Terraform Stacks for multi-component deployments
- `refactor-module` - Refactor existing Terraform code into reusable modules

These skills complement the existing `terraform-infrastructure` skill, which contains enterprise-specific Terraform standards and best practices.

## SKILL.md Format

Each skill is a `SKILL.md` file with YAML frontmatter:

```markdown
---
name: python-backend
description: |
  Python backend development standards. Use when writing Python services,
  FastAPI apps, async code, Pydantic models, or pytest tests.
disposition: contextual
filePatterns:
  - "**/*.py"
compliance:
  - soc2: "CC5.2"
version: "1.0.0"
---

# Python Backend Standards

## Code Structure
- Methods **MUST** be focused on a single responsibility.
...
```

> **For C# Development**: Review `instructions/csharp.instructions.md` for coding standards,
> use `prompts/tech/csharp-async.prompt.md` for async/await patterns, and use
> `agents/unit-test-generator.agent.md` for unit testing guidance (xUnit).

### Frontmatter Fields

| Field | Required | Description |
|-------|----------|-------------|
| `name` | Yes | Unique skill identifier |
| `description` | Yes | When to use this skill (AI reads this) |
| `disposition` | No | `always` or `contextual` (for governance tracking) |
| `filePatterns` | No | File patterns this skill applies to |
| `compliance` | No | Compliance mappings (SOC2, ISO27001, HIPAA) |
| `version` | No | Semantic version |

AI tools only read `name` and `description`. Other fields are for governance.

## How It Works

### For Developers

1. **Subscribe** your repo by adding a GitHub topic (e.g., `ai-rules-backend-python`)
2. **Receive** skills via automated PR to `.cursor/skills/` and `.github/skills/`
3. **Use** - AI automatically loads relevant skills based on context

### Context-Aware Activation

Both Cursor and Copilot read skill descriptions to decide when to load them:

```yaml
description: |
  Python backend development standards. Use when writing Python services...
```

When you ask about Python code, the AI loads the `python-backend` skill.
Security skills (`security-owasp-cwe`, etc.) are always active.

## Distribution

Subscriber repos receive skills based on their GitHub topics:

| Topic | Skills Received |
|-------|-----------------|
| `ai-rules-backend-python` | All generic + `python-backend` |
| `ai-rules-backend-typescript` | All generic + `typescript-backend` |
| `ai-rules-backend-dotnet` | All generic + `dotnet-backend` |
| `ai-rules-backend-rest-api` | All generic + `rest-api-standards` |
| `ai-rules-frontend` | All generic + `frontend-standards` |
| `ai-rules-devops` | All generic + `devops-ci-cd` |
| `ai-rules-devops-infrastructure` | All generic + `devops-ci-cd` + `terraform-infrastructure` + Terraform skills (style-guide, test, stacks, refactor-module, azure-verified-modules) |

See [SUBSCRIPTION.md](./SUBSCRIPTION.md) for enrollment details.

## Chat Modes & Prompts

This repository also includes specialized chat modes and prompts for common development scenarios:

### Chat Modes
- **API Architect**: Design and review API architectures
- **Code Quality Guardian**: Enforce code quality standards
- **Debug**: Systematic debugging assistance
- **Janitor**: Code cleanup and refactoring
- **Mentor**: Learning and educational guidance
- **Address Comments**: Handle code review comments

See the `HowTo/` directory for detailed guides on using each chat mode.

### Technical Prompts
- C# async/await patterns and xUnit testing
- .NET framework upgrade assistance
- SQL query optimization
- Documentation generation (architecture, code exemplars, workflows)

## Contributing

### Adding a New Skill

1. Create `skills/{skill-name}/SKILL.md`
2. Add required frontmatter (`name`, `description`)
3. Write the skill content
4. Add to `config/topics.yaml` if topic-specific
5. Run `npm run lint` to validate
6. Submit PR

### Editing Existing Skills

1. Edit the `SKILL.md` file directly
2. Update `version` in frontmatter
3. Run `npm run lint`
4. Submit PR

See [CONTRIBUTING.md](./CONTRIBUTING.md) for detailed guidelines.

## Local Development

```bash
npm install
npm run lint    # Validate all skills
npm test        # Same as lint
```

## Best Practices

- Follow your team's code review processes for all AI-assisted development
- Thoroughly review and test AI-generated code before integration
- Keep skills updated with evolving best practices and standards
- Document any modifications for future reference

## Compliance

Skills include compliance mappings for governance:

| Framework | Coverage |
|-----------|----------|
| SOC 2 | CC1.5, CC4.1, CC5.2, CC6.1, CC7.1, CC7.2, CC7.3 |
| ISO 27001 | A.12.x, A.14.x series |
| HIPAA | §164.312 (PHI protection) |
| OWASP | Top 10, ASVS |

## Support

For questions or suggestions about this repository, please reach out to your development team or create an issue for discussion.

---

**Version**: 1.0.0  
**Governance**: Enterprise Architecture Team  
*This repository is part of the Zelis development ecosystem, designed to enhance productivity through intelligent AI assistance.*
