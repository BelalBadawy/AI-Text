---
agent: 'agent'
description: 'Generate meaningful unit tests that validate business logic and real-world scenarios'
---

## Task
Analyze the selected function/method and generate focused unit tests that validate actual business behavior and provide real value beyond code coverage metrics.

## CRITICAL: Avoid Low-Value Tests
DO NOT generate tests for:
- Simple getters/setters without logic
- Auto-properties or constants
- Pass-through methods that only call other methods
- Trivial assignments or constructor parameter mapping
- Code that exists purely for framework requirements
- Private methods (test through public interface)

FOCUS ON:
- Business rules and validation logic
- Calculations and transformations
- Decision-making logic (if/switch statements)
- State transitions and workflows
- Integration points and boundaries
- Error handling for real failure scenarios

## Test Generation Strategy

### 1. Business Logic Tests (PRIORITY)
- **Validate business rules**: Test that domain rules are enforced
- **Test calculations**: Verify formulas, aggregations, transformations
- **Validate workflows**: Test state machines, multi-step processes
- **Test invariants**: Ensure business constraints are maintained
- **Real-world scenarios**: Use realistic data that represents actual use cases

Example: Instead of testing that a constant equals itself, test that:
- Discount calculations apply correct business rules
- Order totals include all applicable fees
- Status transitions follow allowed state changes

### 2. Input Validation Tests (Business Context)
- Test validation rules that protect business logic
- Verify domain-specific constraints (e.g., order amount > 0)
- Test business-meaningful boundary conditions (e.g., max transaction limit)
- Validate required fields for business processes
- Test data format requirements (email, phone, etc.)

Avoid: Testing null on a parameter that's never null in practice
Focus on: Testing validation that prevents invalid business states

### 3. Error Handling Tests (Real Failures)
- Test exceptions for recoverable business errors
- Verify meaningful error messages users/systems will see
- Test retry logic, fallback mechanisms, circuit breakers
- Validate compensating transactions or rollbacks
- Test timeout and resource exhaustion scenarios

Avoid: Testing that ThrowsException<Exception> for unrealistic scenarios
Focus on: Testing actual failure modes that occur in production

### 4. Integration & Boundary Tests
- Test interactions with external systems (APIs, databases, queues)
- Verify correct handling of external system failures
- Test data mapping between layers/systems
- Validate transaction boundaries
- Test eventual consistency scenarios

### 5. Edge Cases (Business-Relevant Only)
- Test boundary conditions that matter to business (min/max quantities, dates)
- Test rare but possible business scenarios
- Test data combinations that could cause issues
- Test performance-critical paths with realistic load

Avoid: Testing Integer.MaxValue when business limit is 1000
Focus on: Testing actual business constraints and limits

## Test Structure Requirements

### Naming Convention
Use descriptive names that explain business value:
- ✅ `ApplyDiscount_WhenCustomerIsVIP_ShouldApply20PercentDiscount`
- ✅ `ProcessOrder_WhenInventoryInsufficient_ShouldRejectOrderAndNotifyCustomer`
- ❌ `TestMethod1`
- ❌ `Constructor_SetsProperty` (low value)

### Arrange-Act-Assert Pattern
```csharp
[Fact]
public void CalculateShipping_WhenWeightExceedsLimit_ShouldAddOversizeFee()
{
    // Arrange - Set up realistic business scenario
    var order = new Order 
    { 
        Weight = 51.0m, // Exceeds 50kg limit
        Destination = "Remote Area",
        Items = CreateRealisticItems()
    };
    var calculator = new ShippingCalculator();
    
    // Act - Execute business logic
    var result = calculator.CalculateShipping(order);
    
    // Assert - Verify business outcome
    result.BaseFee.Should().Be(25.00m);
    result.OversizeFee.Should().Be(15.00m);
    result.Total.Should().Be(40.00m);
    result.DeliveryDays.Should().BeGreaterThanOrEqualTo(5);
}
```

## Quality Checklist
Before generating each test, ask:
1. ✅ Does this test validate actual business behavior?
2. ✅ Would this test catch a real bug that matters?
3. ✅ Does this test use realistic data/scenarios?
4. ✅ Would a business stakeholder understand the value?
5. ✅ Does this test something that could actually fail in production?

If any answer is "no", reconsider whether the test adds value.

## Test Data Strategy
- Use realistic test data that represents actual business scenarios
- Create builder patterns or fixtures for complex domain objects
- Use meaningful variable names (not "foo", "bar", "test123")
- Include test data that represents edge cases from real usage
- Consider using Theory/InlineData for multiple business scenarios

## Mocking Strategy
Mock external dependencies to:
- Isolate business logic being tested
- Simulate external system failures
- Control timing and async behavior
- Verify integration contracts

DO NOT mock:
- The class under test
- Simple DTOs or value objects
- Infrastructure that's part of the test (e.g., in-memory collections)

## Configuration
Target class/method: ${input:target:Which class or method should be tested?}
Testing framework: ${input:framework:xUnit/NUnit/MSTest (default: xUnit)}
Mocking library: ${input:mocking:Moq/NSubstitute/FakeItEasy (default: Moq)}
Assertion library: ${input:assertions:FluentAssertions/Shouldly/Standard (default: FluentAssertions)}

## Additional Context
Business domain: ${input:domain:Brief description of business context}
Known edge cases: ${input:edge_cases:Any specific scenarios to cover?}
Integration points: ${input:integrations:External systems this code interacts with?}

## Output Format
Generate tests as complete, compilable C# code with:
- All necessary using statements
- Proper test class structure
- Setup/teardown if needed
- Inline comments explaining complex business scenarios
- Summary of what business value each test provides