---
description: 'Generate effective C# unit tests with xUnit (including data-driven tests)'
tools: ['changes', 'search/codebase', 'edit/editFiles', 'problems', 'search', 'usages', 'runCommands', 'runTests', 'testFailure']
---

# Unit Test Generator (xUnit)

Your goal is to help me write effective unit tests with xUnit for C#/.NET code.

## Inputs to Gather

If not already provided, ask for:

- The target type(s) and method(s) to test
- Any expected behaviors, invariants, and edge cases
- External dependencies (HTTP, DB, time, filesystem) and how to isolate them
- Whether tests should be pure unit tests, or include integration-style tests

## Project Setup

- Prefer a separate test project named `[ProjectName].Tests`
- Reference `Microsoft.NET.Test.Sdk`, `xunit`, and `xunit.runner.visualstudio`
- Create test classes that match the classes being tested (e.g., `CalculatorTests` for `Calculator`)
- Use .NET SDK test commands: `dotnet test` for running tests

## Test Structure

- Use `[Fact]` for simple tests
- Use `[Theory]` for data-driven tests
- Follow the Arrange-Act-Assert (AAA) pattern (do not add “Arrange/Act/Assert” comments)
- Name tests using the pattern `MethodName_Scenario_ExpectedBehavior`
- Use constructors for setup and `IDisposable.Dispose()` for teardown
- Use `IClassFixture<T>` for shared context within a class
- Use `ICollectionFixture<T>` for shared context across multiple test classes

## Standard Tests

- Keep tests focused on a single behavior
- Avoid testing multiple behaviors in one test method
- Use clear assertions that express intent
- Include only assertions needed to verify the behavior
- Keep tests independent and idempotent (can run in any order)
- Avoid test interdependencies

## Data-Driven Tests

- Use `[Theory]` combined with data source attributes
- Use `[InlineData]` for small inline datasets
- Use `[MemberData]` for method-based test data
- Use `[ClassData]` for class-based test data
- For custom sources, implement `DataAttribute`
- Use meaningful parameter names in data-driven tests

## Assertions

- Use `Assert.Equal` for value equality
- Use `Assert.Same` for reference equality
- Use `Assert.True`/`Assert.False` for boolean conditions
- Use `Assert.Contains`/`Assert.DoesNotContain` for collections
- Use `Assert.Matches`/`Assert.DoesNotMatch` for regex checks
- Use `Assert.Throws<T>` or `await Assert.ThrowsAsync<T>` to test exceptions
- If the repo uses a fluent assertions library already, follow the existing convention

## Mocking and Isolation

- Mock external dependencies to isolate the unit under test
- Prefer interfaces to facilitate mocking
- Use an existing mocking library in the repo (commonly Moq or NSubstitute)
- For complex object graphs, consider using the DI container in the test project

## Test Organization

- Group tests by feature/component to match the production structure
- Use `[Trait("Category", "...")]` only if the repo already uses traits
- Use `ITestOutputHelper` for diagnostics when necessary
- Skip tests conditionally only when absolutely required (include a reason)

## Output Requirements

When generating tests:

- Only create/modify test files (and minimal supporting test utilities) needed for the requested coverage
- Prefer deterministic tests (avoid real time, randomness, network calls)
- If a behavior is ambiguous, ask a targeted question before writing brittle tests
